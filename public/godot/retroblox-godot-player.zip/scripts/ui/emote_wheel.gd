extends Control
## EmoteWheel — BACKSPACE pops the classic radial emote picker, Roblox style.
##
## The 8 slots come from Settings → Emotes (you set what sits where); an
## empty wheel can't emote — it tells you where to equip instead. Click a
## slot (or press its number 1–8) to play it on your character. BACKSPACE
## or ESC closes it. The game keeps running behind the wheel, exactly like
## the old client's emote menu.

signal picked(emote: String)

const RADIUS := 118.0            # slot ring radius around the screen center
const SLOT := 66.0               # slot button size
const TITLE := "EMOTES"

var is_open := false
## v14: asset id -> display name for custom (platform-published) emotes the
## game owns — set by game.gd after the account payload lands, so the wheel
## says the emote's real name instead of "Emote 3".
var custom_names: Dictionary = {}
## v15: asset id -> ImageTexture of the emote's catalog icon (the pose its
## creator locked on the studio timeline). When a slot's emote has one, the
## icon rides on the button above the name — the wheel looks like Roblox's.
var custom_icons: Dictionary = {}

var _slots: Array[Button] = []
var _hint: Label
var _dim: ColorRect
var _heading: Label


func _ready() -> void:
        set_anchors_preset(Control.PRESET_FULL_RECT)
        mouse_filter = Control.MOUSE_FILTER_STOP   # eat game clicks while open
        visible = false
        _build()


func _build() -> void:
        # soft dim so the wheel reads as "on top" without freezing the world
        _dim = ColorRect.new()
        _dim.color = Color(0.02, 0.03, 0.05, 0.35)
        _dim.set_anchors_preset(Control.PRESET_FULL_RECT)
        _dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
        add_child(_dim)

        _heading = Label.new()
        _heading.text = TITLE
        _heading.add_theme_font_size_override("font_size", 22)
        _heading.add_theme_color_override("font_color", Color(0.95, 0.96, 0.98))
        _heading.add_theme_color_override("font_outline_color", Color(0.05, 0.06, 0.09, 0.9))
        _heading.add_theme_constant_override("outline_size", 6)
        _heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        add_child(_heading)

        _hint = Label.new()
        _hint.text = ""
        _hint.add_theme_font_size_override("font_size", 15)
        _hint.add_theme_color_override("font_color", Color(0.85, 0.87, 0.92))
        _hint.add_theme_color_override("font_outline_color", Color(0.05, 0.06, 0.09, 0.9))
        _hint.add_theme_constant_override("outline_size", 5)
        _hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        add_child(_hint)

        var slot_face := StyleBoxFlat.new()
        slot_face.bg_color = Color(0.09, 0.11, 0.15, 0.92)
        slot_face.border_color = Color(0.55, 0.58, 0.64, 0.9)
        slot_face.set_border_width_all(2)
        slot_face.set_corner_radius_all(8)
        var slot_hover := slot_face.duplicate()
        slot_hover.bg_color = Color(0.16, 0.19, 0.25, 0.95)
        var slot_dead := slot_face.duplicate()
        slot_dead.bg_color = Color(0.06, 0.07, 0.09, 0.75)
        slot_dead.border_color = Color(0.3, 0.32, 0.36, 0.7)

        for i in range(8):
                var b := Button.new()
                b.custom_minimum_size = Vector2(SLOT, SLOT)
                b.focus_mode = Control.FOCUS_NONE
                b.add_theme_font_size_override("font_size", 13)
                b.add_theme_color_override("font_color", Color(0.95, 0.96, 0.98))
                b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
                b.add_theme_color_override("font_pressed_color", Color(1, 1, 1))
                b.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
                b.add_theme_constant_override("outline_size", 4)
                b.add_theme_stylebox_override("normal", slot_face)
                b.add_theme_stylebox_override("hover", slot_hover)
                b.add_theme_stylebox_override("pressed", slot_hover)
                b.add_theme_stylebox_override("disabled", slot_dead)
                b.pressed.connect(_on_slot.bind(i))
                add_child(b)
                _slots.append(b)


## BACKSPACE (from the game) — toggle.
func toggle() -> void:
        if is_open:
                close()
        else:
                open()


func open() -> void:
        is_open = true
        visible = true
        _refresh()
        _layout()


func close() -> void:
        is_open = false
        visible = false


## Place the ring + labels from the current viewport size (called on open —
## the wheel is fullscreen-anchored so the center follows resizes too).
func _layout() -> void:
        var vp := get_viewport_rect().size
        var center := vp * 0.5
        for i in range(_slots.size()):
                var ang := -PI * 0.5 + TAU * float(i) / 8.0   # slot 1 at the top, clockwise
                _slots[i].position = center + Vector2(cos(ang), sin(ang)) * RADIUS - Vector2(SLOT, SLOT) * 0.5
        _heading.position = Vector2(center.x - 160.0, center.y - _heading.get_minimum_size().y * 0.5 - 4.0)
        _heading.size = Vector2(320.0, 30.0)
        _hint.position = Vector2(center.x - 260.0, center.y + RADIUS + SLOT * 0.5 + 12.0)
        _hint.size = Vector2(520.0, 48.0)


func _refresh() -> void:
        var settings: Node = get_node_or_null("/root/Settings")
        var slots: Array = settings.get("emote_slots") if settings != null else []
        var equipped := 0
        for i in range(_slots.size()):
                var e := String(slots[i]) if i < slots.size() else ""
                if e != "":
                        equipped += 1
                        var label := String(custom_names.get(e, e.capitalize()))
                        _slots[i].text = "%d\n%s" % [i + 1, label]
                        _slots[i].disabled = false
                        _slots[i].tooltip_text = "Play %s" % label
                        # v15: the emote's own icon when it has one
                        var tex := custom_icons.get(e) as Texture2D
                        _slots[i].icon = tex
                        _slots[i].expand_icon = tex != null
                        _slots[i].add_theme_constant_override("icon_max_width", 34)
                        if tex != null and "vertical_icon_alignment" in _slots[i]:
                                # icon centered ABOVE the name (Godot 4.4+)
                                _slots[i].icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
                                _slots[i].vertical_icon_alignment = VERTICAL_ALIGNMENT_TOP
                else:
                        _slots[i].text = "%d\n—" % (i + 1)
                        _slots[i].icon = null
                        _slots[i].expand_icon = false
                        _slots[i].disabled = true
                        _slots[i].tooltip_text = "Empty slot — set it in Settings → Emotes"
        if equipped == 0:
                _hint.text = "No emotes equipped — open Settings → Emotes to set your wheel"
        else:
                _hint.text = "Click a slot or press its number — BACKSPACE / ESC closes"


func _on_slot(index: int) -> void:
        if not is_open:
                return
        var settings: Node = get_node_or_null("/root/Settings")
        var slots: Array = settings.get("emote_slots") if settings != null else []
        var e := String(slots[index]) if index < slots.size() else ""
        if e == "":
                return   # empty slot — nothing equipped there, nothing plays
        picked.emit(e)
        close()


func _unhandled_input(event: InputEvent) -> void:
        if not is_open:
                return
        if event is InputEventKey and event.is_pressed() and not event.is_echo():
                var k := (event as InputEventKey).keycode
                if k >= KEY_1 and k <= KEY_8:
                        _on_slot(k - KEY_1)
                        get_viewport().set_input_as_handled()
                elif k == KEY_BACKSPACE or k == KEY_ESCAPE:
                        close()
                        get_viewport().set_input_as_handled()
