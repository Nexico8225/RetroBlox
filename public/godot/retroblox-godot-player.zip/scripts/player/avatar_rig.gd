extends Node3D
## AvatarRig — the classic six-part block avatar, rebuilt for the new player.
##
## Two visual modes behind one tiny API:
##   1) R6IK mode (default) — the real catalog model. The same R6IK.fbx rig
##      the website's avatar editor renders ships in assets/models/. Limbs
##      swing from its own AnimationPlayer (the old Roblox clips).
##   2) Box mode (fallback) — a code-built classic box body used on first
##      open before Godot imported the FBX, or without a models folder.
##
## The rig is EXACTLY 5 studs tall (classic R6 height) in both modes, so
## creator-placed 3D UGC lands 1:1 with the website's 5-stud rig.

const HEAD := 0
const TORSO := 1
const ARM_L := 2
const ARM_R := 3
const LEG_L := 4
const LEG_R := 5
const HEAD_INDEX := 0

const RIG_SCENE_PATH := "res://assets/models/retroblox_anims.fbx"
## The rig is 5 studs tall, built 1 stud = 1 Godot unit — the classic size.
## UGC hats and creator placements are authored in this same 5-stud space.
const STUD := 1.0
const RIG_HEIGHT := 5.0 * STUD
const SITE_RIG_HEIGHT := 5.0

const ANIM_IDLE := &"Idle"
const ANIM_WALK := &"Walk"
const ANIM_JUMP := &"Jump"
const ANIM_CLIMB := &"Climb"
const ANIM_SIT := &"Sit"

# chat emotes (/e wave · /e dance · /e point · /e laugh · /e cheer · /e sit)
# — posed PROCEDURALLY so they play identically on the real FBX rig and the
# fallback boxes: no clips, no missing-animation errors, works from first open
const EMOTE_NAMES := ["wave", "dance", "point", "laugh", "cheer", "sit"]

# classic noob defaults — guests and brand-new accounts wear these
const NOOB_HEAD := Color("f5cd30")
const NOOB_TORSO := Color("0d69ac")
const NOOB_ARMS := Color("f5cd30")
const NOOB_LEGS := Color("7ab53e")

# name aliases, ported from the site's rig so any part naming convention works
const PART_ALIASES: Array = [
        [HEAD, ["head"]],
        [TORSO, ["torso"]],
        [ARM_L, ["left arm", "leftarm", "arm l", "l arm"]],
        [ARM_R, ["right arm", "rightarm", "arm r", "r arm"]],
        [LEG_L, ["left leg", "leftleg", "leg l", "l leg"]],
        [LEG_R, ["right leg", "rightleg", "leg r", "r leg"]],
]
const RIG_NAME_CHARS := "abcdefghijklmnopqrstuvwxyz0123456789_"

# classic R6 proportions (studs) for the code-built box body — scaled by STUD
const BOX_LEG_H := 2.0 * STUD
const BOX_TORSO := Vector3(2.0, 2.0, 1.0) * STUD
const BOX_ARM := Vector3(1.0, 2.0, 1.0) * STUD
const BOX_LEG := Vector3(1.0, 2.0, 1.0) * STUD
const BOX_HEAD := Vector3(1.15, 1.15, 1.15) * STUD

var parts: Array[MeshInstance3D] = []
var HEAD_PIVOT_Y := 0.0  # head center height, set by the active mode

var _pivots: Array[Node3D] = []
var _part_sizes: Array[Vector3] = []
var _part_aabb: Array[AABB] = []
var _mounts: Array[Node3D] = []
var _overlays: Dictionary = {}
var _nameplate: Label3D
var _face_decal: MeshInstance3D
var _tshirt_decal: MeshInstance3D   # v4.0: the t-shirt image decal on the torso front
var _display_name := "Player"
var _built := false
var _using_r6ik := false
var _time := 0.0
var _applied_colors: Dictionary = {}
var _anim_player: AnimationPlayer
var _current_anim := &""
var _walk_rate := 1.0     # v11.0: eased playback speeds (no more rate snaps)
var _climb_rate := 1.0
var _oof_audio: AudioStream


func _ready() -> void:
        _ensure_built(true)


func is_r6ik() -> bool:
        return _using_r6ik


func setup(p_name: String) -> void:
        _display_name = p_name
        _ensure_built()
        paint_noob()
        set_display_name(p_name)


func set_display_name(value: String) -> void:
        _display_name = value
        if _nameplate != null:
                _nameplate.text = value


func paint_noob() -> void:
        set_part_color(HEAD, NOOB_HEAD)
        set_part_color(TORSO, NOOB_TORSO)
        set_part_color(ARM_L, NOOB_ARMS)
        set_part_color(ARM_R, NOOB_ARMS)
        set_part_color(LEG_L, NOOB_LEGS)
        set_part_color(LEG_R, NOOB_LEGS)


## Paint one body part a solid color (texture-free).
func set_part_color(index: int, color: Color) -> void:
        _ensure_built()
        if index < 0 or index >= parts.size():
                return
        _applied_colors[index] = color
        var mi := parts[index]
        if mi.mesh == null:
                return
        for surface in mi.mesh.get_surface_count():
                mi.set_surface_override_material(surface, null)
        mi.material_override = _make_material(color)


## Dress one part with a zone-UV box mesh + texture (the shirt/pants pipeline).
func set_part_textured(index: int, mesh: Mesh, tex: Texture2D) -> void:
        _ensure_built()
        if index < 0 or index >= parts.size():
                return
        var mi := parts[index]
        var material := StandardMaterial3D.new()
        material.albedo_texture = tex
        material.roughness = 0.78
        if _using_r6ik:
                if _overlays.has(index) and is_instance_valid(_overlays[index]):
                        _overlays[index].queue_free()
                var overlay := MeshInstance3D.new()
                overlay.name = "ClothingOverlay_%d" % index
                overlay.mesh = mesh
                overlay.material_override = material
                _mounts[index].add_child(overlay)
                overlay.scale = Vector3.ONE * 1.02
                _overlays[index] = overlay
        else:
                mi.mesh = mesh
                mi.material_override = material


## v4.0 T-SHIRTS — an image decal on the FRONT of the torso, exactly what
## the website draws (92% of the torso face). T-shirt UGC ships as a plain
## image (no GLB), so the dresser hands the texture here instead of the
## 3D accessory path. Repainted whenever a new t-shirt arrives; freed with
## the rig.
func set_tshirt(tex: Texture2D) -> void:
        _ensure_built()
        if tex == null:
                return
        if _tshirt_decal != null and is_instance_valid(_tshirt_decal):
                _tshirt_decal.queue_free()
                _tshirt_decal = null
        var torso_size := _part_sizes[TORSO]
        var quad := MeshInstance3D.new()
        quad.name = "TshirtDecal"
        var mesh := QuadMesh.new()
        mesh.size = Vector2(torso_size.x * 0.92, torso_size.y * 0.92)
        quad.mesh = mesh
        var material := StandardMaterial3D.new()
        material.albedo_texture = tex
        material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
        material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        material.cull_mode = BaseMaterial3D.CULL_DISABLED
        quad.material_override = material
        var host: Node3D = _mounts[TORSO]
        host.add_child(quad)
        # the front of the torso faces -Z — same wall the face decal hangs on
        quad.position = Vector3(0.0, 0.0, -torso_size.z * 0.5 - 0.004)
        quad.rotation.y = PI
        _tshirt_decal = quad


## Put a face decal on the FRONT of the head (-Z).
func set_face(tex: Texture2D, face_scale: float) -> void:
        _ensure_built()
        if tex == null:
                return
        if _face_decal != null and is_instance_valid(_face_decal):
                _face_decal.queue_free()
                _face_decal = null
        var head_size := _part_sizes[HEAD_INDEX]
        var w: float = head_size.x * 0.62 * clampf(face_scale, 0.5, 2.0)
        var quad := MeshInstance3D.new()
        quad.name = "FaceDecal"
        var mesh := QuadMesh.new()
        mesh.size = Vector2(w, w)
        quad.mesh = mesh
        var material := StandardMaterial3D.new()
        material.albedo_texture = tex
        material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
        material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        material.cull_mode = BaseMaterial3D.CULL_DISABLED
        quad.material_override = material
        var host: Node3D = _mounts[HEAD_INDEX]
        host.add_child(quad)
        quad.position = Vector3(0.0, head_size.y * 0.04, -head_size.z * 0.5 - 0.004)
        quad.rotation.y = PI
        _face_decal = quad


func animate(delta: float, speed: float, grounded: bool, climbing: bool = false) -> void:
        _ensure_built()
        _time += delta
        if _emote != "":
                # any movement or air time releases the pose, classic-style
                if speed > 1.2 * STUD or not grounded:
                        stop_emote()
                elif _emote == "custom":
                        return  # the emote model's own AnimationPlayer drives it
                elif _using_r6ik and _emote == "sit" and _anim_player != null \
                                and _anim_player.has_animation(ANIM_SIT):
                        return  # the rig's own Sit clip is playing
                else:
                        _pose_emote(delta)
                        return
        if _using_r6ik and _anim_player != null:
                _animate_r6ik(delta, speed, grounded, climbing)
                return
        _animate_boxes(delta, speed, grounded, climbing)


func _animate_r6ik(delta: float, speed: float, grounded: bool, climbing: bool) -> void:
        var next: StringName = ANIM_IDLE
        var rate := 1.0
        if climbing:
                next = ANIM_CLIMB
                rate = clampf(speed / (9.0 * STUD), 0.5, 1.5)
        elif not grounded:
                next = ANIM_JUMP
        elif speed > 1.2 * STUD:
                next = ANIM_WALK
                rate = clampf(speed / (8.0 * STUD), 0.8, 2.2)
        if _current_anim != next:
                _current_anim = next
                # v11.0: the JUMP crossfade doubles (0.08 -> 0.16) — the old
                # near-instant cut was the arm pop every time you left the ground
                _anim_player.play(next, 0.16, rate if next != ANIM_JUMP else 1.35)
        elif next == ANIM_WALK or next == ANIM_CLIMB:
                # v11.0: playback speed EASES toward its target — the climb
                # rate rides |velocity.y| which jitters frame to frame, and
                # that jitter read as twitching arms on the ladder
                var k := 1.0 - exp(-8.0 * delta)
                if next == ANIM_WALK:
                        _walk_rate = lerpf(_walk_rate, rate, k)
                        _anim_player.speed_scale = _walk_rate
                else:
                        _climb_rate = lerpf(_climb_rate, rate, k)
                        _anim_player.speed_scale = _climb_rate


## ---------------- emotes (/e wave · /e dance · /e point · /e laugh · /e sit)
## Roblox-style chat emotes, posed procedurally so they play identically on
## the real FBX rig and the fallback boxes — no clips, no missing-animation
## errors. Movement keeps calling animate() every frame; while an emote is
## up it drives the pose instead, and any move / jump / climb releases it.

var _emote := ""            # "" or one of EMOTE_NAMES
var _emote_t := 0.0
var _emote_rest: Array[Transform3D] = []
var _emote_top: Array[Vector3] = []    # shoulder / hip pivot, part-parent space
var _emote_mid: Array[Vector3] = []    # part center pivot, part-parent space
var _emote_ax: Array[Basis] = []       # rig X/Y/Z axes mapped into parent space


func start_emote(emote: String) -> bool:
        var e := emote.to_lower().strip_edges()
        if e == "stop" or e == "stand" or e == "":
                stop_emote()
                return true
        if not EMOTE_NAMES.has(e):
                return false
        _ensure_built(true)
        if parts.size() < 6:
                return false
        _emote = e
        _emote_t = 0.0
        if _anim_player != null:
                _anim_player.stop()   # hand every track back for manual posing
        _capture_emote_rest()
        if _using_r6ik and e == "sit" and _anim_player != null \
                        and _anim_player.has_animation(ANIM_SIT):
                _anim_player.play(ANIM_SIT)   # the rig's own sit reads best
        return true


func stop_emote() -> void:
        _emote = ""
        _emote_t = 0.0
        if _custom_root != null and is_instance_valid(_custom_root):
                _custom_root.queue_free()
        _custom_root = null
        _restore_body_visuals()


## ---------------- custom emotes (v14) --------------------------------------
## Emote items published on the platform (Catalog -> Publish UGC -> Emotes)
## are their OWN rigged models, so they play as their own model: the body
## steps out, the emote model stands in on the same spot and loops its clip,
## and the first move / jump hands the body back. Loaded through the runtime
## GLTF importer — user files never touch the editor import step.

var _custom_root: Node3D = null
var _custom_cache: Dictionary = {}   # path -> template Node3D (duplicated per play)
var _hidden_visuals: Array = []      # body meshes hidden while the emote model stands in


## Play a downloaded .glb emote. clip "" picks the first animation inside.
func start_custom_emote(path: String, clip: String) -> bool:
        stop_emote()
        _ensure_built(true)
        if parts.size() < 6:
                return false
        var template := _custom_template(path)
        if template == null:
                return false
        var root := template.duplicate() as Node3D
        if root == null:
                return false
        add_child(root)
        if not _fit_custom(root):
                root.queue_free()
                return false
        var ap := root.find_child("AnimationPlayer", true, false) as AnimationPlayer
        if ap == null or ap.get_animation_list().is_empty():
                root.queue_free()
                return false
        var anim_name := clip if ap.has_animation(clip) else String(ap.get_animation_list()[0])
        ap.get_animation(anim_name).loop_mode = Animation.LOOP_LINEAR
        ap.play(anim_name)
        _custom_root = root
        _emote = "custom"
        _emote_t = 0.0
        if _anim_player != null:
                _anim_player.stop()
        _hide_body_visuals()
        return true


## Runtime GLB parse (cached per path — a re-play costs nothing).
func _custom_template(path: String) -> Node3D:
        if _custom_cache.has(path):
                return _custom_cache[path]
        if not FileAccess.file_exists(path):
                return null
        var doc := GLTFDocument.new()
        var state := GLTFState.new()
        if doc.append_from_file(path, state) != OK:
                return null
        var node := doc.generate_scene(state) as Node3D
        if node == null:
                return null
        _custom_cache[path] = node
        return node


## Scale the model to classic height, feet on the rig origin, centered.
func _fit_custom(root: Node3D) -> bool:
        var box := AABB()
        var first := true
        for mi in root.find_children("*", "MeshInstance3D", true, false):
                var m := mi as MeshInstance3D
                var wb: AABB = m.global_transform * m.get_aabb()
                if first:
                        box = wb
                        first = false
                else:
                        box = box.merge(wb)
        if first or box.size.y <= 0.01:
                return false
        var s := RIG_HEIGHT / box.size.y
        root.scale = Vector3(s, s, s)
        root.position = Vector3(-box.get_center().x * s, -box.position.y * s, -box.get_center().z * s)
        return true


func _hide_body_visuals() -> void:
        _hidden_visuals.clear()
        for mi in find_children("*", "MeshInstance3D", true, false):
                var m := mi as MeshInstance3D
                if _custom_root != null and _custom_root.is_ancestor_of(m):
                        continue
                if not m.visible:
                        continue
                _hidden_visuals.append(m)
                m.visible = false


func _restore_body_visuals() -> void:
        for m in _hidden_visuals:
                if m != null and is_instance_valid(m):
                        m.visible = true
        _hidden_visuals.clear()


## Snapshot every part's rest transform, its two useful pivots (top edge =
## shoulder / hip, and center) and the rig axes expressed in the part's
## parent space — the FBX nodes carry tilted Blender rotations, so posing
## must rotate around world-meaningful axes, not the node's own.
func _capture_emote_rest() -> void:
        _emote_rest.clear()
        _emote_top.clear()
        _emote_mid.clear()
        _emote_ax.clear()
        for i in range(parts.size()):
                var p := parts[i]
                _emote_rest.append(p.transform)
                var box: AABB = _part_aabb[i]
                var center := box.get_center()
                var top := center
                top.y = box.end.y
                var xf: Transform3D = p.get_parent().global_transform
                var inv: Transform3D = xf.affine_inverse()
                if is_inside_tree():
                        # R6IK boxes are measured in rig space; box-mode boxes
                        # in the part's own space — both go through world here
                        var world_top := to_global(top) if _using_r6ik else p.global_transform * top
                        var world_mid := to_global(center) if _using_r6ik else p.global_transform * center
                        _emote_top.append(inv * world_top)
                        _emote_mid.append(inv * world_mid)
                else:
                        _emote_top.append(top)
                        _emote_mid.append(center)
                var to_parent: Basis = xf.basis.inverse() * global_transform.basis
                _emote_ax.append(Basis(
                        (to_parent * Vector3.RIGHT).normalized(),
                        (to_parent * Vector3.UP).normalized(),
                        (to_parent * Vector3.BACK).normalized()))


## Rotate one part around a rig-space pivot for this frame, easing in from
## its rest pose over the first ~0.18 s.
func _drive(index: int, rot: Basis, pivot: Vector3, w: float) -> void:
        if index < 0 or index >= parts.size():
                return
        var target := Transform3D(rot, pivot) * Transform3D(Basis(), -pivot) * _emote_rest[index]
        parts[index].transform = _emote_rest[index].interpolate_with(target, w)


func _pose_emote(delta: float) -> void:
        _emote_t += delta
        var w := clampf(_emote_t / 0.18, 0.0, 1.0)
        w = 1.0 - (1.0 - w) * (1.0 - w)   # ease-out into the pose
        var t := _emote_t
        match _emote:
                "wave":
                        # right arm up through its own side, swinging hello
                        var ang := PI - 0.30 + sin(t * 7.5) * 0.5
                        _drive(ARM_R, Basis(_emote_ax[ARM_R].z, ang), _emote_top[ARM_R], w)
                "point":
                        _drive(ARM_R, Basis(_emote_ax[ARM_R].x, 1.45), _emote_top[ARM_R], w)
                        _drive(HEAD, Basis(_emote_ax[HEAD].x, -0.12), _emote_mid[HEAD], w)
                "laugh":
                        var bob := sin(t * 6.0)
                        _drive(HEAD, Basis(_emote_ax[HEAD].x, 0.45 + bob * 0.14), _emote_mid[HEAD], w)
                        _drive(TORSO, Basis(_emote_ax[TORSO].x, 0.16 + bob * 0.05), _emote_mid[TORSO], w)
                        _drive(ARM_L, Basis(_emote_ax[ARM_L].z, -0.55), _emote_top[ARM_L], w)
                        _drive(ARM_R, Basis(_emote_ax[ARM_R].z, 0.55), _emote_top[ARM_R], w)
                "dance":
                        var beat := sin(t * 5.2)
                        _drive(TORSO, Basis(_emote_ax[TORSO].y, beat * 0.42), _emote_mid[TORSO], w)
                        _drive(HEAD, Basis(_emote_ax[HEAD].y, -beat * 0.38)
                                * Basis(_emote_ax[HEAD].x, absf(beat) * 0.10), _emote_mid[HEAD], w)
                        _drive(ARM_L, Basis(_emote_ax[ARM_L].z, -(1.9 - beat * 0.55)), _emote_top[ARM_L], w)
                        _drive(ARM_R, Basis(_emote_ax[ARM_R].z, 1.9 + beat * 0.55), _emote_top[ARM_R], w)
                "sit":
                        _drive(LEG_L, Basis(_emote_ax[LEG_L].x, 1.50), _emote_top[LEG_L], w)
                        _drive(LEG_R, Basis(_emote_ax[LEG_R].x, 1.50), _emote_top[LEG_R], w)
                        _drive(ARM_L, Basis(_emote_ax[ARM_L].x, -0.45), _emote_top[ARM_L], w)
                        _drive(ARM_R, Basis(_emote_ax[ARM_R].x, -0.45), _emote_top[ARM_R], w)
                "cheer":
                        # both arms straight up, face to the sky — hooray!
                        var hop := absf(sin(t * 6.5))
                        _drive(ARM_L, Basis(_emote_ax[ARM_L].x, -2.6 + hop * 0.15), _emote_top[ARM_L], w)
                        _drive(ARM_R, Basis(_emote_ax[ARM_R].x, -2.6 + hop * 0.15), _emote_top[ARM_R], w)
                        _drive(HEAD, Basis(_emote_ax[HEAD].x, 0.35), _emote_mid[HEAD], w)
                        _drive(TORSO, Basis(_emote_ax[TORSO].x, -0.08 + hop * 0.05), _emote_mid[TORSO], w)


func _animate_boxes(delta: float, speed: float, grounded: bool, climbing: bool) -> void:
        var movement := clampf(absf(speed) / (5.0 * STUD), 0.0, 1.0)
        var walk_rate := 4.8 + movement * 2.0
        var swing := sin(_time * walk_rate) * movement
        # v11.0: every state computes a TARGET pose and the rig EASES toward
        # it (1-exp blend) — the old direct assignments teleported the arms
        # between walk / climb / jump poses every time the state flipped, and
        # that teleport WAS the twitch / out-of-place arms you felt climbing.
        var k := 1.0 - exp(-12.0 * delta)
        var arm_l_x := 0.0
        var arm_r_x := 0.0
        var leg_l_x := 0.0
        var leg_r_x := 0.0
        var head_x := 0.0
        var torso_x := 0.0
        var arm_l_z := 0.0
        var arm_r_z := 0.0
        if climbing:
                var alt := sin(_time * 6.5) * 0.9
                arm_l_x = -2.4 + alt * 0.4
                arm_r_x = -2.4 - alt * 0.4
                leg_l_x = alt * 0.5
                leg_r_x = -alt * 0.5
        elif grounded:
                arm_l_x = swing * 0.7
                arm_r_x = -swing * 0.7
                leg_l_x = -swing * 0.66
                leg_r_x = swing * 0.66
                head_x = sin(_time * 1.8) * 0.025
                torso_x = sin(_time * 1.8 + 0.5) * 0.012
                arm_l_z = sin(_time * 2.1) * 0.025 * (1.0 - movement)
                arm_r_z = -arm_l_z
        else:
                arm_l_x = -2.6
                arm_r_x = -2.6
                leg_l_x = 0.35
                leg_r_x = -0.35
        _pivots[ARM_L].rotation.x = lerp_angle(_pivots[ARM_L].rotation.x, arm_l_x, k)
        _pivots[ARM_R].rotation.x = lerp_angle(_pivots[ARM_R].rotation.x, arm_r_x, k)
        _pivots[LEG_L].rotation.x = lerp_angle(_pivots[LEG_L].rotation.x, leg_l_x, k)
        _pivots[LEG_R].rotation.x = lerp_angle(_pivots[LEG_R].rotation.x, leg_r_x, k)
        _pivots[ARM_L].rotation.z = lerp_angle(_pivots[ARM_L].rotation.z, arm_l_z, k)
        _pivots[ARM_R].rotation.z = lerp_angle(_pivots[ARM_R].rotation.z, arm_r_z, k)
        _pivots[HEAD].rotation.x = lerp_angle(_pivots[HEAD].rotation.x, head_x, k)
        _pivots[TORSO].rotation.x = lerp_angle(_pivots[TORSO].rotation.x, torso_x, k)


## Oof! — the classic breakup, used by death and reset.
func burst(world: Node3D, impulse_seed: int) -> void:
        _ensure_built()
        if world == null:
                return
        visible = false
        var debris := Node3D.new()
        debris.name = "AvatarBreakup"
        world.add_child(debris)
        debris.global_position = global_position
        var rng := RandomNumberGenerator.new()
        rng.seed = abs(impulse_seed) * 104729 + 13
        for i in range(parts.size()):
                var piece := _make_debris_piece(debris, i)
                piece.linear_velocity = Vector3(
                        rng.randf_range(-4.8, 4.8), rng.randf_range(4.0, 7.5), rng.randf_range(-4.8, 4.8)) * STUD
                piece.angular_velocity = Vector3(
                        rng.randf_range(-5.5, 5.5), rng.randf_range(-5.5, 5.5), rng.randf_range(-5.5, 5.5))
        var audio := AudioStreamPlayer3D.new()
        audio.name = "OriginalOof"
        audio.stream = _get_oof_audio()
        audio.max_distance = 40.0 * STUD
        audio.unit_size = 10.0 * STUD
        debris.add_child(audio)
        audio.play()
        var cleanup := world.get_tree().create_timer(5.0)
        cleanup.timeout.connect(debris.queue_free)


func _get_oof_audio() -> AudioStream:
        if _oof_audio == null:
                # the ORIGINAL classic death sound straight from the client
                if ResourceLoader.exists("res://assets/rbx_uuhhh.mp3"):
                        _oof_audio = load("res://assets/rbx_uuhhh.mp3")
                else:
                        _oof_audio = load("res://assets/oof.wav")
        return _oof_audio


# ---------------------------------------------------------------- building

func _ensure_built(allow_upgrade: bool = false) -> void:
        if _built:
                if allow_upgrade and not _using_r6ik and is_inside_tree():
                        _try_r6ik()
                return
        _built = true
        if is_inside_tree() and _try_r6ik():
                return
        _build_boxes()


## The real R6IK catalog model. Returns false when the FBX is not imported
## yet (fresh unzip, first open) — the box rig takes over until then.
func _try_r6ik() -> bool:
        var packed: PackedScene = load(RIG_SCENE_PATH)
        if packed == null:
                return false
        var inst: Node3D = packed.instantiate()
        if inst == null:
                return false
        var found: Dictionary = {}
        for node in inst.find_children("*", "MeshInstance3D", true, false):
                var mi := node as MeshInstance3D
                if mi.mesh == null:
                        continue
                var index := _match_part_name(mi.name, mi.mesh.resource_name)
                if index >= 0:
                        found[index] = mi
                else:
                        mi.visible = false
        if found.size() < 6:
                inst.free()
                return false
        _using_r6ik = true

        for node in inst.find_children("*", "AnimationPlayer", true, false):
                var ap := node as AnimationPlayer
                ap.autoplay = ""
                ap.stop()
                # the FBX exports EVERY clip as play-once — the classic clips
                # must LOOP (idle/walk/climb/sit) or the character freezes
                # after one second. Jump keeps its single-shot arc.
                for clip in [ANIM_IDLE, ANIM_WALK, ANIM_CLIMB, ANIM_SIT]:
                        var looped := ap.get_animation(clip)
                        if looped != null:
                                looped.loop_mode = Animation.LOOP_LINEAR
                var jump_anim := ap.get_animation(ANIM_JUMP)
                if jump_anim != null:
                        jump_anim.loop_mode = Animation.LOOP_NONE
                _anim_player = ap

        # normalize: RIG_HEIGHT tall, feet on y=0, centered on x/z — bounds from
        # REAL vertices (the FBX part nodes carry tilted Blender rotations)
        var raw_bounds := AABB()
        var have_bounds := false
        var part_boxes: Dictionary = {}
        for index in found:
                var mi: MeshInstance3D = found[index]
                var chain := _chain_transform(mi, inst)
                var box := _vertex_aabb(mi.mesh, chain)
                part_boxes[index] = box
                raw_bounds = box if not have_bounds else raw_bounds.merge(box)
                have_bounds = true
        var fit := RIG_HEIGHT / maxf(raw_bounds.size.y, 0.0001)
        var raw_center := raw_bounds.get_center()
        var model := Node3D.new()
        model.name = "R6IKModel"
        model.scale = Vector3.ONE * fit
        model.position = Vector3(-raw_center.x * fit, -raw_bounds.position.y * fit, -raw_center.z * fit)
        model.add_child(inst)
        add_child(model)

        parts.clear()
        _pivots.clear()
        _part_sizes.clear()
        _part_aabb.clear()
        _mounts.clear()
        for i in range(6):
                var mi: MeshInstance3D = found[i]
                var box: AABB = model.transform * part_boxes[i]
                parts.append(mi)
                _part_sizes.append(box.size)
                _part_aabb.append(box)
                var mount := Node3D.new()
                mount.name = "Mount_%d" % i
                mi.add_child(mount)
                var world_center := to_global(box.get_center())
                mount.transform = mi.global_transform.affine_inverse() * Transform3D(global_transform.basis, world_center)
                _mounts.append(mount)
                if i == HEAD_INDEX:
                        HEAD_PIVOT_Y = box.get_center().y
        for i in range(6):
                _pivots.append(null)

        _nameplate = _make_nameplate()
        _nameplate.position = Vector3(0.0, RIG_HEIGHT + 0.9 * STUD, 0.0)
        add_child(_nameplate)
        _nameplate.text = _display_name

        for index in _applied_colors:
                if index >= 0 and index < parts.size():
                        parts[index].material_override = _make_material(_applied_colors[index])
        return true


## Code-built classic box body — 5 studs tall, feet on y=0, facing -Z.
func _build_boxes() -> void:
        parts.clear()
        _pivots.clear()
        _part_sizes.clear()
        _part_aabb.clear()
        _mounts.clear()
        if _face_decal != null and is_instance_valid(_face_decal):
                _face_decal = null

        # limbs hang from pivots at shoulder (y=4) / hip (y=2) — studs * STUD
        var limb_defs: Array = [
                [HEAD, Vector3(0, 4.0 + 1.15 * 0.5 - 0.05, 0) * STUD, BOX_HEAD, null],
                [TORSO, Vector3(0, 3.0, 0) * STUD, BOX_TORSO, null],
                [ARM_L, Vector3(-1.5, 3.0, 0) * STUD, BOX_ARM, Vector3(-1.5, 4.0, 0) * STUD],
                [ARM_R, Vector3(1.5, 3.0, 0) * STUD, BOX_ARM, Vector3(1.5, 4.0, 0) * STUD],
                [LEG_L, Vector3(-0.5, 1.0, 0) * STUD, BOX_LEG, Vector3(-0.5, 2.0, 0) * STUD],
                [LEG_R, Vector3(0.5, 1.0, 0) * STUD, BOX_LEG, Vector3(0.5, 2.0, 0) * STUD],
        ]
        for def in limb_defs:
                var index: int = def[0]
                var center: Vector3 = def[1]
                var size: Vector3 = def[2]
                var pivot_pos: Variant = def[3]
                var holder: Node3D
                if pivot_pos != null:
                        var pivot := Node3D.new()
                        pivot.name = "Pivot_%d" % index
                        pivot.position = pivot_pos
                        add_child(pivot)
                        var mesh_node := MeshInstance3D.new()
                        mesh_node.name = "Part_%d" % index
                        mesh_node.position = center - pivot_pos  # limb center relative to its pivot
                        pivot.add_child(mesh_node)
                        holder = pivot
                        _pivots.append(pivot)
                else:
                        var mesh_node := MeshInstance3D.new()
                        mesh_node.name = "Part_%d" % index
                        mesh_node.position = center
                        add_child(mesh_node)
                        holder = mesh_node
                        _pivots.append(mesh_node)
                var mesh := BoxMesh.new()
                mesh.size = size
                var mi: MeshInstance3D
                if pivot_pos != null:
                        mi = holder.get_child(holder.get_child_count() - 1) as MeshInstance3D
                else:
                        mi = holder as MeshInstance3D
                mi.mesh = mesh
                parts.append(mi)
                _part_sizes.append(size)
                _part_aabb.append(AABB(-size * 0.5, size))
                var mount := Node3D.new()
                mount.name = "Mount_%d" % index
                mount.position = Vector3(0.0, 0.0, 0.0)
                holder.add_child(mount)
                # axis-aligned mount glued to the part's center (boxes are unrotated)
                if pivot_pos != null:
                        mount.position = center - pivot_pos
                else:
                        mount.position = Vector3.ZERO
                _mounts.append(mount)
        HEAD_PIVOT_Y = (4.0 + 1.15 * 0.5 - 0.05) * STUD

        _nameplate = _make_nameplate()
        _nameplate.position = Vector3(0.0, RIG_HEIGHT + 0.9 * STUD, 0.0)
        add_child(_nameplate)
        _nameplate.text = _display_name


func _make_nameplate() -> Label3D:
        var label := Label3D.new()
        label.name = "Nameplate"
        label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        label.no_depth_test = true
        label.pixel_size = 0.007
        label.font_size = 40
        label.outline_size = 7
        label.modulate = Color.WHITE
        label.outline_modulate = Color(0, 0, 0, 0.85)
        label.text = _display_name
        return label


func _make_debris_piece(debris: Node3D, index: int) -> RigidBody3D:
        var source: MeshInstance3D = parts[index]
        var piece := RigidBody3D.new()
        piece.name = "BrokenPart_%d" % index
        piece.collision_layer = 2
        piece.collision_mask = 3
        piece.mass = 0.7
        piece.linear_damp = 0.35
        piece.angular_damp = 0.45
        debris.add_child(piece)
        piece.global_transform = source.global_transform
        var mesh_copy := MeshInstance3D.new()
        mesh_copy.name = "Mesh"
        mesh_copy.mesh = source.mesh
        mesh_copy.material_override = source.material_override
        for surface: int in range(source.mesh.get_surface_count()):
                var override := source.get_surface_override_material(surface)
                if override != null:
                        mesh_copy.set_surface_override_material(surface, override)
        piece.add_child(mesh_copy)
        var collision := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = _part_sizes[index]
        collision.shape = shape
        piece.add_child(collision)
        return piece


func _make_material(color: Color) -> StandardMaterial3D:
        var material := StandardMaterial3D.new()
        material.albedo_color = color
        material.roughness = 0.78
        return material


# ---------------------------------------------------------------- rig math

## Transform chain from `node` up to (but excluding) `top`, child-first.
func _chain_transform(node: Node, top: Node) -> Transform3D:
        var xform := Transform3D.IDENTITY
        var current: Node = node
        while current != null and current != top:
                if current is Node3D:
                        xform = (current as Node3D).transform * xform
                current = current.get_parent()
        return xform


## Exact world-space bounds of a mesh: walks every vertex once. The FBX
## part nodes are rotated out of axis alignment by Blender's export, so
## transforming the local AABB would inflate the boxes and float decals.
func _vertex_aabb(mesh: Mesh, xform: Transform3D) -> AABB:
        var faces := mesh.get_faces()
        var box := AABB()
        var first := true
        for vertex in faces:
                var world := xform * vertex
                if first:
                        box = AABB(world, Vector3.ZERO)
                        first = false
                else:
                        box = box.expand(world)
        return box


## Site-compatible part-name matcher: lowercase, drop $tags, separators ->
## spaces, strip trailing digits.
func _match_part_name(node_name: String, mesh_name: String) -> int:
        for source in [node_name, mesh_name]:
                var norm := _norm_part_name(source)
                if norm.is_empty():
                        continue
                for entry in PART_ALIASES:
                        for alias in entry[1]:
                                if norm == alias or norm.begins_with(alias + " "):
                                        return int(entry[0])
        return -1


func _norm_part_name(raw: String) -> String:
        var s := raw.to_lower()
        var out := ""
        var i := 0
        while i < s.length():
                if s[i] == "$":
                        i += 1
                        while i < s.length() and RIG_NAME_CHARS.contains(s[i]):
                                i += 1
                else:
                        out += s[i]
                        i += 1
        out = out.replace("_", " ").replace(".", " ").replace("-", " ")
        var keep: Array[String] = []
        for token in out.split(" ", false):
                while token.length() > 1 and token.right(1) >= "0" and token.right(1) <= "9":
                        token = token.left(token.length() - 1)
                if token != "":
                        keep.append(token)
        return " ".join(keep)
