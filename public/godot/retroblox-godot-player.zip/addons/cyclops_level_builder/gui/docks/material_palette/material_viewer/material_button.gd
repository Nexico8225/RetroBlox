# MIT License
#
# Copyright (c) 2023 Mark McKay
# https://github.com/blackears/cyclopsLevelBuilder
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

@tool
extends PanelContainer
class_name MaterialButton

signal apply_material(mat_bn:MaterialButton)
signal select_material(mat_bn:MaterialButton, selection_type:SelectionList.Type)

#@onready var material_preview_scene:MaterialPreviewScene = %material_preview_scene

@onready var material_name:Label = %MaterialName
@onready var thumbnail_image:TextureRect = %thumbnail_image

@export var thumbnail_generator:MaterialThumbnailGenerator

@export var mesh_type:MaterialPreviewScene.MeshType

@export var selected:bool = false:
	get:
		return selected
	set(value):
		if selected == value:
			return
		selected = value
		update_border()
	
@export var active:bool = false:
	get:
		return active
	set(value):
		if active == value:
			return
		active = value
		update_border()
		
@export var thumbnail_size:Vector2i = Vector2i(128, 128):
	set(v):
		if thumbnail_size == v:
			return
			
		thumbnail_size = v
		
		if is_node_ready():
			thumbnail_image.custom_minimum_size = thumbnail_size

@export_file("*.tres") var material_path:String:
	get:
		return material_path
	set(value):
		if material_path == value:
			return
		
		material_path = value

		if material_local:
			material_local.changed.disconnect(on_material_changed)
		
		material_local = ResourceLoader.load(material_path, "Material")
		
		if material_local:
			material_local.changed.connect(on_material_changed)
		
		dirty = true


@export var group:RadioButtonGroup:
	get:
		return group
	set(value):
		if group == value:
			return
		
		if group != null:
			group.remove_button(self)
		
		group = value
		
		if group != null:
			group.add_button(self)
			
@export var theme_normal:Theme = preload("res://addons/cyclops_level_builder/gui/docks/material_palette/material_viewer/mat_bn_normal_theme.tres")
@export var theme_selected:Theme = preload("res://addons/cyclops_level_builder/gui/docks/material_palette/material_viewer/mat_bn_selected_theme.tres")
@export var theme_active:Theme = preload("res://addons/cyclops_level_builder/gui/docks/material_palette/material_viewer/mat_bn_active_theme.tres")

#var plugin:CyclopsLevelBuilder:
	#get:
		#return plugin
	#set(value):
		#if value == plugin:
			#return
		#
		#plugin = value
		#
		#dirty = true

var dirty:bool = true
var waiting_for_thumbnail:bool = false

var material_local:Material

func on_material_changed():
	print("on_material_changed()", material_path)
	rebuild_thumbnail()
	#dirty = true
	
func rebuild_thumbnail():
	if waiting_for_thumbnail:
		dirty = true
		return
	
	if thumbnail_generator:
		waiting_for_thumbnail = true
		#material_local = ResourceLoader.load(material_path, "Material")
		thumbnail_generator.generate_thumbnail(material_local, mesh_type, thumbnail_size, func(result:ImageTexture):
			thumbnail_image.texture = result
			material_name.text = GeneralUtil.calc_resource_name(material_local)
			tooltip_text = material_path
			waiting_for_thumbnail = false
			dirty = false
		)
		pass
	pass

#func rebuild_thumbnail_old():

	##var rp:EditorResourcePreview = EditorInterface.get_resource_previewer()
	##rp.queue_resource_preview(material_path, self, "resource_preview_callback", null)
	#
	#material_local = ResourceLoader.load(material_path, "Material")
	#material_preview_scene.display_material = material_local
##	material_local = load(material_path)
	#%MaterialName.text = GeneralUtil.calc_resource_name(material_local)
	#tooltip_text = material_path
	
#func rebuild_thumbnail_old2():
	#
	#var rp:EditorResourcePreview = EditorInterface.get_resource_previewer()
	#rp.queue_resource_preview(material_path, self, "resource_preview_callback", null)
	#
	#material_local = ResourceLoader.load(material_path, "Material")
	#material_local = load(material_path)
	#%MaterialName.text = GeneralUtil.calc_resource_name(material_local)
	#tooltip_text = material_path

#func resource_preview_callback(path:String, preview:Texture2D, thumbnail_preview:Texture2D, userdata:Variant):
	##print("Set bn tex ", path)
	#%TextureRect.texture = preview


func _gui_input(event:InputEvent):
	if event is InputEventMouseButton:
		var e:InputEventMouseButton = event
	
		if e.button_index == MOUSE_BUTTON_LEFT:
		
			if e.pressed:
				if e.double_click:
					#apply_material_to_selected()
					apply_material.emit(self)
				else:
					#if group:
						#group.select_thumbnail(self)
					#else:
						#selected = true
						
	#				builder.tool_material_path = material_path
					
					select_material.emit(self, SelectionList.choose_type(e.shift_pressed, e.ctrl_pressed))
					
			get_viewport().set_input_as_handled()

func update_border():
	if active:
		theme = theme_active
	elif selected:
		theme = theme_selected
	else:
		theme = theme_normal

	
# Called when the node enters the scene tree for the first time.
func _ready():
	update_border()
	
	thumbnail_image.custom_minimum_size = thumbnail_size
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	if dirty:
		rebuild_thumbnail()
		#dirty = false
	pass


func on_material_property_edited(property: String)->void:
	var inspector = EditorInterface.get_inspector()
	var object = inspector.get_edited_object()
#	if object is Material:
	if object == material_local:
		dirty = true

#func on_resources_reimported(resources: PackedStringArray):
	##print("--on_resources_reimported ", material_path)
	##print("resoruces ", resources)
	#
	#if resources.has(material_path):
		#rebuild_thumbnail()
	#pass

func _on_bn_rect_pressed() -> void:
	mesh_type = MaterialPreviewScene.MeshType.RECTANGLE
	dirty = true
	#material_preview_scene.mesh_type = MaterialPreviewScene.MeshType.RECTANGLE
	pass # Replace with function body.


func _on_bn_sphere_pressed() -> void:
	mesh_type = MaterialPreviewScene.MeshType.SPHERE
	dirty = true
	#material_preview_scene.mesh_type = MaterialPreviewScene.MeshType.SPHERE
	pass # Replace with function body.


func _on_bn_cube_pressed() -> void:
	mesh_type = MaterialPreviewScene.MeshType.CUBE
	dirty = true
	#material_preview_scene.mesh_type = MaterialPreviewScene.MeshType.CUBE
	pass # Replace with function body.


func _on_bn_torus_pressed() -> void:
	mesh_type = MaterialPreviewScene.MeshType.TORUS
	dirty = true
	#material_preview_scene.mesh_type = MaterialPreviewScene.MeshType.TORUS
	pass # Replace with function body.


func _on_tree_entered() -> void:
#	var efs:EditorFileSystem = EditorInterface.get_resource_filesystem()
#	efs.filesystem_changed.connect(on_filesystem_changed)
#	efs.resources_reimported.connect(on_resources_reimported)
	var inspector = EditorInterface.get_inspector()
	inspector.property_edited.connect(on_material_property_edited)
	#	efs.resources_reload.connect(on_resources_reload)


func _on_tree_exiting() -> void:
#	var efs:EditorFileSystem = EditorInterface.get_resource_filesystem()
#	efs.resources_reimported.disconnect(on_resources_reimported)
	var inspector = EditorInterface.get_inspector()
	if inspector.property_edited.is_connected(on_material_property_edited):
		inspector.property_edited.disconnect(on_material_property_edited)
#	pass # Replace with function body.
