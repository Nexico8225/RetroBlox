class_name LocalPlayer
extends CharacterBody3D
# Controls local player movement, capsule collision, 1-2 stud stepping, ladder climbing, health, and voice indicator.
signal health_changed(health: float, max_health: float)
signal health_depleted
signal touched_group(group: String, node: Node3D)
signal land_impact(speed: float)
signal item_picked_up(item_data: Dictionary)

const STUD := 1.0

const WALK_SPEED := 16.0 * STUD
const JUMP_SPEED := 50.0 * STUD
const GRAVITY := 196.2 * STUD
const ACCEL_GROUND := 145.0 * STUD
const ACCEL_AIR := 62.0 * STUD
const BRAKE_GROUND := 170.0 * STUD
const COYOTE_TIME := 0.08
const JUMP_BUFFER := 0.12

const MAX_STEP := 2.0 * STUD
const MIN_STEP := 0.05 * STUD
const STEP_FORWARD := 0.6 * STUD
const STEP_PROBE_AHEAD := 1.7 * STUD
const FLOOR_SNAP := 0.5 * STUD
const STEP_RISE_SPEED := 22.0 * STUD

const CLIMB_SPEED := 11.0 * STUD
const LADDER_JUMP := 24.0 * STUD
const LADDER_DISMOUNT := 0.25

const CLIMB_FACE_START := 0.35
const CLIMB_FACE_STAY := 0.20
const HUG_PRESSURE := 1.5 * STUD

const LAND_SOUND_FALL := 12.0 * STUD
const FALL_WIND_SPEED := 34.0 * STUD

const MAX_HEALTH := 100.0
const REGEN_DELAY := 5.0
const REGEN_RATE := 1.0
const FALL_SAFE_HEIGHT := 45.0
const FALL_DMG_PER_STUD := 4.0
const BOUNCE_POWER := 72.0 * STUD
const BOUNCE_COOLDOWN := 0.35

const AvatarRigScript := preload("res://scripts/player/avatar_rig.gd")
const AvatarDresserScript := preload("res://scripts/player/avatar_dresser.gd")
const ChatBubbleScript := preload("res://scripts/player/chat_bubble.gd")
const RetroUI := preload("res://scripts/ui/retro_theme.gd")
const ITEM_SPAWNER_SCRIPT_PATH := "res://scripts/world/item_spawner.gd"

enum ClimbKind { NONE, LADDER }

@export_group("Character Physics & Movement")
## Base walk speed in studs/second (classic Roblox default: 16.0).
@export var walk_speed: float = 16.0 * STUD
## Jump launch power (classic Roblox default: 50.0).
@export var jump_power: float = 50.0 * STUD
## Downward gravity acceleration in studs/s² (classic Roblox default: 196.2).
@export var gravity: float = 196.2 * STUD

@export_group("Climbing & Ledges")
## Master toggle for whether the player can climb.
@export var can_climb: bool = true
## Master toggle for stepping up onto ledges and curbs.
@export var can_step_up: bool = true
## Maximum step-up height in studs (e.g. 1.0, 1.5, or 2.0 studs).
@export var max_step_studs: float = 2.0:
	set(v):
		max_step_studs = maxf(v, 0.05)
## Minimum step-up height in studs (default: 0.05 studs).
@export var min_step_studs: float = 0.05:
	set(v):
		min_step_studs = maxf(v, 0.01)
## Whether player can climb platform edges and ledges (0.1 to max_step_studs high).
@export var can_climb_ledges: bool = true
## Ladder & ledge climbing speed in studs/second.
@export var climb_speed: float = 11.0 * STUD

@export_group("Health & Fall Damage")
## Maximum health.
@export var max_health: float = 100.0
## Health points regenerated per second (classic Roblox: 1.0 HP/s).
@export var health_regen_rate: float = 1.0
## Delay in seconds after taking damage before health starts regenerating (classic Roblox: 1.0s).
@export var health_regen_delay: float = 1.0
## Whether high falls cause damage (classic Roblox has no fall damage: false).
@export var enable_fall_damage: bool = false
## Safe drop height in studs before fall damage is applied (if enabled).
@export var fall_safe_height: float = 45.0
## Damage dealt per stud fallen beyond the safe height (if enabled).
@export var fall_damage_per_stud: float = 4.0
## Whether the player loses their inventory/equipped items when they die (default: On / true).
@export var lose_item_when_dead: bool = true

@export_group("Custom Walk Animation")
## Drag-and-drop a custom Animation resource here to override the default walk
@export var custom_walk_anim: Animation = null:
	set(v):
		custom_walk_anim = v
		if avatar != null and avatar.has_method("set_custom_walk"):
			avatar.call("set_custom_walk", v)
## Set to true to drive animations via Godot AnimationPlayer
@export var use_animation_player := false
## Clip name in AnimationPlayer to play when walking
@export var walk_clip_name: StringName = &"Walk"

@export_group("Editable Animations")
@export var walk_arm_swing := 0.82
@export var walk_leg_swing := 0.78
@export var walk_cycle_speed := 8.5
@export var jump_arm_angle := 2.75
@export var jump_leg_spread := 0.28
@export var climb_swing := 0.65

var display_name := "Guest"
var avatar: Node3D
var bubble: ChatBubble
var voice_indicator: Sprite3D
var voice_player: AudioStreamPlayer3D
var alive := true
var health := MAX_HEALTH
var heading := 0.0
var grounded := false
var climbing := false
var spawn_point := Transform3D()
var wants_chat_input := false
var dust_enabled := true

var _air_time := 0.0
var _is_jumping := false
var _regen_wait := 0.0
var _falling := false
var _fall_peak_y := 0.0
var _ladder_areas: Array[Node3D] = []
var _ladder_sensor: Area3D = null
var _touch_sensor: Area3D = null
var _climb_kind: int = ClimbKind.NONE
var _climb_face := Vector3.ZERO
var _coyote := 0.0
var _jump_buffer_left := 0.0
var _rise_left := 0.0
var _step_dir := Vector3.ZERO
var _bounce_cd := 0.0
var _time := 0.0
var _settings: Node = null
var _steps_loop: AudioStreamPlayer3D
var _climb_loop: AudioStreamPlayer3D
var _fall_loop: AudioStreamPlayer3D
var _ladder_dismount := 0.0
var _input_shiftlock := false
var _input_first_person := false
var _last_vy := 0.0
var _initialized_nodes := false
var _tex_voice_on: Texture2D
var _tex_voice_muted: Texture2D
var _tex_voice_levels: Array[Texture2D] = []

var _speed_boost_timer := 0.0
var _speed_boost_mult := 1.65
var _speed_remove_on_block := false
var _gravity_boost_timer := 0.0
var _gravity_boost_mult := 0.42
var _jump_boost_mult := 1.25
var _gravity_remove_on_block := false
var _equipped_item: Dictionary = {}
var _carpet_visual: Node3D = null
var _big_head_timer: float = 0.0
var _lunge_float_timer: float = 0.0
# Flat lunge / grapple dash state
var _lunge_dash_timer: float = 0.0
var _lunge_dash_dir: Vector3 = Vector3.ZERO
var _lunge_dash_speed: float = 0.0
var _lunge_rise_left: float = 0.0
var _lunge_rise_speed: float = 0.0
var _lunge_vert_lock: bool = true
var _surge_timer: float = 0.0
var _surge_drain: float = 0.0
var _ghost_timer: float = 0.0
var _floor_snap_default: float = 2.1 * STUD
var _burn_timer: float = 0.0
var _burn_dps: float = 0.0
var _burn_tick_accum: float = 0.0
var _slow_timer: float = 0.0
var _slow_mult: float = 1.0
var in_safe_zone: bool = false
var _seated_chair: Node3D = null
var _chair_sit_cooldown: float = 0.0
var _slide_timer: float = 0.0
var _slide_dir: Vector3 = Vector3.ZERO
var _climb_grace := 0.0
var _active_climb_speed := CLIMB_SPEED
var _touching_damage: Array[Node3D] = []
var _touching_heal: Array[Node3D] = []
var _damage_tick_cd := 0.0
var _heal_tick_cd := 0.0


func _init() -> void:
	name = "LocalPlayer"
	collision_layer = 4
	collision_mask = 1
	floor_snap_length = 2.1 * STUD
	_floor_snap_default = floor_snap_length
	floor_max_angle = deg_to_rad(65.0)
	floor_block_on_wall = false
	floor_constant_speed = true
	floor_stop_on_slope = true


func _ensure_nodes() -> void:
	if _initialized_nodes:
		return
	_initialized_nodes = true

	_tex_voice_levels.clear()
	for i in range(11):
		_tex_voice_levels.append(RetroUI.load_png_safe("res://assets/ui/voice_levels/level_%d.png" % i))
	_tex_voice_muted = RetroUI.load_png_safe("res://assets/ui/voice_bubble_muted.png")
	_tex_voice_on = _tex_voice_levels[0] if not _tex_voice_levels.is_empty() else RetroUI.load_png_safe("res://assets/ui/voice_bubble.png")

	var col := get_node_or_null("CollisionShape3D") as CollisionShape3D
	if col == null:
		col = CollisionShape3D.new()
		col.name = "CollisionShape3D"
		add_child(col)
	if not (col.shape is CapsuleShape3D):
		var cap := CapsuleShape3D.new()
		cap.radius = 1.0 * STUD
		cap.height = 5.0 * STUD
		col.shape = cap
	col.position = Vector3(0.0, 2.5 * STUD, 0.0)

	avatar = get_node_or_null("Avatar") as Node3D
	if avatar == null or not avatar.has_method("animate"):
		if avatar != null:
			avatar.queue_free()
		avatar = AvatarRigScript.new()
		avatar.name = "Avatar"
		add_child(avatar)
	_sync_avatar_anim_exports()

	bubble = get_node_or_null("ChatBubble") as ChatBubble
	if bubble == null:
		bubble = ChatBubbleScript.new()
		bubble.name = "ChatBubble"
		add_child(bubble)

	voice_indicator = get_node_or_null("VoiceIndicator") as Sprite3D
	if voice_indicator == null:
		voice_indicator = Sprite3D.new()
		voice_indicator.name = "VoiceIndicator"
		add_child(voice_indicator)
	voice_indicator.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	voice_indicator.no_depth_test = true
	voice_indicator.pixel_size = 0.0075
	voice_indicator.shaded = false
	voice_indicator.position = Vector3(0.0, 6.55 * STUD, 0.0)
	voice_indicator.texture = _tex_voice_on
	voice_indicator.modulate = Color(1.0, 1.0, 1.0, 0.98)

	if get_node_or_null("LadderSensor") == null:
		_setup_ladder_sensor()
	if get_node_or_null("TouchSensor") == null:
		_setup_touch_sensor()


func _sync_avatar_anim_exports() -> void:
	if avatar == null or not is_instance_valid(avatar):
		return
	avatar.set("walk_arm_swing", walk_arm_swing)
	avatar.set("walk_leg_swing", walk_leg_swing)
	avatar.set("walk_cycle_speed", walk_cycle_speed)
	avatar.set("jump_arm_angle", jump_arm_angle)
	avatar.set("jump_leg_spread", jump_leg_spread)
	avatar.set("climb_swing", climb_swing)
	avatar.set("custom_walk_anim", custom_walk_anim)
	avatar.set("use_animation_player", use_animation_player)
	avatar.set("walk_clip_name", walk_clip_name)


func set_custom_walk(anim: Animation) -> void:
	custom_walk_anim = anim
	if avatar != null and avatar.has_method("set_custom_walk"):
		avatar.call("set_custom_walk", anim)


func _ready() -> void:
	_ensure_nodes()
	_apply_project_settings()
	_settings = get_node_or_null("/root/Settings")
	_setup_character_sfx()
	var vc: Node = get_node_or_null("/root/VoiceChat")
	if vc != null:
		if vc.has_method("make_voice_player_3d"):
			voice_player = vc.call("make_voice_player_3d", self)
		if vc.has_signal("speaking_changed") and not vc.is_connected("speaking_changed", _on_voice_speaking_changed):
			vc.connect("speaking_changed", _on_voice_speaking_changed)
		if vc.has_signal("mute_changed") and not vc.is_connected("mute_changed", _on_voice_mute_changed):
			vc.connect("mute_changed", _on_voice_mute_changed)
	if _settings != null and not _settings.changed.is_connected(_on_setting_changed):
		_settings.changed.connect(_on_setting_changed)
	_refresh_voice_bubble(0.0)


func _on_setting_changed(key: String, _val: Variant) -> void:
	if key in ["voice_enabled", "voice_muted"]:
		_refresh_voice_bubble(0.0)


func _apply_project_settings() -> void:
	if ProjectSettings.has_setting("player/movement/walk_speed"):
		walk_speed = float(ProjectSettings.get_setting("player/movement/walk_speed")) * STUD
	if ProjectSettings.has_setting("player/movement/jump_power"):
		jump_power = float(ProjectSettings.get_setting("player/movement/jump_power")) * STUD
	if ProjectSettings.has_setting("player/movement/gravity"):
		gravity = float(ProjectSettings.get_setting("player/movement/gravity")) * STUD
	if ProjectSettings.has_setting("player/health/max_health"):
		max_health = float(ProjectSettings.get_setting("player/health/max_health"))
		health = max_health
	if ProjectSettings.has_setting("player/health/health_regen_rate"):
		health_regen_rate = float(ProjectSettings.get_setting("player/health/health_regen_rate"))
	if ProjectSettings.has_setting("player/health/fall_damage_enabled"):
		enable_fall_damage = bool(ProjectSettings.get_setting("player/health/fall_damage_enabled"))
	if ProjectSettings.has_setting("player/features/lose_item_when_dead"):
		lose_item_when_dead = bool(ProjectSettings.get_setting("player/features/lose_item_when_dead"))


func _on_voice_mute_changed(_muted: bool) -> void:
	_refresh_voice_bubble(0.0)


func _on_voice_speaking_changed(_speaking: bool, level: float) -> void:
	_refresh_voice_bubble(level)


func _refresh_voice_bubble(level: float) -> void:
	if voice_indicator == null or not is_instance_valid(voice_indicator):
		return
	var vc_enabled := true if _settings == null else bool(_settings.get("voice_enabled"))
	if not vc_enabled or _input_first_person or not alive:
		voice_indicator.visible = false
		return
	var vc: Node = get_node_or_null("/root/VoiceChat")
	var muted := false if vc == null else bool(vc.call("is_muted"))
	var speaking := false if vc == null else bool(vc.call("is_speaking"))
	if muted or (not speaking and level <= 0.02):
		voice_indicator.visible = false
		return
	voice_indicator.visible = true
	var idx := clampi(int(round(level * 10.0)), 0, 10)
	if idx < _tex_voice_levels.size():
		voice_indicator.texture = _tex_voice_levels[idx]
	var s := 1.0 + clampf(level * 0.16, 0.0, 0.16)
	voice_indicator.scale = Vector3(s, s, s)


func _setup_character_sfx() -> void:
	var sfx: Node = get_node_or_null("/root/Sfx")
	if sfx == null:
		return
	_steps_loop = sfx.call("make_loop_3d", "Footsteps", self)
	_climb_loop = sfx.call("make_loop_3d", "ClimbLoop", self)
	_fall_loop = sfx.call("make_loop_3d", "FallingLoop", self)
	if _climb_loop != null:
		_climb_loop.pitch_scale = 1.25


func setup(p_name: String) -> void:
	_ensure_nodes()
	display_name = p_name
	avatar.call("setup", p_name)


func show_bubble(message: String) -> void:
	_ensure_nodes()
	bubble.show_text(message)


func dress(api, payload: Dictionary) -> void:
	_ensure_nodes()
	if payload.is_empty():
		return
	await AvatarDresserScript.apply(api, avatar, payload)


func _physics_process(delta: float) -> void:
	_time += delta
	if _bounce_cd > 0.0:
		_bounce_cd -= delta
	_update_loops()


func drive(delta: float, direction: Vector2, cam_yaw: float, just_pressed: bool, use_shiftlock: bool, first_person := false, jump_held := false) -> void:
	_ensure_nodes()
	if not alive:
		return
	_sync_avatar_anim_exports()
	_input_shiftlock = use_shiftlock
	if _input_first_person != first_person:
		_input_first_person = first_person
		_refresh_voice_bubble(0.0)
	var wish := Vector3(direction.x, 0.0, direction.y).rotated(Vector3.UP, cam_yaw)
	if wish.length() > 1.0:
		wish = wish.normalized()
	if wish.length_squared() > 0.005:
		_step_dir = wish.normalized()

	var hop_on := (_settings == null) or bool(_settings.get("bunny_hop"))
	if just_pressed:
		_jump_buffer_left = JUMP_BUFFER
	elif jump_held and hop_on and (grounded or _coyote > 0.0) and _climb_kind == ClimbKind.NONE:
		_jump_buffer_left = JUMP_BUFFER
	elif _jump_buffer_left > 0.0:
		_jump_buffer_left -= delta
	if grounded:
		_coyote = COYOTE_TIME
	elif _coyote > 0.0:
		_coyote -= delta

	if _ladder_dismount > 0.0:
		_ladder_dismount -= delta

	if _speed_boost_timer > 0.0:
		_speed_boost_timer -= delta
	if _gravity_boost_timer > 0.0:
		_gravity_boost_timer -= delta
	if _surge_timer > 0.0:
		_surge_timer = maxf(0.0, _surge_timer - delta)
		if _surge_drain > 0.0:
			hurt(_surge_drain * delta)
		if _surge_timer <= 0.0:
			_surge_drain = 0.0
	if _ghost_timer > 0.0:
		_ghost_timer = maxf(0.0, _ghost_timer - delta)
		if _ghost_timer <= 0.0:
			set_ghost_alpha(1.0)

	var auto_rot_ladder := true if _settings == null else bool(_settings.get("ladder_auto_rotate"))
	if can_climb:
		_update_climb(wish, delta, auto_rot_ladder)
		if _climb_kind != ClimbKind.NONE and auto_rot_ladder:
			heading = lerp_angle(heading, atan2(-_climb_face.x, -_climb_face.z), 1.0 - exp(-22.0 * delta))
	else:
		_stop_climb()
	if not (_climb_kind != ClimbKind.NONE and auto_rot_ladder):
		if use_shiftlock or first_person:
			heading = cam_yaw
		elif wish.length_squared() > 0.005:
			heading = lerp_angle(heading, atan2(-wish.x, -wish.z), 1.0 - exp(-18.0 * delta))

	if _climb_kind != ClimbKind.NONE:
		_drive_climb(wish, delta)
	else:
		_drive_ground_air(wish, delta)
		_perform_step_up(wish, delta)

	move_and_slide()
	if _climb_kind == ClimbKind.NONE:
		_perform_step_up(wish, delta)
	for i in range(get_slide_collision_count()):
		var sc := get_slide_collision(i)
		if sc != null and sc.get_collider() is Node3D:
			_on_touch_entered(sc.get_collider() as Node3D)
	if _touch_sensor != null and is_instance_valid(_touch_sensor):
		for b in _touch_sensor.get_overlapping_bodies():
			if b is Node3D:
				_on_touch_entered(b as Node3D)
	var was_grounded := grounded
	grounded = is_on_floor()
	if grounded:
		_air_time = 0.0
		_is_jumping = false
		if not was_grounded and _last_vy < -LAND_SOUND_FALL:
			_play_land_sound()
			_dust(clampf(-_last_vy / (40.0 * STUD), 1.0, 1.8))
			land_impact.emit(-_last_vy)
	else:
		_air_time += delta

	_update_fall_damage()
	_update_brick_ticks(delta)
	if _regen_wait > 0.0:
		_regen_wait -= delta
	elif health < max_health:
		health = minf(health + health_regen_rate * delta, max_health)
		health_changed.emit(health, max_health)
	_last_vy = velocity.y
	avatar.rotation.y = heading
	if _ladder_sensor != null and is_instance_valid(_ladder_sensor):
		_ladder_sensor.rotation.y = heading
	var hspeed := Vector2(velocity.x, velocity.z).length()
	var anim_speed := absf(velocity.y) if climbing else hspeed
	var anim_grounded := grounded or (not _is_jumping and _air_time < 0.20 and velocity.y > -14.0 * STUD)
	avatar.call("animate", delta, anim_speed, anim_grounded, climbing)


static func _node_float(node: Object, prop_name: String, meta_name: String, default_val: float) -> float:
	if node == null or not is_instance_valid(node):
		return default_val
	var v: Variant = node.get(prop_name)
	if v is float or v is int:
		return float(v)
	if node.has_meta(meta_name):
		return float(node.get_meta(meta_name, default_val))
	return default_val


func _update_brick_ticks(delta: float) -> void:
	if not alive:
		return
	if _touch_sensor != null and is_instance_valid(_touch_sensor):
		var overlapping := _touch_sensor.get_overlapping_bodies()
		for i in range(_touching_damage.size() - 1, -1, -1):
			var b := _touching_damage[i]
			if not is_instance_valid(b) or not overlapping.has(b):
				_touching_damage.remove_at(i)
		for i in range(_touching_heal.size() - 1, -1, -1):
			var b := _touching_heal[i]
			if not is_instance_valid(b) or not overlapping.has(b):
				_touching_heal.remove_at(i)
	else:
		for i in range(_touching_damage.size() - 1, -1, -1):
			if not is_instance_valid(_touching_damage[i]):
				_touching_damage.remove_at(i)
		for i in range(_touching_heal.size() - 1, -1, -1):
			if not is_instance_valid(_touching_heal[i]):
				_touching_heal.remove_at(i)
	if _damage_tick_cd > 0.0:
		_damage_tick_cd -= delta
	elif not _touching_damage.is_empty():
		var brick := _touching_damage[0]
		if bool(brick.get("continuous_damage")):
			var dmg := _node_float(brick, "damage_amount", "damage", 20.0)
			var cd := _node_float(brick, "damage_cooldown", "damage_cooldown", 0.55)
			hurt(dmg)
			_damage_tick_cd = cd
			touched_group.emit("damage", brick)
	if _heal_tick_cd > 0.0:
		_heal_tick_cd -= delta
	elif not _touching_heal.is_empty():
		var hbrick := _touching_heal[0]
		if bool(hbrick.get("continuous_heal")):
			var h_amt := _node_float(hbrick, "heal_amount", "heal", 15.0)
			var h_cd := _node_float(hbrick, "heal_cooldown", "heal_cooldown", 0.45)
			if health < MAX_HEALTH:
				heal(h_amt)
			_heal_tick_cd = h_cd
			touched_group.emit("heal", hbrick)


func _prune_ladder_contacts() -> void:
	_ladder_areas.clear()
	if _ladder_sensor != null and is_instance_valid(_ladder_sensor):
		for b in _ladder_sensor.get_overlapping_bodies():
			if b is Node3D and b != self and _is_climbable_node(b as Node3D):
				if not _ladder_areas.has(b):
					_ladder_areas.append(b as Node3D)
		for a in _ladder_sensor.get_overlapping_areas():
			if a is Node3D and a != self and _is_climbable_node(a as Node3D):
				if not _ladder_areas.has(a):
					_ladder_areas.append(a as Node3D)
	for i in range(get_slide_collision_count()):
		var sc := get_slide_collision(i)
		if sc != null and sc.get_collider() is Node3D:
			var col_node := sc.get_collider() as Node3D
			if col_node != self and _is_climbable_node(col_node) and not _ladder_areas.has(col_node):
				_ladder_areas.append(col_node)
	# Direct torso-level raycast straight forward (ensures ladder in front of chest is detected
	# even when capsule collider halts movement before torso mesh touches)
	var space := get_world_3d().direct_space_state
	if space != null:
		var forward := Vector3(-sin(heading), 0.0, -cos(heading)).normalized()
		var torso_origin := global_position + Vector3.UP * (2.6 * STUD)
		var query := PhysicsRayQueryParameters3D.create(torso_origin, torso_origin + forward * (1.6 * STUD), collision_mask, [get_rid()])
		var hit := space.intersect_ray(query)
		if not hit.is_empty():
			var col_obj: Variant = hit.get("collider", null)
			if col_obj is Node3D and _is_climbable_node(col_obj as Node3D):
				if not _ladder_areas.has(col_obj):
					_ladder_areas.append(col_obj as Node3D)


func _update_climb(wish: Vector3, _delta: float, _auto_rot_ladder: bool) -> void:
	_prune_ladder_contacts()

	if _climb_kind != ClimbKind.NONE and grounded and wish.dot(_climb_face) < -0.15:
		_stop_climb()
		return

	if _climb_kind == ClimbKind.LADDER:
		if not _ladder_areas.is_empty():
			var lad: Node3D = _nearest_ladder()
			_active_climb_speed = _node_float(lad, "climb_speed", "climb_speed", climb_speed)
			var face := _toward(lad)
			if face != Vector3.ZERO and face.dot(_climb_face) > -0.5:
				_climb_face = face
			_climb_grace = 0.08
			return
		# Left the ladder volume at the top: step cleanly onto the top platform without launching into the sky
		var was_climbing_up := velocity.y > 0.0
		var f := _climb_face
		_stop_climb()
		velocity.y = 0.0
		if was_climbing_up:
			_try_mantle()
			velocity.x = f.x * walk_speed * 0.7
			velocity.z = f.z * walk_speed * 0.7
		return

	if _ladder_dismount > 0.0:
		return

	# ONLY Ladders and Trusses are climbable — walls and blocks are NEVER climbable!
	if not _ladder_areas.is_empty():
		var lad2: Node3D = _nearest_ladder()
		var face_to_lad := _toward(lad2)
		if face_to_lad != Vector3.ZERO:
			var forward := Vector3(-sin(heading), 0.0, -cos(heading))
			var moving_into := wish.dot(face_to_lad) > 0.05 or (not grounded and forward.dot(face_to_lad) >= 0.0)
			if moving_into:
				_climb_kind = ClimbKind.LADDER
				_climb_face = face_to_lad
				_active_climb_speed = _node_float(lad2, "climb_speed", "climb_speed", climb_speed)
				_climb_grace = 0.08
				return


func _try_mantle() -> bool:
	var f := Vector3(_climb_face.x, 0.0, _climb_face.z).normalized()
	if f.length_squared() < 0.01:
		f = Vector3(-sin(heading), 0.0, -cos(heading)).normalized()
	var space := get_world_3d().direct_space_state
	if space == null:
		velocity.y = 0.0
		_stop_climb()
		return false
	var over := global_position + f * (1.1 * STUD) + Vector3.UP * (1.4 * STUD)
	var down := PhysicsRayQueryParameters3D.create(over, over + Vector3.DOWN * (2.4 * STUD), collision_mask, [get_rid()])
	var hit := space.intersect_ray(down)
	if not hit.is_empty():
		var hit_y: float = float(hit["position"].y)
		var target_pos := global_position + f * (0.9 * STUD)
		target_pos.y = hit_y + 0.02 * STUD
		var test_xform := Transform3D(global_transform.basis, target_pos)
		if not test_move(test_xform, Vector3.ZERO):
			global_position = target_pos
	velocity.y = 0.0
	_stop_climb()
	grounded = true
	return true


func _drive_climb(wish: Vector3, _delta: float) -> void:
	var up_amount := wish.dot(_climb_face)
	if _jump_buffer_left > 0.0:
		_jump_buffer_left = 0.0
		_ladder_dismount = LADDER_DISMOUNT
		velocity.y = LADDER_JUMP * 0.65
		velocity.x = -_climb_face.x * 7.0 * STUD
		velocity.z = -_climb_face.z * 7.0 * STUD
		grounded = false
		_stop_climb()
		if avatar != null and avatar.has_method("on_jump"):
			avatar.call("on_jump")
		return
	var spd := _active_climb_speed if _active_climb_speed > 0.0 else climb_speed
	if up_amount > 0.12:
		velocity.y = spd
		climbing = true
	elif up_amount < -0.12:
		velocity.y = -spd
		climbing = true
	else:
		velocity.y = 0.0
		climbing = true
	velocity.x = _climb_face.x * HUG_PRESSURE
	velocity.z = _climb_face.z * HUG_PRESSURE


func _stop_climb() -> void:
	_climb_kind = ClimbKind.NONE
	climbing = false
	_climb_grace = 0.0


func _nearest_ladder() -> Node3D:
	var best: Node3D = null
	var best_d := INF
	for lad in _ladder_areas:
		if not is_instance_valid(lad):
			continue
		var d := lad.global_position.distance_squared_to(global_position)
		if d < best_d:
			best_d = d
			best = lad
	return best


func _toward(lad: Node3D) -> Vector3:
	if lad == null or not is_instance_valid(lad):
		return Vector3.ZERO
	var to := lad.global_position - global_position
	to.y = 0.0
	if to.length_squared() < 0.0016:
		return Vector3(-sin(heading), 0.0, -cos(heading))
	return to.normalized()


func _drive_ground_air(wish: Vector3, delta: float) -> void:
	var eq_id: String = String(_equipped_item.get("id", ""))
	if eq_id == "flying_carpet":
		var f_spd: float = float(_equipped_item.get("fly_speed", 38.0)) * STUD
		var a_spd: float = float(_equipped_item.get("ascend_speed", 24.0)) * STUD
		velocity.x = move_toward(velocity.x, wish.x * f_spd, ACCEL_GROUND * delta)
		velocity.z = move_toward(velocity.z, wish.z * f_spd, ACCEL_GROUND * delta)
		var vy: float = 0.0
		if Input.is_action_pressed("jump") or Input.is_key_pressed(KEY_SPACE):
			vy += a_spd
		if Input.is_key_pressed(KEY_C) or Input.is_key_pressed(KEY_CTRL) or Input.is_key_pressed(KEY_Q):
			vy -= a_spd
		velocity.y = move_toward(velocity.y, vy, ACCEL_GROUND * delta)
		_fall_peak_y = global_position.y
		return

	if eq_id == "heal_coil" and alive and health < max_health:
		var h_rate: float = float(_equipped_item.get("heal_per_second", 16.0))
		heal(h_rate * delta)

	if _burn_timer > 0.0 and alive:
		_burn_timer = maxf(0.0, _burn_timer - delta)
		_burn_tick_accum += delta
		if _burn_tick_accum >= 0.25:
			hurt(_burn_dps * _burn_tick_accum)
			_burn_tick_accum = 0.0

	if _slow_timer > 0.0:
		_slow_timer = maxf(0.0, _slow_timer - delta)
		if _slow_timer <= 0.0:
			_slow_mult = 1.0

	var accel: float = ACCEL_GROUND if is_on_floor() else ACCEL_AIR
	var spd_mult: float = get_speed_multiplier()
	var grav_mult: float = get_gravity_multiplier()
	var jmp_mult: float = get_jump_multiplier()

	if _lunge_dash_timer > 0.0:
		_drive_lunge_dash(delta)
		return

	if _chair_sit_cooldown > 0.0:
		_chair_sit_cooldown = maxf(0.0, _chair_sit_cooldown - delta)

	if _seated_chair != null and is_instance_valid(_seated_chair):
		if _jump_buffer_left > 0.0:
			_jump_buffer_left = 0.0
			_seated_chair = null
			_chair_sit_cooldown = 1.0
			velocity.y = jump_power * jmp_mult
			grounded = false
			_is_jumping = true
			if avatar != null and avatar.has_method("play_emote"):
				avatar.call("play_emote", "")
			if avatar != null and avatar.has_method("on_jump"):
				avatar.call("on_jump")
			return
		global_position = _seated_chair.global_position + Vector3(0.0, 0.55 * STUD, 0.0)
		velocity = Vector3.ZERO
		heading = _seated_chair.global_rotation.y
		grounded = true
		if avatar != null and avatar.has_method("play_emote"):
			avatar.call("play_emote", "sit")
		return

	if _slide_timer > 0.0:
		_slide_timer = maxf(0.0, _slide_timer - delta)
		velocity.x = _slide_dir.x * 34.0 * STUD
		velocity.z = _slide_dir.z * 34.0 * STUD
	else:
		var target: Vector3 = wish * (walk_speed * spd_mult)
		if wish.length_squared() < 0.005 and is_on_floor():
			velocity.x = move_toward(velocity.x, 0.0, BRAKE_GROUND * delta)
			velocity.z = move_toward(velocity.z, 0.0, BRAKE_GROUND * delta)
		else:
			velocity.x = move_toward(velocity.x, target.x, accel * delta)
			velocity.z = move_toward(velocity.z, target.z, accel * delta)

	if not is_on_floor():
		velocity.y -= gravity * grav_mult * delta
	elif velocity.y < 0.0:
		velocity.y = 0.0
	var can_jump: bool = is_on_floor() or _coyote > 0.0 or is_on_wall()
	if _jump_buffer_left > 0.0 and can_jump:
		_jump_buffer_left = 0.0
		_coyote = 0.0
		_is_jumping = true
		grounded = false
		velocity.y = jump_power * jmp_mult
		_play_jump_sound()
		_dust()
		if avatar != null and avatar.has_method("on_jump"):
			avatar.call("on_jump")


func _perform_step_up(wish: Vector3, _delta: float) -> void:
	if _lunge_dash_timer > 0.0:
		# Never step-snap mid-lunge: the dash must keep its exact height.
		return
	if not can_step_up or not alive:
		return
	if wish.length_squared() < 0.005:
		return
	var move_dir := wish.normalized()
	var step_h := maxf(max_step_studs, 0.08) * STUD

	# 1. Probing headroom: ensure ceiling above is clear
	if test_move(global_transform, Vector3.UP * (step_h + 0.1 * STUD)):
		return

	var space := get_world_3d().direct_space_state
	if space == null:
		return

	# Torso-level wall check: ensure no vertical wall in front at chest height (stairs have open air above them; walls do not)
	var torso_from := global_position + Vector3.UP * (2.5 * STUD)
	var torso_to := torso_from + move_dir * (1.6 * STUD)
	var wall_query := PhysicsRayQueryParameters3D.create(torso_from, torso_to, collision_mask, [get_rid()])
	var wall_hit := space.intersect_ray(wall_query)
	if not wall_hit.is_empty():
		var wnorm: Vector3 = wall_hit.get("normal", Vector3.UP)
		if absf(wnorm.y) < 0.4:
			return

	# 2. Probe downward across multiple offsets to find step/ledge top surface
	var found_step := false
	var target_y := global_position.y
	var best_dist := 0.0

	for dist_mult: float in [0.65, 1.05, 1.45]:
		var probe_x := move_dir * (dist_mult * STUD)
		var from_pt := global_position + probe_x + Vector3.UP * (step_h + 0.15 * STUD)
		var to_pt := global_position + probe_x + Vector3.DOWN * (0.25 * STUD)
		var ray := PhysicsRayQueryParameters3D.create(from_pt, to_pt, collision_mask, [get_rid()])
		var hit := space.intersect_ray(ray)
		if not hit.is_empty():
			var hit_norm: Vector3 = hit.get("normal", Vector3.UP)
			if hit_norm.y > 0.6:
				var hit_pos: Vector3 = hit["position"]
				var h_diff := hit_pos.y - global_position.y
				if h_diff >= (min_step_studs * STUD) and h_diff <= (step_h + 0.08 * STUD):
					target_y = hit_pos.y
					best_dist = dist_mult * STUD
					found_step = true
					break

	if not found_step:
		return

	# 3. Test if capsule can stand at target step position
	var target_pos := global_position + move_dir * (best_dist * 0.75)
	target_pos.y = target_y
	var test_xform := Transform3D(global_transform.basis, target_pos)
	if test_move(test_xform, Vector3.UP * (2.8 * STUD)):
		return
	if not test_move(test_xform, Vector3.DOWN * (0.05 * STUD)):
		global_position = target_pos
		if velocity.y < 0.0:
			velocity.y = 0.0
		apply_floor_snap()
		grounded = true


func _dust(strength := 1.0) -> void:
	if not dust_enabled or not alive:
		return
	if _settings != null and int(_settings.get("graphics_quality")) <= 1:
		return
	var world := get_parent()
	if world == null or not is_inside_tree():
		return
	var puff := CPUParticles3D.new()
	puff.name = "DustPuff"
	puff.one_shot = true
	puff.emitting = true
	puff.amount = int(10 * strength)
	puff.lifetime = 0.45
	puff.explosiveness = 0.92
	puff.direction = Vector3.UP
	puff.spread = 75.0
	puff.initial_velocity_min = 2.0 * strength * STUD
	puff.initial_velocity_max = 5.0 * STUD * strength
	puff.gravity = Vector3(0.0, -7.0 * STUD, 0.0)
	puff.scale_amount_min = 0.16 * STUD
	puff.scale_amount_max = 0.34 * STUD
	var ring := SphereMesh.new()
	ring.radius = 0.5
	ring.height = 1.0
	ring.radial_segments = 6
	ring.rings = 3
	puff.mesh = ring
	puff.color = Color(0.92, 0.9, 0.84, 0.8)
	world.add_child(puff)
	puff.global_position = global_position + Vector3(0.0, 0.25 * STUD, 0.0)
	var timer := get_tree().create_timer(1.0)
	timer.timeout.connect(puff.queue_free)


func _update_fall_damage() -> void:
	if not alive:
		return
	if grounded:
		if _falling:
			_falling = false
			if enable_fall_damage:
				var drop := _fall_peak_y - global_position.y
				var drop_studs := drop / STUD
				if drop_studs > fall_safe_height:
					hurt((drop_studs - fall_safe_height) * fall_damage_per_stud)
	else:
		_fall_peak_y = maxf(_fall_peak_y, global_position.y) if _falling else global_position.y
		_falling = true


func hurt(amount: float) -> void:
	if not alive or amount <= 0.0 or in_safe_zone:
		return
	health = maxf(health - amount, 0.0)
	_regen_wait = health_regen_delay
	health_changed.emit(health, max_health)
	if health <= 0.0:
		health_depleted.emit()


func heal(amount: float) -> void:
	if not alive or amount <= 0.0:
		return
	health = minf(health + amount, max_health)
	health_changed.emit(health, max_health)


func play_emote(clip: String) -> void:
	if avatar != null and avatar.has_method("play_emote"):
		avatar.call("play_emote", clip)


func get_effective_speed_studs() -> float:
	return (walk_speed * get_speed_multiplier()) / STUD


func get_effective_jump_studs() -> float:
	return (jump_power * get_jump_multiplier()) / STUD


func get_effective_gravity_studs() -> float:
	return (gravity * get_gravity_multiplier()) / STUD


func get_speed_multiplier() -> float:
	var mult: float = _speed_boost_mult if _speed_boost_timer > 0.0 else 1.0
	var eq_id: String = String(_equipped_item.get("id", ""))
	if eq_id in ["speed_coil", "fusion_coil"]:
		mult = maxf(mult, float(_equipped_item.get("speed_multiplier", 2.0)))
	if _slow_timer > 0.0:
		mult *= _slow_mult
	return mult


func get_jump_multiplier() -> float:
	var mult: float = _jump_boost_mult if _gravity_boost_timer > 0.0 else 1.0
	var eq_id: String = String(_equipped_item.get("id", ""))
	if eq_id in ["gravity_coil", "fusion_coil"]:
		mult = maxf(mult, float(_equipped_item.get("jump_boost_multiplier", 1.40)))
	return mult


func get_gravity_multiplier() -> float:
	var mult: float = _gravity_boost_mult if _gravity_boost_timer > 0.0 else 1.0
	var eq_id: String = String(_equipped_item.get("id", ""))
	if eq_id in ["gravity_coil", "fusion_coil"]:
		mult = minf(mult, float(_equipped_item.get("gravity_multiplier", 0.35)))
	return mult


func apply_lunge_dash(direction: Vector3, forward_speed: float = 52.0, up_boost: float = 0.0, duration: float = 0.34) -> void:
	# Classic flat lunge: charge forward at a FIXED height. Gravity is switched off for the
	# dash, so running off a ledge mid-lunge keeps you level instead of dropping you, and the
	# moment the dash ends gravity comes back and you fall normally.
	var flat := Vector3(direction.x, 0.0, direction.z)
	if flat.length_squared() < 0.0001:
		flat = Vector3(-sin(heading), 0.0, -cos(heading))
	_lunge_dash_dir = flat.normalized()
	_lunge_dash_speed = maxf(forward_speed, 0.0) * STUD
	_lunge_dash_timer = maxf(duration, 0.08)
	_lunge_vert_lock = true
	_lunge_rise_speed = maxf(up_boost, 0.0) * STUD
	_lunge_rise_left = 0.22 if _lunge_rise_speed > 0.0 else 0.0
	floor_snap_length = 0.0
	grounded = false
	_is_jumping = true
	velocity.y = _lunge_rise_speed if _lunge_rise_left > 0.0 else 0.0


func apply_lunge_float(up_boost: float = 22.0, duration: float = 1.6) -> void:
	# Kept for older scenes: an upward float is now just a zero-speed dash with a pop.
	apply_lunge_dash(Vector3(-sin(heading), 0.0, -cos(heading)), 0.0, up_boost, duration)


func _drive_lunge_dash(delta: float) -> void:
	_lunge_dash_timer = maxf(0.0, _lunge_dash_timer - delta)
	floor_snap_length = 0.0
	velocity.x = _lunge_dash_dir.x * _lunge_dash_speed
	velocity.z = _lunge_dash_dir.z * _lunge_dash_speed
	if not _lunge_vert_lock:
		velocity.y = _lunge_dash_dir.y * _lunge_dash_speed
	elif _lunge_rise_left > 0.0:
		_lunge_rise_left = maxf(0.0, _lunge_rise_left - delta)
		velocity.y = _lunge_rise_speed
	else:
		velocity.y = 0.0
	if _lunge_dash_timer <= 0.0:
		_end_lunge_dash()


func _end_lunge_dash() -> void:
	_lunge_dash_timer = 0.0
	_lunge_rise_left = 0.0
	_lunge_vert_lock = true
	floor_snap_length = _floor_snap_default
	grounded = false


func is_lunging() -> bool:
	return _lunge_dash_timer > 0.0


func start_grapple(target: Vector3, speed: float = 95.0, duration: float = 1.15) -> void:
	var to_target: Vector3 = target - global_position
	if to_target.length_squared() < 0.04:
		return
	_lunge_dash_dir = to_target.normalized()
	_lunge_dash_speed = maxf(speed, 10.0) * STUD
	_lunge_dash_timer = maxf(duration, 0.15)
	_lunge_vert_lock = false
	_lunge_rise_left = 0.0
	_lunge_rise_speed = 0.0
	floor_snap_length = 0.0
	grounded = false
	_is_jumping = true


func apply_speed_surge(mult: float, duration: float, health_drain_per_sec: float = 0.0) -> void:
	_speed_boost_mult = maxf(_speed_boost_mult, mult)
	_speed_boost_timer = maxf(_speed_boost_timer, duration)
	_surge_timer = maxf(_surge_timer, duration)
	_surge_drain = maxf(_surge_drain, health_drain_per_sec)


func set_ghost(duration: float) -> void:
	_ghost_timer = maxf(_ghost_timer, duration)
	set_ghost_alpha(0.18)


func set_ghost_alpha(alpha: float) -> void:
	if avatar == null or not is_instance_valid(avatar):
		return
	var tr: float = clampf(1.0 - alpha, 0.0, 1.0)
	for n in avatar.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		if mi != null:
			mi.transparency = tr
	for n in avatar.find_children("*", "Label3D", true, false):
		var lbl := n as Label3D
		if lbl != null:
			lbl.transparency = clampf(tr + 0.35, 0.0, 1.0)


func sit_in_chair(chair_node: Node3D) -> void:
	if chair_node == null or not is_instance_valid(chair_node) or _chair_sit_cooldown > 0.0:
		return
	_seated_chair = chair_node
	global_position = chair_node.global_position + Vector3(0.0, 0.55 * STUD, 0.0)
	velocity = Vector3.ZERO
	heading = chair_node.global_rotation.y
	if avatar != null and avatar.has_method("play_emote"):
		avatar.call("play_emote", "sit")


func apply_burn(dps: float, duration: float) -> void:
	_burn_dps = maxf(_burn_dps, dps)
	_burn_timer = maxf(_burn_timer, duration)


func apply_slow(mult: float, duration: float) -> void:
	_slow_mult = clampf(mult, 0.1, 1.0)
	_slow_timer = maxf(_slow_timer, duration)


func die(world: Node3D) -> void:
	if not alive:
		return
	alive = false
	health = 0.0
	health_changed.emit(health, max_health)
	velocity = Vector3.ZERO
	_stop_climb()
	if voice_indicator != null and is_instance_valid(voice_indicator):
		voice_indicator.visible = false
	avatar.call("burst", world, randi(), _input_first_person)


func respawn_at(pos: Vector3) -> void:
	_ensure_nodes()
	alive = true
	health = max_health
	_regen_wait = 0.0
	_falling = false
	_stop_climb()
	_ladder_dismount = 0.0
	_rise_left = 0.0
	_touching_damage.clear()
	_touching_heal.clear()
	_damage_tick_cd = 0.0
	_heal_tick_cd = 0.0
	avatar.position.y = 0.0
	health_changed.emit(health, max_health)
	global_position = pos
	velocity = Vector3.ZERO
	heading = 0.0
	avatar.rotation.y = 0.0
	avatar.visible = true
	_refresh_voice_bubble(0.0)
	_dust(1.3)


func _do_bounce(custom_power := BOUNCE_POWER) -> void:
	if not alive or _bounce_cd > 0.0:
		return
	_bounce_cd = BOUNCE_COOLDOWN
	velocity.y = custom_power
	_falling = true
	_fall_peak_y = global_position.y
	_play_jump_sound(0.9)
	_dust(1.4)


func _play_jump_sound(_pitch := 1.0) -> void:
	var sfx: Node = get_node_or_null("/root/Sfx")
	if sfx != null:
		sfx.call("play_jump_3d", self)


func _play_land_sound() -> void:
	var sfx: Node = get_node_or_null("/root/Sfx")
	if sfx != null:
		sfx.call("play_land_3d", self)


func _update_loops() -> void:
	if _steps_loop == null or _climb_loop == null:
		return
	if not is_instance_valid(_steps_loop) or not is_instance_valid(_climb_loop):
		return
	var hspeed := Vector2(velocity.x, velocity.z).length()
	var walking := alive and grounded and not climbing and hspeed > 2.0 * STUD
	if walking:
		if not _steps_loop.playing:
			_steps_loop.play()
		_steps_loop.pitch_scale = clampf(1.85 * (0.9 + hspeed / walk_speed * 0.2), 1.4, 2.2)
	elif _steps_loop.playing:
		_steps_loop.stop()

	var is_climbing := alive and climbing
	if is_climbing:
		if not _climb_loop.playing:
			_climb_loop.play()
	elif _climb_loop.playing:
		_climb_loop.stop()

	if _fall_loop != null and is_instance_valid(_fall_loop):
		var plummeting := alive and not grounded and not climbing and velocity.y < -FALL_WIND_SPEED
		if plummeting:
			if not _fall_loop.playing:
				_fall_loop.play()
		elif _fall_loop.playing:
			_fall_loop.stop()


static func _is_climbable_node(other: Node3D) -> bool:
	if other == null or not is_instance_valid(other):
		return false
	if other.is_in_group("ladder") or other.is_in_group("climb"):
		return true
	var n := other.name.to_lower()
	if "ladder" in n or "truss" in n or "climb" in n:
		return true
	if other is CollisionObject3D and (((other as CollisionObject3D).collision_layer & 16) != 0):
		return true
	return false


func _setup_ladder_sensor() -> void:
	var area := Area3D.new()
	area.name = "LadderSensor"
	area.collision_layer = 0
	area.collision_mask = 16 | 1
	area.monitoring = true
	area.monitorable = false
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.8 * STUD, 3.0 * STUD, 2.8 * STUD)
	shape_node.shape = shape
	shape_node.position = Vector3(0.0, 2.6 * STUD, 0.0)
	area.add_child(shape_node)
	add_child(area)
	_ladder_sensor = area
	var on_enter := func(other: Node3D) -> void:
		if other != self and _is_climbable_node(other) and not _ladder_areas.has(other):
			_ladder_areas.append(other)
	var on_exit := func(other: Node3D) -> void:
		_ladder_areas.erase(other)
	area.area_entered.connect(on_enter)
	area.area_exited.connect(on_exit)
	area.body_entered.connect(on_enter)
	area.body_exited.connect(on_exit)


func _on_touch_entered(other: Node3D) -> void:
	if other == null or other == self or not is_instance_valid(other):
		return
	if other.is_in_group("chair") and _seated_chair == null and _chair_sit_cooldown <= 0.0:
		sit_in_chair(other)
		return
	if other.is_in_group("slide_ramp"):
		var s_fwd: Vector3 = -other.global_transform.basis.z
		s_fwd.y = 0.0
		if s_fwd.length_squared() > 0.01:
			_slide_dir = s_fwd.normalized()
			_slide_timer = 0.25
		return
	if other.is_in_group("item_spawner") and other.has_method("can_pickup"):
		if bool(other.call("can_pickup")):
			var it_data: Dictionary = other.call("consume_pickup")
			item_picked_up.emit(it_data)
		return
	if other.is_in_group("kill") or other.get("insta_kill") == true:
		touched_group.emit("kill", other)
		return
	if other.is_in_group("insta_heal") or other.get("insta_heal") == true:
		if health < max_health:
			heal(max_health)
		touched_group.emit("insta_heal", other)
		return
	if other.is_in_group("damage"):
		if not _touching_damage.has(other):
			_touching_damage.append(other)
		if _damage_tick_cd <= 0.0:
			var dmg := _node_float(other, "damage_amount", "damage", 20.0)
			var cd := _node_float(other, "damage_cooldown", "damage_cooldown", 0.55)
			hurt(dmg)
			_damage_tick_cd = cd
			touched_group.emit("damage", other)
		return
	if other.is_in_group("heal"):
		if not _touching_heal.has(other):
			_touching_heal.append(other)
		if _heal_tick_cd <= 0.0:
			var h_amt := _node_float(other, "heal_amount", "heal", 15.0)
			var h_cd := _node_float(other, "heal_cooldown", "heal_cooldown", 0.45)
			if health < max_health:
				heal(h_amt)
			_heal_tick_cd = h_cd
			touched_group.emit("heal", other)
		return

	# If remove_on_touch_block was requested by a pad, stepping onto any normal block/ground resets the boost
	var is_pad := other.is_in_group("speed_pad") or other.is_in_group("gravity_pad") or other.is_in_group("bounce") or other.is_in_group("checkpoint")
	if not is_pad:
		if _speed_remove_on_block:
			_speed_boost_mult = 1.0
			_speed_boost_timer = 0.0
			_speed_remove_on_block = false
		if _gravity_remove_on_block:
			_gravity_boost_mult = 1.0
			_jump_boost_mult = 1.0
			_gravity_boost_timer = 0.0
			_gravity_remove_on_block = false

	for g in ["goal", "checkpoint", "bounce", "speed_pad", "gravity_pad"]:
		if other.is_in_group(g):
			if g == "checkpoint":
				var spawn_pos: Vector3 = other.global_position + Vector3(0.0, 1.2 * STUD, 0.0)
				var meta_spawn: Variant = other.get_meta("spawn", null)
				if meta_spawn is Vector3:
					spawn_pos = meta_spawn
				spawn_point = Transform3D(Basis(), spawn_pos)
				if other.has_method("activate_checkpoint"):
					other.call("activate_checkpoint")
				if bool(other.get("heal_on_checkpoint")):
					heal(max_health)
				_dust(1.5)
				touched_group.emit(g, other)
				return
			if g == "bounce":
				var bp := _node_float(other, "bounce_power", "bounce_power", BOUNCE_POWER)
				_do_bounce(bp * STUD)
				return
			if g == "speed_pad":
				_speed_boost_mult = _node_float(other, "speed_multiplier", "speed_multiplier", 1.65)
				var is_infinite := bool(other.get("infinite_duration")) or bool(other.get_meta("infinite_duration", false)) or _node_float(other, "speed_duration", "speed_duration", 10.0) > 100000.0
				_speed_boost_timer = INF if is_infinite else _node_float(other, "speed_duration", "speed_duration", 10.0)
				_speed_remove_on_block = bool(other.get("remove_on_touch_block")) or bool(other.get_meta("remove_on_touch_block", false))
				_dust(1.5)
				touched_group.emit(g, other)
				return
			if g == "gravity_pad":
				_gravity_boost_mult = _node_float(other, "gravity_multiplier", "gravity_multiplier", 0.42)
				_jump_boost_mult = _node_float(other, "jump_boost_multiplier", "jump_boost_multiplier", 1.25)
				var is_inf_g := bool(other.get("infinite_duration")) or bool(other.get_meta("infinite_duration", false)) or _node_float(other, "gravity_duration", "gravity_duration", 10.0) > 100000.0
				_gravity_boost_timer = INF if is_inf_g else _node_float(other, "gravity_duration", "gravity_duration", 10.0)
				_gravity_remove_on_block = bool(other.get("remove_on_touch_block")) or bool(other.get_meta("remove_on_touch_block", false))
				_dust(1.5)
				touched_group.emit(g, other)
				return
			touched_group.emit(g, other)
			return


func _on_touch_exited(other: Node3D) -> void:
	_touching_damage.erase(other)
	_touching_heal.erase(other)


func _setup_touch_sensor() -> void:
	var area := Area3D.new()
	area.name = "TouchSensor"
	area.collision_layer = 0
	area.collision_mask = 1 | 16
	area.monitoring = true
	area.monitorable = false
	var shape_node := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = 1.35 * STUD
	shape.height = 5.6 * STUD
	shape_node.shape = shape
	shape_node.position = Vector3(0.0, 2.4 * STUD, 0.0)
	area.add_child(shape_node)
	add_child(area)
	_touch_sensor = area
	area.body_entered.connect(_on_touch_entered)
	area.body_exited.connect(_on_touch_exited)
	area.area_entered.connect(_on_touch_entered)
	area.area_exited.connect(_on_touch_exited)


func set_equipped_item(item_data: Dictionary) -> void:
	_equipped_item = item_data
	if _carpet_visual != null and is_instance_valid(_carpet_visual):
		_carpet_visual.queue_free()
		_carpet_visual = null
	if avatar == null or not is_instance_valid(avatar):
		return
	if item_data.is_empty():
		if avatar.has_method("set_equipped_hand_model"):
			avatar.call("set_equipped_hand_model", null)
		return
	var spawner_scr: Script = load(ITEM_SPAWNER_SCRIPT_PATH) as Script
	if spawner_scr == null:
		return
	var iid_str: String = String(item_data.get("id", ""))
	var t_idx: int = int(item_data.get("item_type", 0))
	if t_idx <= 0 and spawner_scr.has_method("get_type_from_id"):
		t_idx = int(spawner_scr.call("get_type_from_id", iid_str))
	if t_idx <= 0:
		t_idx = 5
	var model: Node3D = spawner_scr.call("build_item_mesh_3d", t_idx) as Node3D
	if model != null:
		if avatar.has_method("set_equipped_hand_model"):
			avatar.call("set_equipped_hand_model", model, iid_str)
	if String(item_data.get("id", "")) == "flying_carpet":
		_carpet_visual = spawner_scr.call("build_item_mesh_3d", 12) as Node3D
		if _carpet_visual != null:
			_carpet_visual.name = "FlyingCarpetUnderFeet"
			_carpet_visual.scale = Vector3(1.6, 1.0, 1.6)
			_carpet_visual.position = Vector3(0.0, 0.08 * STUD, 0.0)
			add_child(_carpet_visual)


func activate_big_head(scale_mult: float, duration: float) -> void:
	_big_head_timer = maxf(duration, 1.0)
	if avatar != null and avatar.has_method("set_head_scale"):
		avatar.call("set_head_scale", scale_mult)
