extends Node3D
## AvatarRig — the classic six-part block avatar, rebuilt for the new player.
##
## Two visual modes behind one tiny API:
##   1) R6IK mode (default) — the real catalog model. The same R6IK.fbx rig
##      the website's avatar editor renders ships in assets/models/. Limbs
##      swing from its own AnimationPlayer (the old Roblox clips).
##   2) Box mode (fallback) — a code-built classic box body used on first
##      open before Godot imported the FBX, or without a models folder.
##
## The rig is EXACTLY 5 studs tall (classic R6 height) in both modes, so
## creator-placed 3D UGC lands 1:1 with the website's 5-stud rig.

const HEAD := 0
const TORSO := 1
const ARM_L := 2
const ARM_R := 3
const LEG_L := 4
const LEG_R := 5
const HEAD_INDEX := 0

const RIG_SCENE_PATH := "res://assets/models/retroblox_anims.fbx"
## The rig is 5 studs tall, built 1 stud = 1 Godot unit — the classic size.
## UGC hats and creator placements are authored in this same 5-stud space.
const STUD := 1.0
const RIG_HEIGHT := 5.0 * STUD
const SITE_RIG_HEIGHT := 5.0

const ANIM_IDLE := &"Idle"
const ANIM_WALK := &"Walk"
const ANIM_JUMP := &"Jump"
const ANIM_CLIMB := &"Climb"
const ANIM_SIT := &"Sit"

# classic noob defaults — guests and brand-new accounts wear these
const NOOB_HEAD := Color("f5cd30")
const NOOB_TORSO := Color("0d69ac")
const NOOB_ARMS := Color("f5cd30")
const NOOB_LEGS := Color("7ab53e")

# name aliases, ported from the site's rig so any part naming convention works
const PART_ALIASES: Array = [
        [HEAD, ["head"]],
        [TORSO, ["torso"]],
        [ARM_L, ["left arm", "leftarm", "arm l", "l arm"]],
        [ARM_R, ["right arm", "rightarm", "arm r", "r arm"]],
        [LEG_L, ["left leg", "leftleg", "leg l", "l leg"]],
        [LEG_R, ["right leg", "rightleg", "leg r", "r leg"]],
]
const RIG_NAME_CHARS := "abcdefghijklmnopqrstuvwxyz0123456789_"

# classic R6 proportions (studs) for the code-built box body — scaled by STUD
const BOX_LEG_H := 2.0 * STUD
const BOX_TORSO := Vector3(2.0, 2.0, 1.0) * STUD
const BOX_ARM := Vector3(1.0, 2.0, 1.0) * STUD
const BOX_LEG := Vector3(1.0, 2.0, 1.0) * STUD
const BOX_HEAD := Vector3(1.15, 1.15, 1.15) * STUD

var parts: Array[MeshInstance3D] = []
var HEAD_PIVOT_Y := 0.0  # head center height, set by the active mode

var _pivots: Array[Node3D] = []
var _part_sizes: Array[Vector3] = []
var _part_aabb: Array[AABB] = []
var _mounts: Array[Node3D] = []
var _overlays: Dictionary = {}
var _nameplate: Label3D
var _face_decal: MeshInstance3D
var _tshirt_decal: MeshInstance3D   # v4.0: the t-shirt image decal on the torso front
var _display_name := "Player"
var _built := false
var _using_r6ik := false
var _time := 0.0
var _applied_colors: Dictionary = {}
var _anim_player: AnimationPlayer
var _current_anim := &""
var _walk_rate := 1.0     # v11.0: eased playback speeds (no more rate snaps)
var _climb_rate := 1.0
var _oof_audio: AudioStream


func _ready() -> void:
        _ensure_built(true)


func is_r6ik() -> bool:
        return _using_r6ik


func setup(p_name: String) -> void:
        _display_name = p_name
        _ensure_built()
        paint_noob()
        set_display_name(p_name)


func set_display_name(value: String) -> void:
        _display_name = value
        if _nameplate != null:
                _nameplate.text = value


func paint_noob() -> void:
        set_part_color(HEAD, NOOB_HEAD)
        set_part_color(TORSO, NOOB_TORSO)
        set_part_color(ARM_L, NOOB_ARMS)
        set_part_color(ARM_R, NOOB_ARMS)
        set_part_color(LEG_L, NOOB_LEGS)
        set_part_color(LEG_R, NOOB_LEGS)


## Paint one body part a solid color (texture-free).
func set_part_color(index: int, color: Color) -> void:
        _ensure_built()
        if index < 0 or index >= parts.size():
                return
        _applied_colors[index] = color
        var mi := parts[index]
        if mi.mesh == null:
                return
        for surface in mi.mesh.get_surface_count():
                mi.set_surface_override_material(surface, null)
        mi.material_override = _make_material(color)


## Dress one part with a zone-UV box mesh + texture (the shirt/pants pipeline).
func set_part_textured(index: int, mesh: Mesh, tex: Texture2D) -> void:
        _ensure_built()
        if index < 0 or index >= parts.size():
                return
        var mi := parts[index]
        var material := StandardMaterial3D.new()
        material.albedo_texture = tex
        material.roughness = 0.78
        if _using_r6ik:
                if _overlays.has(index) and is_instance_valid(_overlays[index]):
                        _overlays[index].queue_free()
                var overlay := MeshInstance3D.new()
                overlay.name = "ClothingOverlay_%d" % index
                overlay.mesh = mesh
                overlay.material_override = material
                _mounts[index].add_child(overlay)
                overlay.scale = Vector3.ONE * 1.02
                _overlays[index] = overlay
        else:
                mi.mesh = mesh
                mi.material_override = material


## v4.0 T-SHIRTS — an image decal on the FRONT of the torso, exactly what
## the website draws (92% of the torso face). T-shirt UGC ships as a plain
## image (no GLB), so the dresser hands the texture here instead of the
## 3D accessory path. Repainted whenever a new t-shirt arrives; freed with
## the rig.
func set_tshirt(tex: Texture2D) -> void:
        _ensure_built()
        if tex == null:
                return
        if _tshirt_decal != null and is_instance_valid(_tshirt_decal):
                _tshirt_decal.queue_free()
                _tshirt_decal = null
        var torso_size := _part_sizes[TORSO]
        var quad := MeshInstance3D.new()
        quad.name = "TshirtDecal"
        var mesh := QuadMesh.new()
        mesh.size = Vector2(torso_size.x * 0.92, torso_size.y * 0.92)
        quad.mesh = mesh
        var material := StandardMaterial3D.new()
        material.albedo_texture = tex
        material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
        material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        material.cull_mode = BaseMaterial3D.CULL_DISABLED
        quad.material_override = material
        var host: Node3D = _mounts[TORSO]
        host.add_child(quad)
        # the front of the torso faces -Z — same wall the face decal hangs on
        quad.position = Vector3(0.0, 0.0, -torso_size.z * 0.5 - 0.004)
        quad.rotation.y = PI
        _tshirt_decal = quad


## Put a face decal on the FRONT of the head (-Z).
func set_face(tex: Texture2D, face_scale: float) -> void:
        _ensure_built()
        if tex == null:
                return
        if _face_decal != null and is_instance_valid(_face_decal):
                _face_decal.queue_free()
                _face_decal = null
        var head_size := _part_sizes[HEAD_INDEX]
        var w: float = head_size.x * 0.62 * clampf(face_scale, 0.5, 2.0)
        var quad := MeshInstance3D.new()
        quad.name = "FaceDecal"
        var mesh := QuadMesh.new()
        mesh.size = Vector2(w, w)
        quad.mesh = mesh
        var material := StandardMaterial3D.new()
        material.albedo_texture = tex
        material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
        material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        material.cull_mode = BaseMaterial3D.CULL_DISABLED
        quad.material_override = material
        var host: Node3D = _mounts[HEAD_INDEX]
        host.add_child(quad)
        quad.position = Vector3(0.0, head_size.y * 0.04, -head_size.z * 0.5 - 0.004)
        quad.rotation.y = PI
        _face_decal = quad


func animate(delta: float, speed: float, grounded: bool, climbing: bool = false, climb_speed: float = 0.0) -> void:
        _ensure_built()
        if _using_r6ik and _anim_player != null:
                _time += delta
                _animate_r6ik(delta, speed, grounded, climbing, climb_speed)
                return
        _animate_boxes(delta, speed, grounded, climbing, climb_speed)


var _resolved_anims: Dictionary = {}


func _resolve_anim_name(base: StringName) -> StringName:
        if _anim_player == null:
                return &""
        if _resolved_anims.has(base):
                return _resolved_anims[base]
        if _anim_player.has_animation(base):
                _resolved_anims[base] = base
                return base
        var base_str := String(base).to_lower()
        for anim_name in _anim_player.get_animation_list():
                var s := String(anim_name).to_lower()
                if s == base_str or s.ends_with("/" + base_str) or s.ends_with("|" + base_str) or s.contains(base_str):
                        _resolved_anims[base] = anim_name
                        return anim_name
        _resolved_anims[base] = &""
        return &""


func _animate_r6ik(delta: float, speed: float, grounded: bool, climbing: bool, climb_speed: float) -> void:
        var next: StringName = ANIM_IDLE
        var rate := 1.0
        var is_climb_moving := absf(climb_speed) > 0.15

        if climbing:
                next = ANIM_CLIMB
                rate = clampf(absf(climb_speed) / (9.0 * STUD), 0.7, 1.6) if is_climb_moving else 0.0
        elif not grounded:
                next = ANIM_JUMP
                rate = 1.35
        elif speed > 1.2 * STUD:
                next = ANIM_WALK
                rate = clampf(speed / (8.0 * STUD), 0.8, 2.2)

        var anim_to_play := _resolve_anim_name(next)
        if anim_to_play != &"":
                if _current_anim != next:
                        _current_anim = next
                        _anim_player.play(anim_to_play, 0.12, 1.0 if not climbing else (rate if is_climb_moving else 0.001))
                        if climbing and not is_climb_moving:
                                _anim_player.speed_scale = 0.0
                                _climb_rate = 0.0
                        elif not climbing:
                                _anim_player.speed_scale = rate
                elif climbing:
                        if is_climb_moving:
                                _climb_rate = lerpf(_climb_rate, rate, 1.0 - exp(-10.0 * delta))
                                _anim_player.speed_scale = _climb_rate
                        else:
                                _climb_rate = 0.0
                                _anim_player.speed_scale = 0.0
                elif next == ANIM_WALK:
                        var k := 1.0 - exp(-8.0 * delta)
                        _walk_rate = lerpf(_walk_rate, rate, k)
                        _anim_player.speed_scale = _walk_rate
                else:
                        _anim_player.speed_scale = 1.0
        else:
                _animate_boxes(delta, speed, grounded, climbing, climb_speed)


## Settings > Animations: pose the character with a rig clip ("Sit", ...).
## Movement calls animate() every frame, which cancels the pose naturally.
func play_emote(clip: String) -> void:
        _ensure_built()
        if not _using_r6ik or _anim_player == null:
                return
        if clip == "":
                _current_anim = &""
                return
        var anim_name := StringName(clip)
        var resolved := _resolve_anim_name(anim_name)
        if resolved != &"" and _anim_player.has_animation(resolved):
                _current_anim = &"emote_" + anim_name
                _anim_player.play(resolved, 0.2)


func _animate_boxes(delta: float, speed: float, grounded: bool, climbing: bool, climb_speed: float = 0.0) -> void:
        var is_climb_moving := absf(climb_speed) > 0.15
        if not climbing or is_climb_moving:
                _time += delta
        var movement := clampf(absf(speed) / (5.0 * STUD), 0.0, 1.0)
        var walk_rate := 4.8 + movement * 2.0
        var swing := sin(_time * walk_rate) * movement
        var k := 1.0 - exp(-12.0 * delta)
        var arm_l_x := 0.0
        var arm_r_x := 0.0
        var leg_l_x := 0.0
        var leg_r_x := 0.0
        var head_x := 0.0
        var torso_x := 0.0
        var arm_l_z := 0.0
        var arm_r_z := 0.0
        if climbing:
                var alt := sin(_time * 6.5) * 0.9
                arm_l_x = -2.4 + alt * 0.4
                arm_r_x = -2.4 - alt * 0.4
                leg_l_x = alt * 0.5
                leg_r_x = -alt * 0.5
        elif grounded:
                arm_l_x = swing * 0.7
                arm_r_x = -swing * 0.7
                leg_l_x = -swing * 0.66
                leg_r_x = swing * 0.66
                head_x = sin(_time * 1.8) * 0.025
                torso_x = sin(_time * 1.8 + 0.5) * 0.012
                arm_l_z = sin(_time * 2.1) * 0.025 * (1.0 - movement)
                arm_r_z = -arm_l_z
        else:
                arm_l_x = -2.6
                arm_r_x = -2.6
                leg_l_x = 0.35
                leg_r_x = -0.35
        var set_rot := func(idx: int, rx: float, rz: float = 0.0, use_z: bool = false) -> void:
                if idx < _pivots.size() and _pivots[idx] != null and is_instance_valid(_pivots[idx]):
                        _pivots[idx].rotation.x = lerp_angle(_pivots[idx].rotation.x, rx, k)
                        if use_z:
                                _pivots[idx].rotation.z = lerp_angle(_pivots[idx].rotation.z, rz, k)

        set_rot.call(ARM_L, arm_l_x, arm_l_z, true)
        set_rot.call(ARM_R, arm_r_x, arm_r_z, true)
        set_rot.call(LEG_L, leg_l_x)
        set_rot.call(LEG_R, leg_r_x)
        set_rot.call(HEAD, head_x)
        set_rot.call(TORSO, torso_x)


## Oof! — the classic breakup, used by death and reset.
func burst(world: Node3D, impulse_seed: int) -> void:
        _ensure_built()
        if world == null:
                return
        visible = false
        var debris := Node3D.new()
        debris.name = "AvatarBreakup"
        world.add_child(debris)
        debris.global_position = global_position
        var rng := RandomNumberGenerator.new()
        rng.seed = abs(impulse_seed) * 104729 + 13
        for i in range(parts.size()):
                var piece := _make_debris_piece(debris, i)
                piece.linear_velocity = Vector3(
                        rng.randf_range(-4.8, 4.8), rng.randf_range(4.0, 7.5), rng.randf_range(-4.8, 4.8)) * STUD
                piece.angular_velocity = Vector3(
                        rng.randf_range(-5.5, 5.5), rng.randf_range(-5.5, 5.5), rng.randf_range(-5.5, 5.5))
        var audio := AudioStreamPlayer3D.new()
        audio.name = "OriginalOof"
        audio.stream = _get_oof_audio()
        audio.max_distance = 40.0 * STUD
        audio.unit_size = 10.0 * STUD
        debris.add_child(audio)
        audio.play()
        var cleanup := world.get_tree().create_timer(5.0)
        cleanup.timeout.connect(debris.queue_free)


func _get_oof_audio() -> AudioStream:
        if _oof_audio == null:
                # the ORIGINAL classic death sound straight from the client
                if ResourceLoader.exists("res://assets/rbx_uuhhh.mp3"):
                        _oof_audio = load("res://assets/rbx_uuhhh.mp3")
                else:
                        _oof_audio = load("res://assets/oof.wav")
        return _oof_audio


# ---------------------------------------------------------------- building

func _check_existing_scene_nodes() -> bool:
        var head := get_node_or_null("Head") as MeshInstance3D
        if head == null:
                head = get_node_or_null("Part_0") as MeshInstance3D
        var torso := get_node_or_null("Torso") as MeshInstance3D
        if torso == null:
                torso = get_node_or_null("Part_1") as MeshInstance3D
        var lp := get_node_or_null("LeftArmPivot") as Node3D
        if lp == null:
                lp = get_node_or_null("Pivot_2") as Node3D
        var rp := get_node_or_null("RightArmPivot") as Node3D
        if rp == null:
                rp = get_node_or_null("Pivot_3") as Node3D
        var llp := get_node_or_null("LeftLegPivot") as Node3D
        if llp == null:
                llp = get_node_or_null("Pivot_4") as Node3D
        var rlp := get_node_or_null("RightLegPivot") as Node3D
        if rlp == null:
                rlp = get_node_or_null("Pivot_5") as Node3D

        if head == null or torso == null or lp == null or rp == null or llp == null or rlp == null:
                return false

        var la := lp.get_node_or_null("LeftArm") as MeshInstance3D
        if la == null:
                la = lp.get_node_or_null("Part_2") as MeshInstance3D
        var ra := rp.get_node_or_null("RightArm") as MeshInstance3D
        if ra == null:
                ra = rp.get_node_or_null("Part_3") as MeshInstance3D
        var ll := llp.get_node_or_null("LeftLeg") as MeshInstance3D
        if ll == null:
                ll = llp.get_node_or_null("Part_4") as MeshInstance3D
        var rl := rlp.get_node_or_null("RightLeg") as MeshInstance3D
        if rl == null:
                rl = rlp.get_node_or_null("Part_5") as MeshInstance3D

        if la == null or ra == null or ll == null or rl == null:
                return false

        parts = [head, torso, la, ra, ll, rl]
        _pivots = [head, torso, lp, rp, llp, rlp]
        _part_sizes = [BOX_HEAD, BOX_TORSO, BOX_ARM, BOX_ARM, BOX_LEG, BOX_LEG]
        _part_aabb = [
                AABB(-BOX_HEAD * 0.5, BOX_HEAD),
                AABB(-BOX_TORSO * 0.5, BOX_TORSO),
                AABB(-BOX_ARM * 0.5, BOX_ARM),
                AABB(-BOX_ARM * 0.5, BOX_ARM),
                AABB(-BOX_LEG * 0.5, BOX_LEG),
                AABB(-BOX_LEG * 0.5, BOX_LEG)
        ]
        _mounts.clear()
        for i in range(6):
                var m := _pivots[i].get_node_or_null("Mount_%d" % i) as Node3D
                if m == null:
                        m = Node3D.new()
                        m.name = "Mount_%d" % i
                        _pivots[i].add_child(m)
                _mounts.append(m)
        HEAD_PIVOT_Y = head.position.y
        if _nameplate == null:
                _nameplate = _make_nameplate()
                _nameplate.position = Vector3(0.0, RIG_HEIGHT + 0.9 * STUD, 0.0)
                add_child(_nameplate)
        _built = true
        return true


func _ensure_built(allow_upgrade: bool = false) -> void:
        if _built:
                if allow_upgrade and not _using_r6ik and is_inside_tree() and not _check_existing_scene_nodes():
                        _try_r6ik()
                return
        if _check_existing_scene_nodes():
                return
        _built = true
        if is_inside_tree() and _try_r6ik():
                return
        _build_boxes()


## The real R6IK catalog model. Returns false when the FBX is not imported
## yet (fresh unzip, first open) — the box rig takes over until then.
func _try_r6ik() -> bool:
        var packed: PackedScene = load(RIG_SCENE_PATH)
        if packed == null:
                return false
        var inst: Node3D = packed.instantiate()
        if inst == null:
                return false
        var found: Dictionary = {}
        for node in inst.find_children("*", "MeshInstance3D", true, false):
                var mi := node as MeshInstance3D
                if mi.mesh == null:
                        continue
                var index := _match_part_name(mi.name, mi.mesh.resource_name)
                if index >= 0:
                        found[index] = mi
                else:
                        mi.visible = false
        if found.size() < 6:
                inst.free()
                return false
        _using_r6ik = true

        for node in inst.find_children("*", "AnimationPlayer", true, false):
                var ap := node as AnimationPlayer
                ap.autoplay = ""
                ap.stop()
                _anim_player = ap
                # Configure loop modes using resolved animation names
                for clip in [ANIM_IDLE, ANIM_WALK, ANIM_CLIMB, ANIM_SIT]:
                        var actual := _resolve_anim_name(clip)
                        if actual != &"":
                                var looped := ap.get_animation(actual)
                                if looped != null:
                                        looped.loop_mode = Animation.LOOP_LINEAR
                var jump_actual := _resolve_anim_name(ANIM_JUMP)
                if jump_actual != &"":
                        var jump_anim := ap.get_animation(jump_actual)
                        if jump_anim != null:
                                jump_anim.loop_mode = Animation.LOOP_NONE

        # normalize: RIG_HEIGHT tall, feet on y=0, centered on x/z — bounds from
        # REAL vertices (the FBX part nodes carry tilted Blender rotations)
        var raw_bounds := AABB()
        var have_bounds := false
        var part_boxes: Dictionary = {}
        for index in found:
                var mi: MeshInstance3D = found[index]
                var chain := _chain_transform(mi, inst)
                var box := _vertex_aabb(mi.mesh, chain)
                part_boxes[index] = box
                raw_bounds = box if not have_bounds else raw_bounds.merge(box)
                have_bounds = true
        var fit := RIG_HEIGHT / maxf(raw_bounds.size.y, 0.0001)
        var raw_center := raw_bounds.get_center()
        var model := Node3D.new()
        model.name = "R6IKModel"
        model.scale = Vector3.ONE * fit
        model.position = Vector3(-raw_center.x * fit, -raw_bounds.position.y * fit, -raw_center.z * fit)
        model.add_child(inst)
        add_child(model)

        parts.clear()
        _pivots.clear()
        _part_sizes.clear()
        _part_aabb.clear()
        _mounts.clear()
        for i in range(6):
                var mi: MeshInstance3D = found[i]
                var box: AABB = model.transform * part_boxes[i]
                parts.append(mi)
                _part_sizes.append(box.size)
                _part_aabb.append(box)
                var mount := Node3D.new()
                mount.name = "Mount_%d" % i
                mi.add_child(mount)
                var world_center := to_global(box.get_center())
                mount.transform = mi.global_transform.affine_inverse() * Transform3D(global_transform.basis, world_center)
                _mounts.append(mount)
                if i == HEAD_INDEX:
                        HEAD_PIVOT_Y = box.get_center().y
        for i in range(6):
                _pivots.append(found[i])

        _nameplate = _make_nameplate()
        _nameplate.position = Vector3(0.0, RIG_HEIGHT + 0.9 * STUD, 0.0)
        add_child(_nameplate)
        _nameplate.text = _display_name

        for index in _applied_colors:
                if index >= 0 and index < parts.size():
                        parts[index].material_override = _make_material(_applied_colors[index])
        return true


## Code-built classic box body — 5 studs tall, feet on y=0, facing -Z.
func _build_boxes() -> void:
        parts.clear()
        _pivots.clear()
        _part_sizes.clear()
        _part_aabb.clear()
        _mounts.clear()
        if _face_decal != null and is_instance_valid(_face_decal):
                _face_decal = null

        # limbs hang from pivots at shoulder (y=4) / hip (y=2) — studs * STUD
        var limb_defs: Array = [
                [HEAD, Vector3(0, 4.0 + 1.15 * 0.5 - 0.05, 0) * STUD, BOX_HEAD, null],
                [TORSO, Vector3(0, 3.0, 0) * STUD, BOX_TORSO, null],
                [ARM_L, Vector3(-1.5, 3.0, 0) * STUD, BOX_ARM, Vector3(-1.5, 4.0, 0) * STUD],
                [ARM_R, Vector3(1.5, 3.0, 0) * STUD, BOX_ARM, Vector3(1.5, 4.0, 0) * STUD],
                [LEG_L, Vector3(-0.5, 1.0, 0) * STUD, BOX_LEG, Vector3(-0.5, 2.0, 0) * STUD],
                [LEG_R, Vector3(0.5, 1.0, 0) * STUD, BOX_LEG, Vector3(0.5, 2.0, 0) * STUD],
        ]
        for def in limb_defs:
                var index: int = def[0]
                var center: Vector3 = def[1]
                var size: Vector3 = def[2]
                var pivot_pos: Variant = def[3]
                var holder: Node3D
                if pivot_pos != null:
                        var pivot := Node3D.new()
                        pivot.name = "Pivot_%d" % index
                        pivot.position = pivot_pos
                        add_child(pivot)
                        var mesh_node := MeshInstance3D.new()
                        mesh_node.name = "Part_%d" % index
                        mesh_node.position = center - pivot_pos  # limb center relative to its pivot
                        pivot.add_child(mesh_node)
                        holder = pivot
                        _pivots.append(pivot)
                else:
                        var mesh_node := MeshInstance3D.new()
                        mesh_node.name = "Part_%d" % index
                        mesh_node.position = center
                        add_child(mesh_node)
                        holder = mesh_node
                        _pivots.append(mesh_node)
                var mesh := BoxMesh.new()
                mesh.size = size
                var mi: MeshInstance3D
                if pivot_pos != null:
                        mi = holder.get_child(holder.get_child_count() - 1) as MeshInstance3D
                else:
                        mi = holder as MeshInstance3D
                mi.mesh = mesh
                parts.append(mi)
                _part_sizes.append(size)
                _part_aabb.append(AABB(-size * 0.5, size))
                var mount := Node3D.new()
                mount.name = "Mount_%d" % index
                mount.position = Vector3(0.0, 0.0, 0.0)
                holder.add_child(mount)
                # axis-aligned mount glued to the part's center (boxes are unrotated)
                if pivot_pos != null:
                        mount.position = center - pivot_pos
                else:
                        mount.position = Vector3.ZERO
                _mounts.append(mount)
        HEAD_PIVOT_Y = (4.0 + 1.15 * 0.5 - 0.05) * STUD

        _nameplate = _make_nameplate()
        _nameplate.position = Vector3(0.0, RIG_HEIGHT + 0.9 * STUD, 0.0)
        add_child(_nameplate)
        _nameplate.text = _display_name


func _make_nameplate() -> Label3D:
        var label := Label3D.new()
        label.name = "Nameplate"
        label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        label.no_depth_test = true
        label.pixel_size = 0.007
        label.font_size = 40
        label.outline_size = 7
        label.modulate = Color.WHITE
        label.outline_modulate = Color(0, 0, 0, 0.85)
        label.text = _display_name
        return label


func _make_debris_piece(debris: Node3D, index: int) -> RigidBody3D:
        var source: MeshInstance3D = parts[index]
        var piece := RigidBody3D.new()
        piece.name = "BrokenPart_%d" % index
        piece.collision_layer = 2
        piece.collision_mask = 3
        piece.mass = 0.7
        piece.linear_damp = 0.35
        piece.angular_damp = 0.45
        debris.add_child(piece)
        piece.global_transform = source.global_transform
        var mesh_copy := MeshInstance3D.new()
        mesh_copy.name = "Mesh"
        mesh_copy.mesh = source.mesh
        mesh_copy.material_override = source.material_override
        for surface: int in range(source.mesh.get_surface_count()):
                var override := source.get_surface_override_material(surface)
                if override != null:
                        mesh_copy.set_surface_override_material(surface, override)
        piece.add_child(mesh_copy)
        var collision := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = _part_sizes[index]
        collision.shape = shape
        piece.add_child(collision)
        return piece


func _make_material(color: Color) -> StandardMaterial3D:
        var material := StandardMaterial3D.new()
        material.albedo_color = color
        material.roughness = 0.78
        return material


# ---------------------------------------------------------------- rig math

## Transform chain from `node` up to (but excluding) `top`, child-first.
func _chain_transform(node: Node, top: Node) -> Transform3D:
        var xform := Transform3D.IDENTITY
        var current: Node = node
        while current != null and current != top:
                if current is Node3D:
                        xform = (current as Node3D).transform * xform
                current = current.get_parent()
        return xform


## Exact world-space bounds of a mesh: walks every vertex once. The FBX
## part nodes are rotated out of axis alignment by Blender's export, so
## transforming the local AABB would inflate the boxes and float decals.
func _vertex_aabb(mesh: Mesh, xform: Transform3D) -> AABB:
        var faces := mesh.get_faces()
        var box := AABB()
        var first := true
        for vertex in faces:
                var world := xform * vertex
                if first:
                        box = AABB(world, Vector3.ZERO)
                        first = false
                else:
                        box = box.expand(world)
        return box


## Site-compatible part-name matcher: lowercase, drop $tags, separators ->
## spaces, strip trailing digits.
func _match_part_name(node_name: String, mesh_name: String) -> int:
        for source in [node_name, mesh_name]:
                var norm := _norm_part_name(source)
                if norm.is_empty():
                        continue
                for entry in PART_ALIASES:
                        for alias in entry[1]:
                                if norm == alias or norm.begins_with(alias + " "):
                                        return int(entry[0])
        return -1


func _norm_part_name(raw: String) -> String:
        var s := raw.to_lower()
        var out := ""
        var i := 0
        while i < s.length():
                if s[i] == "$":
                        i += 1
                        while i < s.length() and RIG_NAME_CHARS.contains(s[i]):
                                i += 1
                else:
                        out += s[i]
                        i += 1
        out = out.replace("_", " ").replace(".", " ").replace("-", " ")
        var keep: Array[String] = []
        for token in out.split(" ", false):
                while token.length() > 1 and token.right(1) >= "0" and token.right(1) <= "9":
                        token = token.left(token.length() - 1)
                if token != "":
                        keep.append(token)
        return " ".join(keep)
