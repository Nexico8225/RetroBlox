extends SceneTree

func _init() -> void:
	# Test if FileSystemDock has PopupMenu children
	print("Checking how FileSystem dock context menus are built...")
	quit(0)
