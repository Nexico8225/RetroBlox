extends SceneTree
## Custom emote (v14) headless test — the platform-published GLB path.
##
## 1. builds an ANIMATED GLB at runtime with Godot's own glTF exporter
##    (a small box model + one position clip) -> user://emotes/emote_test.glb
## 2. feeds it through AvatarRig.start_custom_emote() exactly like the game:
##    body visuals hide, the model stands in, the clip loops
## 3. checks the no-anim template (site rig GLB) fails GRACEFULLY, not by crash
## 4. movement releases the emote and restores the body visuals

const RIG_SCRIPT := "res://scripts/player/avatar_rig.gd"
const TEST_GLB := "user://emotes/emote_test.glb"


func _init() -> void:
        call_deferred("_run")


func _run() -> void:
        var failures := 0
        var root := Node3D.new()
        get_root().add_child(root)
        var rig: Node = (load(RIG_SCRIPT) as GDScript).new()
        root.add_child(rig)
        rig.call("setup", "Tester")

        # ---- 1. animated GLB -> user:// ---------------------------------
        DirAccess.make_dir_recursive_absolute("user://emotes")
        var exported := _export_test_glb()
        if not exported:
                print("CUSTOM_EMOTE_TEST: SKIP (glTF export unavailable)")
                quit(0)
                return
        print("CUSTOM_EMOTE_TEST: exported animated glb ok")

        # ---- 2. play it like the game does ------------------------------
        var ok: bool = rig.call("start_custom_emote", TEST_GLB, "Wave")
        if not ok:
                print("CUSTOM_EMOTE_TEST: FAIL start_custom_emote returned false")
                failures += 1
        else:
                var emote: String = rig.get("_emote")
                var hidden: int = (rig.get("_hidden_visuals") as Array).size()
                var cr: Node3D = rig.get("_custom_root")
                if emote != "custom":
                        print("CUSTOM_EMOTE_TEST: FAIL emote state=%s" % emote)
                        failures += 1
                if hidden == 0:
                        print("CUSTOM_EMOTE_TEST: FAIL no body visuals hidden")
                        failures += 1
                if cr == null or not is_instance_valid(cr):
                        print("CUSTOM_EMOTE_TEST: FAIL custom model missing")
                        failures += 1
                else:
                        var ap := cr.find_child("AnimationPlayer", true, false) as AnimationPlayer
                        if ap == null or not ap.is_playing():
                                print("CUSTOM_EMOTE_TEST: FAIL clip not playing")
                                failures += 1
                        else:
                                print("CUSTOM_EMOTE_TEST: clip '%s' looping (%.2fs)" % [ap.current_animation, ap.current_animation_length])
        await process_frame
        await process_frame

        # ---- 3. movement releases it, body comes back --------------------
        rig.call("animate", 0.016, 20.0, true, false)
        if rig.get("_emote") != "" or rig.get("_custom_root") != null:
                print("CUSTOM_EMOTE_TEST: FAIL movement did not release the emote")
                failures += 1
        var still_hidden: int = (rig.get("_hidden_visuals") as Array).size()
        if still_hidden != 0:
                print("CUSTOM_EMOTE_TEST: FAIL body visuals not restored")
                failures += 1
        else:
                print("CUSTOM_EMOTE_TEST: movement release + body restore ok")

        # ---- 4. the site's rig template (NO animations) fails gracefully -
        var tmpl := "/home/z/my-project/public/models/retroblox-rig-template.glb"
        if FileAccess.file_exists(tmpl):
                var ok2: bool = rig.call("start_custom_emote", tmpl, "")
                if ok2:
                        print("CUSTOM_EMOTE_TEST: FAIL no-anim model should be rejected")
                        failures += 1
                else:
                        print("CUSTOM_EMOTE_TEST: no-anim glb rejected cleanly ok")
        else:
                print("CUSTOM_EMOTE_TEST: (template glb not found on disk — skipped)")

        # ---- 5. built-in emotes still work after all that ---------------
        var ok3: bool = rig.call("start_emote", "wave")
        if not ok3 or rig.get("_emote") != "wave":
                print("CUSTOM_EMOTE_TEST: FAIL built-in wave broke")
                failures += 1
        else:
                print("CUSTOM_EMOTE_TEST: built-in wave still ok")

        if failures == 0:
                print("CUSTOM_EMOTE_TEST: ALL PASS")
                quit(0)
        else:
                print("CUSTOM_EMOTE_TEST: %d FAILURES" % failures)
                quit(1)


## Build a tiny model (box mesh on a pivot) with one looping position clip
## and export it as a binary glTF through GLTFDocument's own exporter.
func _export_test_glb() -> bool:
        var model := Node3D.new()
        model.name = "EmoteModel"
        var mi := MeshInstance3D.new()
        mi.name = "Box"
        mi.mesh = BoxMesh.new()
        mi.mesh.size = Vector3(1, 2, 1)
        model.add_child(mi)
        var ap := AnimationPlayer.new()
        model.add_child(ap)
        var lib := AnimationLibrary.new()
        var anim := Animation.new()
        anim.length = 1.0
        var track := anim.add_track(Animation.TYPE_VALUE)
        anim.track_set_path(track, "Box:position")
        anim.track_insert_key(track, 0.0, Vector3.ZERO)
        anim.track_insert_key(track, 0.5, Vector3(0, 1.5, 0))
        anim.track_insert_key(track, 1.0, Vector3.ZERO)
        lib.add_animation("Wave", anim)
        ap.add_animation_library("", lib)

        var doc := GLTFDocument.new()
        var state := GLTFState.new()
        var err := doc.append_from_scene(model, state)
        if err != OK:
                print("CUSTOM_EMOTE_TEST: append_from_scene err=%d" % err)
                return false
        var bytes := doc.generate_buffer(state)
        if bytes.is_empty():
                return false
        var f := FileAccess.open(TEST_GLB, FileAccess.WRITE)
        f.store_buffer(bytes)
        f.close()
        return FileAccess.file_exists(TEST_GLB)
