# CHANGELOG

## [2.5.stable](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.5.stable) - 2026-07-03

- [836702d3](http://github.com/CraterCrash/godot-orchestrator/commit/836702d3328503c06caea801937680def2e835b4) - GH-1694 Use main thread script loading on main thread
- [849951ca](http://github.com/CraterCrash/godot-orchestrator/commit/849951ca027ee54a325a783c3736f80f5fc21726) - GH-1694 Add integration test to GitHub CI
- [80e3e6be](http://github.com/CraterCrash/godot-orchestrator/commit/80e3e6bebe2e5d94da1827e957a28a1a967365d1) - GH-1694 Avoid crash in OScriptLanguage get_global_map index-accessor
- [4540b5b0](http://github.com/CraterCrash/godot-orchestrator/commit/4540b5b083e20572524a351f8942ec68668af165) - GH-1694 Improve test harness
- [0fab1ac2](http://github.com/CraterCrash/godot-orchestrator/commit/0fab1ac299abcf1be196b9e35e621af27d7b5d7a) - GH-1694 Fix editor crash when doing a headless import
- [fad749ee](http://github.com/CraterCrash/godot-orchestrator/commit/fad749ee87b600c506f4f5cf208dd720b6d333fc) - GH-1689 Fix collapse to function / expand node behavior
- [e60fa319](http://github.com/CraterCrash/godot-orchestrator/commit/e60fa3190532a245d86fa08edf5cbb2b90db092f) - GH-1688 Treat `_shortcut_input` as an event node type
- [926b1976](http://github.com/CraterCrash/godot-orchestrator/commit/926b197638d04335d1c8e7d343cdb46ad6d45988) - GH-1687 Do not include local variable nodes in event graphs
- [4ca15d9e](http://github.com/CraterCrash/godot-orchestrator/commit/4ca15d9e40c26b67b0ac91712223d1a90ab8da4a) - GH-1684 Improve save performance
 
## [2.5.rc2](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.5.rc2) - 2026-06-29

- [8ec26a27](http://github.com/CraterCrash/godot-orchestrator/commit/8ec26a27e262698f233f34847b3cba833af4fd66) - GH-1672 Improve the performance of switch nodes
- [515f4705](http://github.com/CraterCrash/godot-orchestrator/commit/515f4705215cf526ecff3e74fc7354ba239342a0) - GH-1672 Improve has_any_connections/get_connection
- [83564965](http://github.com/CraterCrash/godot-orchestrator/commit/83564965b7a127c182714ce34671cf5c6b29159d) - GH-1672 Gate function analyzer warnings
- [1ba8360f](http://github.com/CraterCrash/godot-orchestrator/commit/1ba8360f0325879f5f75bec5b679fa403d56c18f) - GH-1672 Improve connection lookup performance
- [e1299d6f](http://github.com/CraterCrash/godot-orchestrator/commit/e1299d6f8e92e76739fc874f22f4736e2e96ce1c) - GH-1672 Reduce node pin collection allocations
- [3e1e9638](http://github.com/CraterCrash/godot-orchestrator/commit/3e1e9638189af271a80de7eaef0707aa196a9275) - GH-1672 Remove container hashes of Ref objects
- [cec93579](http://github.com/CraterCrash/godot-orchestrator/commit/cec935790b0d35b5025547aa2adad1b707990d31) - GH-1672 Cache control flow successors in function analysis
- [dd6649a6](http://github.com/CraterCrash/godot-orchestrator/commit/dd6649a6f049358fa557445e2813292543f87210) - GH-1672 Fix loops breaking linear execution order
- [08d4b4f4](http://github.com/CraterCrash/godot-orchestrator/commit/08d4b4f458d50612402a32ff87b705d492877993) - GH-1676 Short-circuit get_operator_type for known bool results
- [1eb643e0](http://github.com/CraterCrash/godot-orchestrator/commit/1eb643e0ca16c64f7c2182298cfaac2a81015ec4) - GH-1675 Allow property selector to work with class name types
- [a305de0b](http://github.com/CraterCrash/godot-orchestrator/commit/a305de0bbd0a1cc3a48b3d9c7e37ee25b8581fb7) - GH-1664 Support PringStringOverlay with CanvasLayers
- [468688c4](http://github.com/CraterCrash/godot-orchestrator/commit/468688c4004abdc5ec9aa9c08218534a253eb8de) - GH-1667 Improve integration test runner
- [8bc1c046](http://github.com/CraterCrash/godot-orchestrator/commit/8bc1c046c8cf406fadef74a2129c143398831c8e) - GH-1667 Fix integration tests, clean/import before run
- [d5827430](http://github.com/CraterCrash/godot-orchestrator/commit/d5827430df7b8e549fa955aed855e3a0cbd914bc) - GH-1667 Fix script node provenance
- [03245b53](http://github.com/CraterCrash/godot-orchestrator/commit/03245b534075871db7799eb8ee1a2adc2f1b6c1c) - GH-1662 Add test case
- [655b3acd](http://github.com/CraterCrash/godot-orchestrator/commit/655b3acd62b759e604ce8e5a9f46010509402a80) - GH-1662 Fix heterogeneous type resolution in generic switch
- [099862c2](http://github.com/CraterCrash/godot-orchestrator/commit/099862c28807d7b74dabffbfe10398db218bf69d) - GH-1661 Fix includes
- [ca3f15b5](http://github.com/CraterCrash/godot-orchestrator/commit/ca3f15b552da3f57bdc89417d5d511dfac2d9642) - GH-1661 Fix typed container variable serialization
- [dd0e3f98](http://github.com/CraterCrash/godot-orchestrator/commit/dd0e3f98661fd0d8cfc456507448f2c59272e9d3) - GH-1663 Limit test case to Godot 4.5+
- [7a6f9e23](http://github.com/CraterCrash/godot-orchestrator/commit/7a6f9e23168a89915dc896702125e401b387ed17) - GH-1663 Add test case
- [9e5d8744](http://github.com/CraterCrash/godot-orchestrator/commit/9e5d87448e770e1248d8caaa7ba7d3d0a6fedca9) - GH-1663 Fix script instance assignment (Godot 4.5+)
- [9887d775](http://github.com/CraterCrash/godot-orchestrator/commit/9887d775253e02977f81823abc29a8296aecb19c) - GH-1656 Update to SCons 4.10.1
- [a86fe1b7](http://github.com/CraterCrash/godot-orchestrator/commit/a86fe1b73d9731bc73d9f3e7fb6b16a88168b682) - GH-1657 Fix Brew tap warnings for macOS/iOS
- [6b3aa520](http://github.com/CraterCrash/godot-orchestrator/commit/6b3aa520cd08feb6c9472314894fca8ee3b1d469) - GH-1649 Improve promotable operator node behavior
- [e26b118f](http://github.com/CraterCrash/godot-orchestrator/commit/e26b118f46c855021fc4929908d4a2a38038ee30) - GH-1648 Fix dependency check using For with Break
- [68cee772](http://github.com/CraterCrash/godot-orchestrator/commit/68cee772acfd3c37b583680cc6ceb29edb496e80) - GH-1650 Fix Set Array Element with resize
- [0f931ec2](http://github.com/CraterCrash/godot-orchestrator/commit/0f931ec27ff8190998b1b6d0b63658ec467056be) - GH-1651 Fix "[Self]" pin label assignment
- [3553faf4](http://github.com/CraterCrash/godot-orchestrator/commit/3553faf41bb93673d04ba7d62dffcb2817767445) - GH-1646 Fix delete context menu signal binding

## [2.5.rc1](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.5.rc1) - 2026-06-20

- [d96bf590](http://github.com/CraterCrash/godot-orchestrator/commit/d96bf590b2411c31774bac53f93d3a7055a0eed7) - GH-281 Introduce new promotable/dynamic operator nodes
- [d4ab74c6](http://github.com/CraterCrash/godot-orchestrator/commit/d4ab74c6b1d07fadfafc6560bfc85d3f57c72edc) - GH-1643 Request restart when required for specific properties
- [c457c8db](http://github.com/CraterCrash/godot-orchestrator/commit/c457c8db7a053e4b2b39964b7ad5c50dd072e344) - GH-1635 Fix bitwise to boolean operator
- [045424ef](http://github.com/CraterCrash/godot-orchestrator/commit/045424ef0b399ba89c9641f90e20334e2a610cd2) - GH-1636 Remove C++23 usage
- [eb27eeb0](http://github.com/CraterCrash/godot-orchestrator/commit/eb27eeb077797c09abc79b780d5dfdd4190e981e) - GH-1522 Support for Godot 4.7 / GDExtension v10
- [fcc602b8](http://github.com/CraterCrash/godot-orchestrator/commit/fcc602b85ea7b2c513b214c10972b6b88324fa1e) - GH-859 Experimental support for iOS platforms
- [334df7de](http://github.com/CraterCrash/godot-orchestrator/commit/334df7dec414923b6e965480bd3ebd428068be72) - GH-367 New Settings Dialog / Configurable Keybinds
- [6d30c3b1](http://github.com/CraterCrash/godot-orchestrator/commit/6d30c3b10eff2a90027b66d9474c00dc867c7a96) - GH-1625 Fix compilation with release builds
- [a9e3739a](http://github.com/CraterCrash/godot-orchestrator/commit/a9e3739a98858635bf74c3aa51ba82bc85ce14b5) - GH-1625 Improve load/save performance
- [212bfc7e](http://github.com/CraterCrash/godot-orchestrator/commit/212bfc7e7ca813ee8c1316908e65b757c8b90f06) - GH-1622 Fix double-click selection on changing base type
- [d08425e1](http://github.com/CraterCrash/godot-orchestrator/commit/d08425e11573da71d43751a38e75254dd42ea6f2) - GH-1623 Add make/break nodes as eligible drag operations
- [c781434f](http://github.com/CraterCrash/godot-orchestrator/commit/c781434f4bd236d6095b9a25ad85fd40e3fc2e81) - GH-1624 Change node action delete to use current selection
- [2ca58bc3](http://github.com/CraterCrash/godot-orchestrator/commit/2ca58bc3905286163208dc055a95bc7255c36193) - GH-806 Support Typed Arrays and Dictionaries
- [f57424e9](http://github.com/CraterCrash/godot-orchestrator/commit/f57424e94c97641dc6fa6cb21f33293a9dd6137d) - GH-1611 Use `Engine.get_main_loop().create_timer` for Delay
- [413410d9](http://github.com/CraterCrash/godot-orchestrator/commit/413410d903da3ef932783e5625278bb675f9cf41) - GH-1611 Fix dereferencing of a null object
- [73b5c8a7](http://github.com/CraterCrash/godot-orchestrator/commit/73b5c8a7f1ebf6b5ae511c62fecf9deb9cf47f9f) - GH-1610 Fix resetting using clear/reset button
- [1702bfaf](http://github.com/CraterCrash/godot-orchestrator/commit/1702bfaf9cbdf3e8f120913bb710fb1ff7777e26) - GH-1610 Fix file pin button removal on cancel
- [acdb880b](http://github.com/CraterCrash/godot-orchestrator/commit/acdb880b4a1b9db8c81932dbf5a90fc736e2b206) - GH-1612 Add additional keywords to type cast node
- [9933c167](http://github.com/CraterCrash/godot-orchestrator/commit/9933c1678f456cb4c4335451954c5056b349b6f4) - GH-1613 Fix Light theme inconsistencies
- [6d2982fb](http://github.com/CraterCrash/godot-orchestrator/commit/6d2982fb57cb1d29471576293ea4dadb593108d2) - GH-1412 Fix Set Dictionary Item error message
- [fc43fbe0](http://github.com/CraterCrash/godot-orchestrator/commit/fc43fbe05818d13d1ae97830b24c5d75b989691b) - GH-698 Small tweak to component panel themes
- [2f4c99f7](http://github.com/CraterCrash/godot-orchestrator/commit/2f4c99f7b33e05baedc91d9c15144fb56716c448) - GH-698 Custom theme options
- [f9eb34d8](http://github.com/CraterCrash/godot-orchestrator/commit/f9eb34d82b8e940c9ad607539352197c2a1be7f7) - GH-1604 Fix base type icon resolution
- [7e4a9b0c](http://github.com/CraterCrash/godot-orchestrator/commit/7e4a9b0cb705af5263078316499717f8926db78c) - GH-1475 Support await coroutines / non-coroutine methods
- [e848ea3e](http://github.com/CraterCrash/godot-orchestrator/commit/e848ea3e7407b6fa9ae32c9da0dc35a779864b5a) - GH-1597 Fix test memory leak
- [32885ab4](http://github.com/CraterCrash/godot-orchestrator/commit/32885ab4486a0beb522f5a2e236dc3873754084f) - GH-1597 Fix parse error calling script-instance functions
- [cdd5b3cb](http://github.com/CraterCrash/godot-orchestrator/commit/cdd5b3cbcd257ae348e4409a5b2636812316f829) - GH-1600 Avoid calling OScript `_init` twice
- [d258863c](http://github.com/CraterCrash/godot-orchestrator/commit/d258863cb4e331fbcefbfa902d180eb94447ae3d) - GH-1599 Allow `Free Object` to deallocate `RefCounted` objects
- [8e6c2c37](http://github.com/CraterCrash/godot-orchestrator/commit/8e6c2c37cf261eb2a8da9342d73b1048fd909e85) - GH-1595 Fix evaluation of OPCODE_OPERATOR_EVALUATE
- [0dcbccf3](http://github.com/CraterCrash/godot-orchestrator/commit/0dcbccf32b807b9dbcb90f77630361fd3bbe8f9c) - GH-1547 Add graph toolbar toggle buttons
- [680d8e03](http://github.com/CraterCrash/godot-orchestrator/commit/680d8e03945fbd46fc13555f9ab8a7bd627d7982) - GH-1148 Allow script nodes to be selected on drag
- [5ae4820d](http://github.com/CraterCrash/godot-orchestrator/commit/5ae4820dc38ca97e2c230b655a2a3450c16201e1) - GH-1573 Fix Godot compatibility w/LocalVector
- [8a9d54d4](http://github.com/CraterCrash/godot-orchestrator/commit/8a9d54d450c327cecb99afcb64e6db1058b9fc7b) - GH-1573 Fix connected function argument removal
- [c9dd30f6](http://github.com/CraterCrash/godot-orchestrator/commit/c9dd30f67813cb35232c03154fedcb9ed56a805b) - GH-1574 Avoid crash resolving unknown variable icon
- [2bb2717c](http://github.com/CraterCrash/godot-orchestrator/commit/2bb2717c1d28c54b79e533ded56728e6ed05fe31) - GH-1588 Improve compatibility with Modern theme
- [e550707e](http://github.com/CraterCrash/godot-orchestrator/commit/e550707e6648fdc41c83572bc2e6cd41ff5aa615) - GH-1576 Support switch on class-scoped enums
- [f7306946](http://github.com/CraterCrash/godot-orchestrator/commit/f73069460d35b6104a77d94fda79bbb3f19ebba3) - GH-1586 Fix ObjectDB leak in ScriptServer
- [3e7011c6](http://github.com/CraterCrash/godot-orchestrator/commit/3e7011c658fad09a503a806ebe47bc1b81ea1cec) - GH-1580 Use multi-frame action search
- [36125850](http://github.com/CraterCrash/godot-orchestrator/commit/36125850ef928425a1d727c2e9be33c8fd2ebebc) - GH-1571 Fix hotkey conflict ui_copy vs create frame
- [0b8f30ba](http://github.com/CraterCrash/godot-orchestrator/commit/0b8f30babe1973cbe4b50e5aee0ce8b28d9c479a) - GH-1578 Fix hotzone logic for dialogue message nodes
- [6e2ae06a](http://github.com/CraterCrash/godot-orchestrator/commit/6e2ae06aef30d2012eb011ccd00584ab5acab7d9) - GH-1569 Fix editor plugin unref memory leak
- [6c791340](http://github.com/CraterCrash/godot-orchestrator/commit/6c7913403a86d6c4b9772c5a81ac5a305bed095f) - GH-1559 Identify and report cyclic control/data flows
- [300a419b](http://github.com/CraterCrash/godot-orchestrator/commit/300a419bc0a856b9d636d901a82445034285a8aa) - GH-463 Fix Godot 4.4 compatibility
- [0658df78](http://github.com/CraterCrash/godot-orchestrator/commit/0658df78fbe5eb1491a68c5856b9db7cb933f249) - GH-1558 Fix Godot 4.4 compatibility
- [871cd20b](http://github.com/CraterCrash/godot-orchestrator/commit/871cd20b21391df0d9609f0c2c4d4e917e0175d6) - GH-463 Support changing comments, fix deletes
- [7e56b84d](http://github.com/CraterCrash/godot-orchestrator/commit/7e56b84d2e7f809c8f1ca6db002df6257e8b762d) - GH-463 Add keybind `C` to create frames
- [c41355cf](http://github.com/CraterCrash/godot-orchestrator/commit/c41355cfe46c53f069dd11dfa99942c283b13a57) - GH-463 Implement `GraphFrame`, replaces old comments
- [4e66ce83](http://github.com/CraterCrash/godot-orchestrator/commit/4e66ce83b10bfde73f1b7ae3ab35f457942ee85b) - GH-1553 Use `windows-2022` runners for Windows
- [155a6806](http://github.com/CraterCrash/godot-orchestrator/commit/155a6806f01f339f3818d8fcd2bef5c8af9c5bbf) - GH-1558 Fix crash when autowiring self nodes
- [e94281e7](http://github.com/CraterCrash/godot-orchestrator/commit/e94281e7b6dedd583f9612d5fa5ae12c97716c5a) - GH-1563 Fix variable defined as enum/bitfields
- [a51532f1](http://github.com/CraterCrash/godot-orchestrator/commit/a51532f17a6060f8094408d9379086245f8170a4) - GH-1561 Correctly resolve global enum/bitfield type
- [4e9dc12f](http://github.com/CraterCrash/godot-orchestrator/commit/4e9dc12feb26bcdd090efaf5d1e6efeb4f854452) - GH-1554 Add missing OP_XOR handler to binary_op
- [c16917fc](http://github.com/CraterCrash/godot-orchestrator/commit/c16917fc69648e6aa9b105e27dbcc626435f0cf5) - GH-1548 Add secondary ClassDB `MethodInfo` lookup
- [de5d2b55](http://github.com/CraterCrash/godot-orchestrator/commit/de5d2b5578cf6d12fa7708eb4a498c55d535d21d) - GH-1549 Correctly apply serialized version to Orchestration
- [3932fac3](http://github.com/CraterCrash/godot-orchestrator/commit/3932fac3f0681611ac0815facbbb65c53e95a354) - GH-758 Support reroute branching
- [fdd034d4](http://github.com/CraterCrash/godot-orchestrator/commit/fdd034d48923fad14fc2f2a2bf8a4191e38c4d1d) - GH-1540 Fix enum/bitfield value resolution
- [5c322668](http://github.com/CraterCrash/godot-orchestrator/commit/5c322668fc33acff705835a7f22e0f522dc50d3f) - Update README about branch development status
- [3d183b81](http://github.com/CraterCrash/godot-orchestrator/commit/3d183b814b59b37af90aba04a265c5215ab710ce) - GH-1534 Apply temp file prefix when making templates

## [2.5.dev1](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.5.dev1) - 2026-04-26

- [d4ce97fa](http://github.com/CraterCrash/godot-orchestrator/commit/d4ce97faec1e882237940d8940ae29ae67ef4fe9) - GH-1531 Fix typo in orchestration list context menu
- [a6e26670](http://github.com/CraterCrash/godot-orchestrator/commit/a6e26670ebc00eff02f8b42f8fe9f8f71868e3e5) - GH-1529 Fix message_queue error when dialog opened
- [dc8b6a4e](http://github.com/CraterCrash/godot-orchestrator/commit/dc8b6a4eeed4c47f7dce0c2020b4a28336e9f1ed) - GH-1507 Improve action dialog performance
- [39903489](http://github.com/CraterCrash/godot-orchestrator/commit/399034898e8f06e0d409fb3c84c9d6409dad3d3d) - GH-1519 Fix script extends widget behavior
- [cd8d12f5](http://github.com/CraterCrash/godot-orchestrator/commit/cd8d12f571873d9b121704de9155c54806252705) - GH-1477 Avoid crash dragging from get self node
- [ec7e6363](http://github.com/CraterCrash/godot-orchestrator/commit/ec7e636355fb306e94522d8c13df06e8342af9c8) - GH-1472 Update callable references when script function renamed
- [ec5f2f12](http://github.com/CraterCrash/godot-orchestrator/commit/ec5f2f12746f63c027c070a2aee9b3416a5c319d) - GH-1515 Cleanup editor plugins on exit
- [3690b6e5](http://github.com/CraterCrash/godot-orchestrator/commit/3690b6e5a540a1c2e40ba3849a7dfd1577ce7120) - GH-1510 Add script filename button to UI
- [4bbeb479](http://github.com/CraterCrash/godot-orchestrator/commit/4bbeb47939b019754345240071e2e36e00df8788) - GH-1508 Reorganize orchestration specific files
- [ee197852](http://github.com/CraterCrash/godot-orchestrator/commit/ee1978529ddc1a9c5a871f747991a8507647926b) - GH-1500 Refactor bookmark/breakpoint into graph marker class
- [baef71e5](http://github.com/CraterCrash/godot-orchestrator/commit/baef71e538f57a4780af003c723b2716b4f417ea) - GH-1498 Improve graph clipboard operations
- [c7a1e0f4](http://github.com/CraterCrash/godot-orchestrator/commit/c7a1e0f418759a7a31ff11c7c724330f3455d666) - GH-1478 Use GDE::ResourceUID::uid_to_path
- [306728df](http://github.com/CraterCrash/godot-orchestrator/commit/306728df4c8c5e834a5b409a5e28c4011056f0d3) - GH-1478 Correctly resolve self node titlebar icon
- [61fbfd57](http://github.com/CraterCrash/godot-orchestrator/commit/61fbfd5742923f60b6b5675fcaf2375f2012c463) - GH-1494 Code cleanup
- [20b8e2a2](http://github.com/CraterCrash/godot-orchestrator/commit/20b8e2a2c0d46adcc16fcc8bd1edbf915dd2ef49) - GH-1494 Reduce number of DFS in OScriptFunctionAnalyzer
- [df6d85fc](http://github.com/CraterCrash/godot-orchestrator/commit/df6d85fcc0d36d12ad93808d626556f8d7fdaa2b) - GH-1492 Avoid crashes during orphan fix-ups
- [0d76a916](http://github.com/CraterCrash/godot-orchestrator/commit/0d76a916d12eccce69e089d88db7faa035f6cf70) - GH-1490 Avoid crashes with utility functions, e.g `abs`
- [c29d01db](http://github.com/CraterCrash/godot-orchestrator/commit/c29d01db27a040734c7c475fd552d91eb5767577) - GH-1488 Fix duplicate_resource test for Godot 4.4
- [456fdf20](http://github.com/CraterCrash/godot-orchestrator/commit/456fdf205cf5a8d3009dda72ca2a0eb263cda573) - GH-1447 Fix missing import for older branches
- [f5cfe71f](http://github.com/CraterCrash/godot-orchestrator/commit/f5cfe71f4db0e66f24349f3ab50389e68b824292) - GH-1486 Normalize C++ line numbers for integration tests
- [44cad763](http://github.com/CraterCrash/godot-orchestrator/commit/44cad763c29a6cb0277cf611537bd9b6ebded015) - GH-1447 Fix calling static methods in native base classes
- [1bae53bf](http://github.com/CraterCrash/godot-orchestrator/commit/1bae53bf62b4be05f6ffae5cd7d93aa411a0640d) - GH-1484 Don't attempt to register function localvars twice
- [c89024fa](http://github.com/CraterCrash/godot-orchestrator/commit/c89024fa344e4522807c004168576619181930fe) - GH-1482 Fix non-OScript static function call resolution
- [0719b5ec](http://github.com/CraterCrash/godot-orchestrator/commit/0719b5ec4f8fc1f0c51cbf1661eaa85fd5656391) - GH-1455 Don't cleanup other scripts
- [79452de2](http://github.com/CraterCrash/godot-orchestrator/commit/79452de2551989b95335196b4c4228f58e964288) - GH-1441 Deprecate `type_exists` OScript utility function
- [5da05df7](http://github.com/CraterCrash/godot-orchestrator/commit/5da05df7e8ad6e4b0b3f6c5983ee4feef2b4fc92) - GH-1469 Override parent script methods using the override button
- [c4902ceb](http://github.com/CraterCrash/godot-orchestrator/commit/c4902cebaed029021f7f5a3c8097dd50dee633c4) - GH-1480 Use script _to_string override if present
- [b042b672](http://github.com/CraterCrash/godot-orchestrator/commit/b042b6728eeed49ff236b00bb65d0f88dbc93e5c) - GH-1428 Omit backtrace checks for Godot 4.4
- [a5bb5d09](http://github.com/CraterCrash/godot-orchestrator/commit/a5bb5d097c2cdd2b3f50334b2e2f702b88997eee) - GH-1428 Paginate release lookup
- [59fb5703](http://github.com/CraterCrash/godot-orchestrator/commit/59fb5703972e02b9f750ae71c9407280c26efec7) - GH-1428 Add test for assignment member as self
- [cdcb1fe1](http://github.com/CraterCrash/godot-orchestrator/commit/cdcb1fe16abffa3ee8dca1fe6f1189ab042f435e) - GH-1428 Orchestrator test suite
- [32a219a3](http://github.com/CraterCrash/godot-orchestrator/commit/32a219a30ed61062eed40075d5fd8a21683b51fb) - GH-1473 Resolve await signal node as self by default
- [f55cbf89](http://github.com/CraterCrash/godot-orchestrator/commit/f55cbf89aba9e3ded07cedf5630b363eed13a644) - GH-1467 Register const variables as ConstantNode in AST
- [98554ee3](http://github.com/CraterCrash/godot-orchestrator/commit/98554ee339cbaf07fb18bc7da4b4fdf44110cb71) - GH-1464 Skip self assignment to avoid variant corruption
- [9035951e](http://github.com/CraterCrash/godot-orchestrator/commit/9035951e71f0efad247849f5cb154674c5001fad) - GH-1362 Resolve NodePath relative to attached script node
- [15fb23d5](http://github.com/CraterCrash/godot-orchestrator/commit/15fb23d5abdc241713472f87f9946e0a43e7bfdb) - GH-1445 Fix interrupted coroutines not clearing properly
- [62d2d573](http://github.com/CraterCrash/godot-orchestrator/commit/62d2d573adafa62947727e63930e0c2153acdc3e) - GH-1366 Do not crash during interlanguage circular dependencies
- [8b4d322a](http://github.com/CraterCrash/godot-orchestrator/commit/8b4d322ae6f061ba54fe47dbbfed6cf94d99a0a0) - GH-1457 Improve evaluation of constant expressions with arrays/dictionaries
- [d8668d2a](http://github.com/CraterCrash/godot-orchestrator/commit/d8668d2a0c894fa1a9127f409f597df202f74ef4) - GH-1443 Fix inferred function return type resolution
- [cecca371](http://github.com/CraterCrash/godot-orchestrator/commit/cecca371792178f8a1e3ab39be708ba6fd0b7c1d) - GH-1459 Fix "trying to resolve type of null node" when missing condition
- [6ddf3709](http://github.com/CraterCrash/godot-orchestrator/commit/6ddf3709026e190f4eb72e676a8e58091e4aaa09) - GH-1439 Fix `_get_var_type` availability
- [71e35c2b](http://github.com/CraterCrash/godot-orchestrator/commit/71e35c2befd57218f2287003460d9c781f014293) - GH-1439 Fix compiler generating incorrect bytecode for conversion return
- [8c3e3440](http://github.com/CraterCrash/godot-orchestrator/commit/8c3e3440ff2cfa7a9fe0065da3c40ebbcf3b3ae0) - GH-1451 Only increment parser status, avoiding re-analysis
- [c6cac2f1](http://github.com/CraterCrash/godot-orchestrator/commit/c6cac2f1c96c3bcbbb6e256d8fe9f4e8378d3fd9) - GH-1435 Correctly resolve callable unbounded arg counts
- [d80a8776](http://github.com/CraterCrash/godot-orchestrator/commit/d80a8776ffa21acbd225ca30e2d197ac58a3ee16) - GH-1449 Improve display of non-exported members in Remote Tree Inspector
- [00621ecd](http://github.com/CraterCrash/godot-orchestrator/commit/00621ecdb33f8603e1864574f7c9319ba587f43e) - GH-1430 Introduce `assert` node for editor/debug builds
- [cd342011](http://github.com/CraterCrash/godot-orchestrator/commit/cd3420110b259386e3e4a516b4f5fc44db7f1d7b) - GH-1453 Remove unused `unload_static` method
- [b45801ee](http://github.com/CraterCrash/godot-orchestrator/commit/b45801eea22d3ae935dcf7b1bd0c10b4a618df69) - GH-1461 Add env variable
- [977c33c9](http://github.com/CraterCrash/godot-orchestrator/commit/977c33c9b1158f9b47838799ce50dc3c1436c264) - GH-1461 Introduce cache warmer workflow
- [b35ee75d](http://github.com/CraterCrash/godot-orchestrator/commit/b35ee75d1040bd9bbf34af7fb085093d229a4987) - GH-1368 Prevent crash due to Godot 4.7 regression
- [cb1eee5c](http://github.com/CraterCrash/godot-orchestrator/commit/cb1eee5ce1c5c2f6580e2068b5dbef2a6b4058f3) - GH-1390 Fix and simplify coroutine stack clearing
- [b7c27374](http://github.com/CraterCrash/godot-orchestrator/commit/b7c27374074aa4acd8d70b9f56776de4db74140e) - GH-1433 Do not reset connect signal name on pin changes
- [19a2c369](http://github.com/CraterCrash/godot-orchestrator/commit/19a2c3696f3a4d9293af49fadde2d1414974d5f8) - GH-1431 Fix creating new class instance based on OScript
- [1ec90ea8](http://github.com/CraterCrash/godot-orchestrator/commit/1ec90ea80f3b22cca096503c92c5431dcccad996) - GH-1410 Fix resolving input when variable set output pin is used
- [0121370e](http://github.com/CraterCrash/godot-orchestrator/commit/0121370e87eb04415f33998efdba0f6356ca136d) - GH-1422 Fix `Variant::get_validated_object_with_check` return freed state
- [8699b30f](http://github.com/CraterCrash/godot-orchestrator/commit/8699b30fef9dcd69b9858eeefac10e16562d2185) - GH-1420 Fix crash calling builtin static methods
- [e65cddb3](http://github.com/CraterCrash/godot-orchestrator/commit/e65cddb337ac38a1c78a724c21c7c747519d6fc7) - GH-1424 Do not share array/dictionary instances
- [774e45f6](http://github.com/CraterCrash/godot-orchestrator/commit/774e45f6246ecc411096b2fdf3243104823fa19a) - GH-1426 Return `await` result, if one is available
- [2b61dd9f](http://github.com/CraterCrash/godot-orchestrator/commit/2b61dd9f249abd8280dc882d97ef4dc91a6db054) - GH-1380 Fix editor creating presets config unnecessary
- [3868a9f9](http://github.com/CraterCrash/godot-orchestrator/commit/3868a9f9a675f50ce78b4abad0c4e7f468c460d3) - GH-1399 Include inherited non-named script members
- [cb968ab7](http://github.com/CraterCrash/godot-orchestrator/commit/cb968ab7dd559c4eed122680d06256cbd95a9890) - GH-1381 Set search box caret to end of text
- [6c4116af](http://github.com/CraterCrash/godot-orchestrator/commit/6c4116afbede9b8841b6501b22c345874f12ed0f) - GH-1381 Fix action matching algorithm
- [6acd9eb0](http://github.com/CraterCrash/godot-orchestrator/commit/6acd9eb0bec7536697ad71ab652ddd2a5cce0a0d) - GH-1403 Fix connecting signals with bind values
- [13f5cb97](http://github.com/CraterCrash/godot-orchestrator/commit/13f5cb974bfa40668ad4f21340c12c36011f16c4) - GH-1379 Reset orchestration edit state when reloaded
- [5c020b1e](http://github.com/CraterCrash/godot-orchestrator/commit/5c020b1e163cab580090fea4c62f1797935bf7cc) - GH-1382 Save user data on canceled signal
- [c2e0be1b](http://github.com/CraterCrash/godot-orchestrator/commit/c2e0be1b4294a8ae6f660c2492a181de83ad3942) - GH-1377 Avoid spawning multiple call to parent nodes
- [fde9d8a2](http://github.com/CraterCrash/godot-orchestrator/commit/fde9d8a24c7e5c4f5a77ed178b8c30a35d32b58f) - GH-1386 Update OScriptCache when moving open script files
- [d6b08ad9](http://github.com/CraterCrash/godot-orchestrator/commit/d6b08ad98f1025ab135e0e510d7b667b97699ff7) - GH-1402 Treat self as Global Class if named class
- [b3bf60e4](http://github.com/CraterCrash/godot-orchestrator/commit/b3bf60e4744abbcee787fb59996be53b6b01e117) - GH-1392 Allow overriding `_set` and `_get`
- [7402df14](http://github.com/CraterCrash/godot-orchestrator/commit/7402df142213618bf1d44d731965a94df22e2d9e) - GH-1364 Fix crash when duplicating functions
- [fb80d33c](http://github.com/CraterCrash/godot-orchestrator/commit/fb80d33c5158e5997861f236a4176b99f8b380e1) - GH-1365 Avoid unnecessary component panel refreshes
- [db81b41c](http://github.com/CraterCrash/godot-orchestrator/commit/db81b41cf80d6b4430fbb976878c3661fcdb7ce4) - GH-1361 Prevent TextEdit entry being backward
- [4d1c2b0f](http://github.com/CraterCrash/godot-orchestrator/commit/4d1c2b0f5511620b891a49c2b0a16df7cf679a85) - GH-1367 Fix preload of non-OScript resources
- [a12a3872](http://github.com/CraterCrash/godot-orchestrator/commit/a12a3872622417dc1e464c57913dc14893358568) - GH-1356 Fix crash connecting to while node
- [1f532634](http://github.com/CraterCrash/godot-orchestrator/commit/1f53263484e399fca55fc6a35c6222d4416c217f) - GH-1283 Remove support for Godot 4.2 and 4.3
- [e1cb927b](http://github.com/CraterCrash/godot-orchestrator/commit/e1cb927b12316ad8b47f698c138114210e282e06) - GH-1347 Make several UI code performance improvements
- [5076ac0a](http://github.com/CraterCrash/godot-orchestrator/commit/5076ac0ad08dca1b0f889123dc6d1efdd3b2fc25) - GH-1343 Fix collapse nodes to function behavior
- [0e1e0218](http://github.com/CraterCrash/godot-orchestrator/commit/0e1e0218b052113da99fd186bbd39268257a4b24) - GH-1345 Fix Guid thread-safety & validity check
- [389b3da6](http://github.com/CraterCrash/godot-orchestrator/commit/389b3da6a19dcbf920c212c2ffad9705e10654ff) - GH-1349 Use correct null-check in `GDE::Variant::is_null`
- [00dabc52](http://github.com/CraterCrash/godot-orchestrator/commit/00dabc5251cb69ba84b8aebf0d9cdbfa43263398) - GH-1351 Correctly handle signal bindings on tree exit
- [dd78299e](http://github.com/CraterCrash/godot-orchestrator/commit/dd78299e236b98ceef25ecb83997f31d85426115) - GH-1357 Fix Stylebox and Editor crash on macOS
- [33840c88](http://github.com/CraterCrash/godot-orchestrator/commit/33840c88ee5657c29796b62a1a4d6198dac7f08e) - Style: Replace header guards with `#pragma once`
- [d0863725](http://github.com/CraterCrash/godot-orchestrator/commit/d0863725a8308980054ae6daaed2a44c3212224c) - GH-1340 Refresh ConnectionsDock on signal disconnect
- [40a7fc21](http://github.com/CraterCrash/godot-orchestrator/commit/40a7fc218ad46e02c9c8753b15ed6d0aadae2d72) - GH-709 Support connection straightening
- [8895077a](http://github.com/CraterCrash/godot-orchestrator/commit/8895077a4857eefa8f9820d29a9c5429488ea671) - GH-1337 Fix script list highlighting
- [966def3a](http://github.com/CraterCrash/godot-orchestrator/commit/966def3aee5717da4ae10d3b6b02a336f1151cd2) - GH-1329 Allow using arrow keys in search dialogs
- [c2f22429](http://github.com/CraterCrash/godot-orchestrator/commit/c2f22429fb67a3c03c63567b0b4f29d4e1a1cd20) - GH-1327 Avoid get_function_node_id error
- [affdae04](http://github.com/CraterCrash/godot-orchestrator/commit/affdae04b9cd4ec869b26fd004dd45fde06fc399) - GH-1325 Fix `_init` method not being called
- [a0d3462e](http://github.com/CraterCrash/godot-orchestrator/commit/a0d3462e8cb4d0352443bb09437fdcefbcd60725) - GH-1316 Fix crash when removing function
- [82e6df74](http://github.com/CraterCrash/godot-orchestrator/commit/82e6df74000b0a6d0b6ccfcb9afdeb58496f8d8b) - GH-1314 Fix editor crash with binary orchestration scripts

## [2.4.stable](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.4.stable) - 2026-02-22

- [7681464](http://github.com/CraterCrash/godot-orchestrator/commit/76814647597aed3d80eb6b7be57c708d3d277dff) - GH-1303 Improve unsaved script marker on changes
- [d3a0de9](http://github.com/CraterCrash/godot-orchestrator/commit/d3a0de9c7cd5ff52939c168c171ab0e12c99dbc3) - GH-1302 Update demo orchestrations
- [db76611](http://github.com/CraterCrash/godot-orchestrator/commit/db7661133d79c1bd5654a47a65d078dbe6ce5c98) - GH-1299 Avoid text resource truncation
- [83cffa4](http://github.com/CraterCrash/godot-orchestrator/commit/83cffa40fd1455290ec57acca276029a1329e2c6) - GH-1297 Mark script modified when function changes
- [2f5b016](http://github.com/CraterCrash/godot-orchestrator/commit/2f5b016d3ed0b4aea8a73043f6ee596218ef6f74) - GH-1295 Remove UI node when removed from data model
- [4074f8f](http://github.com/CraterCrash/godot-orchestrator/commit/4074f8fe5ff2fccfcdf46960fcb3ca7e51729a20) - Fix `@OScript` description for constant `One`
- [bcaef5e](http://github.com/CraterCrash/godot-orchestrator/commit/bcaef5ea0a45040538c8f0f8e15c2886f1a02891) - GH-1292 Fix populating public constants dictionary
- [32c5413](http://github.com/CraterCrash/godot-orchestrator/commit/32c54131550d916ce3252ad01420d7ad7defab98) - GH-1288 Use native class for extends path override menu
- [5f5efa5](http://github.com/CraterCrash/godot-orchestrator/commit/5f5efa5282abc66a712852f8c7eaf8ff5a27f066) - GH-1286 Avoid showing defined methods in actions menu

## [2.4.rc2](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.4.rc2) - 2026-02-15

- [77d0c3d](http://github.com/CraterCrash/godot-orchestrator/commit/77d0c3dd18cff7f78463a5625dd057c18c04f4a6) - GH-1235 Support file-based script inheritance
- [c165aef](http://github.com/CraterCrash/godot-orchestrator/commit/c165aef1a88278a51a216e5a7e4b00bf0f5faa35) - GH-1244 Update editor/inspector with changes without explicit save
- [f545598](http://github.com/CraterCrash/godot-orchestrator/commit/f545598f16a25a1bf392b4f0f47e7f5084f6ac94) - GH-1259 Disable support for built-in scripts
- [2c3d4b5](http://github.com/CraterCrash/godot-orchestrator/commit/2c3d4b5965516f357e0201abdc29a715cb806a5d) - GH-1275 Fix free object working with controls
- [4311b92](http://github.com/CraterCrash/godot-orchestrator/commit/4311b928058e3d1e8bafd2b861d2bd22b5ba634f) - GH-1277 Omit math constants in debugger global list
- [f11c050](http://github.com/CraterCrash/godot-orchestrator/commit/f11c05013c0479e00426bc6b03cb4b439ee6f723) - GH-1267 Fix autoload lifecycle access
- [460b4c9](http://github.com/CraterCrash/godot-orchestrator/commit/460b4c9739de5d0e41af7222d5ed874c130596d8) - GH-1267 Make sure cache is primed on load
- [4da537f](http://github.com/CraterCrash/godot-orchestrator/commit/4da537f63b5ad7ed196488e398a9cf32bf6e16d9) - GH-1267 Add plugin-level autoload caching
- [83eca9c](http://github.com/CraterCrash/godot-orchestrator/commit/83eca9cb7eb815a5d8f705acaa5244549fd869ef) - GH-1269 Enable compiler node convergence
- [8837273](http://github.com/CraterCrash/godot-orchestrator/commit/8837273ecbe2cadbe28a118a843f5ac943b80eb2) - GH-1271 Reduce frequency of script validation
- [1e9d975](http://github.com/CraterCrash/godot-orchestrator/commit/1e9d9754d96de8357eaa0bfe50f771533624c8bd) - GH-1273 Remove ResourceLoader to resolve resource types
- [62f1b5c](http://github.com/CraterCrash/godot-orchestrator/commit/62f1b5ca23622e44ed167e0962b41c2f450666d7) - GH-1262 Correctly reset override function state
- [e9f4470](http://github.com/CraterCrash/godot-orchestrator/commit/e9f4470dcac9edaad6dbdaee4b795aedd08c84ff) - GH-1263 Do not auto-init script language
- [685288e](http://github.com/CraterCrash/godot-orchestrator/commit/685288ebd4df23b5fa2024789048745197b11317) - GH-1257 Optimize script save & reload signals
- [7d20fe6](http://github.com/CraterCrash/godot-orchestrator/commit/7d20fe63929351b90a986a5c022cc1df9e963332) - GH-1252 Enable -Wno-ordered-compare-function-pointers for builds
- [6daf98c](http://github.com/CraterCrash/godot-orchestrator/commit/6daf98c58964d61607bcbe3774b3d9cacdd57c6f) - GH-1253 Resize node to content on autowire
- [9f7cf87](http://github.com/CraterCrash/godot-orchestrator/commit/9f7cf87fe691e18f98acd0b099b9f56e59a1697f) - GH-1246 Rework Break for extra Variant properties
- [a4dac9e](http://github.com/CraterCrash/godot-orchestrator/commit/a4dac9e18e37e9525d593f1660a3b283eb07a25f) - GH-1247 Correctly register static functions
- [165b273](http://github.com/CraterCrash/godot-orchestrator/commit/165b2739be9b9ffd7b6d29326ade5a2b2c2488c4) - GH-1242 Fix errors on plugin first load
- [33701c9](http://github.com/CraterCrash/godot-orchestrator/commit/33701c992d4c0b1fb0789a86810728be3bcfa9d7) - GH-1249 Correctly decode class scoped types
- [dd7395f](http://github.com/CraterCrash/godot-orchestrator/commit/dd7395f9c03ec47d725516467551bd80b9fa7a27) - GH-1241 Fix PagedAllocator leak errors
- [50dc36f](http://github.com/CraterCrash/godot-orchestrator/commit/50dc36fbb829e91e4e62d95d14f880879631e4e5) - GH-1239 Fix editor crash inspecting nodes with exported variants

## [2.4.rc1](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.4.rc1) - 2026-02-01

- [5c0917a](http://github.com/CraterCrash/godot-orchestrator/commit/5c0917af393e4fc931b00c7e2951213f2873842e) - GH-1236 Sync with upstream godot-cpp commit 58d1de720b8ffe9f8ffcdfe3a85148582cfd2e74
- [bed603e](http://github.com/CraterCrash/godot-orchestrator/commit/bed603ed6bfff257200ba2ceb841dc247ba48829) - GH-1062 Add Godot class-specific script templates
- [d3b100a](http://github.com/CraterCrash/godot-orchestrator/commit/d3b100ad9e2e91dca6dd901942665709c5bbaa9e) - GH-1232 Fix crash opening file menu
- [e6a170f](http://github.com/CraterCrash/godot-orchestrator/commit/e6a170f9be83fb6aeb175d541665c3bc52568fe2) - GH-1229 Fix leaked resources due to preload
- [12d7858](http://github.com/CraterCrash/godot-orchestrator/commit/12d7858a3322f41b3dd726b8fcc5009d04f1a94d) - GH-1224 Support dragging resources as exported variables
- [ea08065](http://github.com/CraterCrash/godot-orchestrator/commit/ea08065f818c0ae5b79ae4eafac7dbaa5dd5b90e) - GH-1226 Fix parser to set variable export info correctly
- [820bc03](http://github.com/CraterCrash/godot-orchestrator/commit/820bc0390d50d84e34b766f4d6478906eda4cf1b) - GH-1219 Add tool script hint and background color tint
- [7621847](http://github.com/CraterCrash/godot-orchestrator/commit/7621847c835583c08f1219f5b84807aa0e15b06e) - GH-1215 Add soft reload tool script file menu option
- [271b10a](http://github.com/CraterCrash/godot-orchestrator/commit/271b10a03bac2d48c519d2f8829472460b2371c4) - GH-1216 Fix populating script list on startup
- [2eae04a](http://github.com/CraterCrash/godot-orchestrator/commit/2eae04a2781ef42010db3aa395cebec0f9256139) - GH-1213 Fix freezes with print string node in tool scripts
- [c1610cd](http://github.com/CraterCrash/godot-orchestrator/commit/c1610cd41afb96d41922151d32c647409d5a2814) - GH-1211 Guard non-existent input section in project settings

## [2.4.dev2](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.4.dev2) - 2026-01-24

- [4be2229](http://github.com/CraterCrash/godot-orchestrator/commit/4be22291d1e76d1d11e818b89c05c9219891b894) - GH-1205 Support tool orchestrations
- [16ed854](http://github.com/CraterCrash/godot-orchestrator/commit/16ed85438ee7a545b506ab6b343c6a3c7644cea1) - GH-1201 Always place event nodes in event graphs
- [485006b](http://github.com/CraterCrash/godot-orchestrator/commit/485006b854f0a9728b901a1862a2506cb985214e) - GH-261 Fix missing include
- [05c796e](http://github.com/CraterCrash/godot-orchestrator/commit/05c796ef5b3494e0146d009b15f2762b5783bede) - GH-261 Fix Godot 4.4 compatibility
- [01c1790](http://github.com/CraterCrash/godot-orchestrator/commit/01c1790e505534daf7a13e5c885f66caeca401da) - GH-261 Use PROPERTY_HINT_FILE for icon path
- [d90d151](http://github.com/CraterCrash/godot-orchestrator/commit/d90d151bf5612076502b4fa84fc0a757bed56388) - GH-261 Support calling parent/super methods
- [9c866ff](http://github.com/CraterCrash/godot-orchestrator/commit/9c866ffb81caa5460a67acb32aaef67212cefabf) - GH-261 Support orchestration script classes
- [ef9fbbc](http://github.com/CraterCrash/godot-orchestrator/commit/ef9fbbc796086c870646c137d31af4b4c624373c) - GH-932 Fix overriding parent functions
- [3d4d86f](http://github.com/CraterCrash/godot-orchestrator/commit/3d4d86f127ab6b5737ef2793939f74b67effb6b0) - GH-1202 Fix parser error when functions return variants
- [5220855](http://github.com/CraterCrash/godot-orchestrator/commit/52208557a219ed0141781e8c6356c748310112f9) - GH-1198 Fix New Object to work with script classes
- [7c9f239](http://github.com/CraterCrash/godot-orchestrator/commit/7c9f239fc04b0a2459864d64259baccb1fc4e4d7) - GH-1196 Remove superfluous console output
- [b97b27c](http://github.com/CraterCrash/godot-orchestrator/commit/b97b27c6fc5d2e32bb6498ff757ddd13701dc6d4) - GH-1194 Update graph panel on orchestration reloads
- [0733456](http://github.com/CraterCrash/godot-orchestrator/commit/07334560b0378239a9f93fc321e5511bd730f9f2) - GH-1192 Fix preload to work with script global classes
- [ae5625e](http://github.com/CraterCrash/godot-orchestrator/commit/ae5625e56cdf4f671f632609d8fdd6de100474c7) - GH-1190 Rebind parser bindings after clear
- [27806f9](http://github.com/CraterCrash/godot-orchestrator/commit/27806f9d0e447b5a8da04d992b1f798b31e5872d) - GH-1188 Register class as internal Godot class
- [f371b4b](http://github.com/CraterCrash/godot-orchestrator/commit/f371b4b4ab9e905cd2c7643f95022696e361abc4) - GH-1188 Add static `_bind_methods` handler
- [31f2938](http://github.com/CraterCrash/godot-orchestrator/commit/31f2938b2703e57733c514b382ce3509bcb64caf) - GH-1186 Correctly evaluate owner, avoiding null dereference
- [952a983](http://github.com/CraterCrash/godot-orchestrator/commit/952a9839e13e3ccf3d37151fe599bf4c69b06239) - GH-1172 Fix OScriptParser handling variadic function args
- [a9e568c](http://github.com/CraterCrash/godot-orchestrator/commit/a9e568cefb61bfdc85536d503b945dbef88437f5) - GH-1182 Correctly bind struct pin `text_submitted` signal
- [cb15365](http://github.com/CraterCrash/godot-orchestrator/commit/cb15365a04bca280db832aff7dde80561d120112) - GH-1171 Correctly enqueue print string text overlay
- [613b918](http://github.com/CraterCrash/godot-orchestrator/commit/613b9189923f65b0843697e1ca62e09dc940f555) - GH-1169 Fix search box grab focus when opened
- [25fc493](http://github.com/CraterCrash/godot-orchestrator/commit/25fc4931ab12be9d02303574c9d300dc4b4dc017) - GH-1173 Fix `GDE::Variant::evaluate` to return result
- [464f86c](http://github.com/CraterCrash/godot-orchestrator/commit/464f86cecc218417394c138db3609e7be4e99b82) - GH-1175 Fix GraphNodeAlignment error
- [a9810bd](http://github.com/CraterCrash/godot-orchestrator/commit/a9810bd8b88956ee38db2c2df854074c710c9645) - GH-1176 Fix script error message instance resolution
- [7086290](http://github.com/CraterCrash/godot-orchestrator/commit/708629032d6f93807b1661c076233f47508a56b9) - GH-1168 Make mouse visible when dialogues are shown

## [2.4.dev1](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.4.dev1) - 2026-01-18

- [fcda111](http://github.com/CraterCrash/godot-orchestrator/commit/fcda111b639576c5ec114e0341a4d70280a60ecd) - GH-967 Make scaled Orchestrator Logo crisper
- [f7be253](http://github.com/CraterCrash/godot-orchestrator/commit/f7be253b75a49fafdfc01e199fcb0ba1fdeccf02) - GH-1153 Treat `Object#connect` flags as drop-down
- [5aff17a](http://github.com/CraterCrash/godot-orchestrator/commit/5aff17a130f230fa5de80d6af2b36ce62483c461) - GH-1056 Use CMAKE_MSVC_RUNTIME_LIBRARY for Windows
- [897ef55](http://github.com/CraterCrash/godot-orchestrator/commit/897ef55e1f4ed2003a7bad98da001f499f0fcf9c) - GH-1056 Update demo project to Godot 4.6
- [3330e9c](http://github.com/CraterCrash/godot-orchestrator/commit/3330e9c5c7372babdb777c2fa8d73566c44c48b4) - GH-1056 Godot 4.6 support (sync 4.6.rc1)
- [7c5919f](http://github.com/CraterCrash/godot-orchestrator/commit/7c5919f64deb133178bbf954c849f66b78cf5150) - GH-1165 Make use of ccache configurable
- [226463c](http://github.com/CraterCrash/godot-orchestrator/commit/226463c5d7c3808b181ffa88e9c2f858b8a0b3d3) - GH-967 Fix include issue
- [b584a11](http://github.com/CraterCrash/godot-orchestrator/commit/b584a11f6c802771fdc083b261327ba17ac96ec7) - GH-967 Fix more Godot 4.4 compatibility
- [52e0f74](http://github.com/CraterCrash/godot-orchestrator/commit/52e0f74914e16c88c72ebea0b6c2297f4aef708a) - GH-967 Introduce Goodt 4.4 compat ResourceUID::path_to_uid
- [33c4d59](http://github.com/CraterCrash/godot-orchestrator/commit/33c4d59b755fc1b0b85bc978685811e30d4652b4) - GH-967 Fix main screen tab icon scaling
- [66c1d22](http://github.com/CraterCrash/godot-orchestrator/commit/66c1d22142be32e498839d52855de297942b5b41) - GH-967 Use new callable_mp style macros
- [62cf879](http://github.com/CraterCrash/godot-orchestrator/commit/62cf8790ea68a46b416ac423c561409ba658a3d1) - GH-967 Use core/scene static string names
- [27b11ba](http://github.com/CraterCrash/godot-orchestrator/commit/27b11ba94070246334e84e572e43f0683791fefa) - GH-967 Remove tree_utils as dead code
- [3589771](http://github.com/CraterCrash/godot-orchestrator/commit/3589771a952e00d25aa8e8cacf26c22761945f5f) - GH-967 Remove godot_utils helpers
- [cae9da5](http://github.com/CraterCrash/godot-orchestrator/commit/cae9da530f89c1c8e6bc8451a286ed1553f7e334) - GH-967 Refactor/Fix format common classes
- [7555180](http://github.com/CraterCrash/godot-orchestrator/commit/755518014454a46ac627762edc7193808bc7635d) - GH-967 Refactor/Fix format editor classes
- [e7fe043](http://github.com/CraterCrash/godot-orchestrator/commit/e7fe0431cd54ea190aba9d645196490275cea75b) - GH-967 Refactor/Cleanup Orchestrator EditorPlugin
- [30f22ac](http://github.com/CraterCrash/godot-orchestrator/commit/30f22acfbdae4570c742f0394beead49136de4c3) - GH-967 Refactor export plugin
- [8e2f404](http://github.com/CraterCrash/godot-orchestrator/commit/8e2f40474717a2d393d58e6d54aaf06baf4b3800) - GH-967 Rework GraphNode ThemeCache
- [604c7fb](http://github.com/CraterCrash/godot-orchestrator/commit/604c7fb321ace2c2abacaab8d0f7d94875cff13c) - GH-967 Fix knots disappearing on graph changes
- [ebf4f02](http://github.com/CraterCrash/godot-orchestrator/commit/ebf4f02161834244b534478a649634a46d21cf89) - GH-967 Refactor/Style graph classes
- [907e69a](http://github.com/CraterCrash/godot-orchestrator/commit/907e69a8f85afb0eb73cd9c83af154ff5469de17) - GH-967 Fix comment node style behavior
- [bbe9804](http://github.com/CraterCrash/godot-orchestrator/commit/bbe98040f6c72532db993b5de8f37cf7fef3fb47) - GH-967 Cleanup deprecations, fix style for actions
- [7908af4](http://github.com/CraterCrash/godot-orchestrator/commit/7908af4dc98e761af1e38ea53b6473c6c6026286) - GH-967 Refactor Debugger plugin
- [2931740](http://github.com/CraterCrash/godot-orchestrator/commit/29317402fce1148c0a7461cb32b18cdbeb0c184b) - GH-967 Fix race condition on restoring window state
- [1099ffa](http://github.com/CraterCrash/godot-orchestrator/commit/1099ffa25e677d7a2bbe2107cb28fca29cf9f5fc) - GH-967 Refactor inspector plugins
- [3b77195](http://github.com/CraterCrash/godot-orchestrator/commit/3b77195eaa2fd13ed575da5f1ef27d15b481dca1) - GH-967 Fix compatibility with ExtensionDB changes
- [d81566d](http://github.com/CraterCrash/godot-orchestrator/commit/d81566defdf466297b49800202471ef1adad48ff) - GH-967 Refactor varray template function
- [737dcf4](http://github.com/CraterCrash/godot-orchestrator/commit/737dcf4205b06d89f0c3e6fee9444c8db2ae2865) - GH-967 Refactor WeakRef
- [e6ba6bc](http://github.com/CraterCrash/godot-orchestrator/commit/e6ba6bc8c0ed300e51b55c90ddc8482015cf263a) - GH-967 Refactor ClassDBUtils into GDE::ClassDB
- [e6eaac8](http://github.com/CraterCrash/godot-orchestrator/commit/e6eaac8740ecd1eeb10c24b481650badccfa3922) - GH-967 Fix validation to skip node lookup with invalid ids
- [56785ed](http://github.com/CraterCrash/godot-orchestrator/commit/56785ed731b13f247af3581c0b06589e56ed0262) - GH-967 Introduce option to prioritize methods over properties
- [99b910a](http://github.com/CraterCrash/godot-orchestrator/commit/99b910a9ff043af4295acec5310b7aefb403706c) - GH-967 Fix node path default value rendering
- [f5b4e20](http://github.com/CraterCrash/godot-orchestrator/commit/f5b4e2074e84dfcc61bd9045a9bbcd7c3f436024) - GH-967 Fix floating window not visible after restore on KDE
- [2785d50](http://github.com/CraterCrash/godot-orchestrator/commit/2785d501f34b0a2cfe1007e9731ea5085c217cf7) - GH-967 Fix PopupPanel menu style
- [f30ab2b](http://github.com/CraterCrash/godot-orchestrator/commit/f30ab2b99c8c5a669067137f342c79b654b9b2ce) - GH-967 Add hover styles to buttons
- [e3fe2ac](http://github.com/CraterCrash/godot-orchestrator/commit/e3fe2ace66a022a8024822d83b37f7d88826c277) - GH-967 Wayland: Work around window scale ambiguity
- [a020ca4](http://github.com/CraterCrash/godot-orchestrator/commit/a020ca4f75c2d5cafd84ea496ac322bca3c1907e) - GH-967 Exclude comment nodes from knot position check
- [f6a8a67](http://github.com/CraterCrash/godot-orchestrator/commit/f6a8a6736a36f78c1c483eb75b39215da663a156) - GH-967 Add connection popup context-menu
- [412c07d](http://github.com/CraterCrash/godot-orchestrator/commit/412c07d79541cde3b6ed6013dd3f2caf504662d9) - GH-967 Fix button/icon scale issues
- [e196397](http://github.com/CraterCrash/godot-orchestrator/commit/e196397038dbf5bdd3edfbc7b744916d919f9336) - GH-967 Fix editable pin logic on function call nodes
- [bd02dc5](http://github.com/CraterCrash/godot-orchestrator/commit/bd02dc593821a6b70118904cc31b3ceebfb5dd88) - GH-967 Deselect other nodes when showing pin context menu
- [33db62b](http://github.com/CraterCrash/godot-orchestrator/commit/33db62b2823688992a0f608bea03ca2da030e4d0) - GH-967 Fix bitmask toggle logic
- [82438ad](http://github.com/CraterCrash/godot-orchestrator/commit/82438ad0e4fd47b4a56ec071ad7923c49d2191d8) - GH-967 Fix signal suggestion support
- [136645f](http://github.com/CraterCrash/godot-orchestrator/commit/136645f7ee9ca637dcb3358542ef5beb73e73761) - GH-967 Fix enum/bitfield default value rendering
- [1961b9e](http://github.com/CraterCrash/godot-orchestrator/commit/1961b9e4706a9e59320ae35b9c1e36536aba5e20) - GH-967 Toggle viewport active on opening scripts
- [4cd1f4e](http://github.com/CraterCrash/godot-orchestrator/commit/4cd1f4e3393ebf94e9021fb943f86f8b677ccbae) - GH-967 Support meta clicks in Output panel to Orchestrations
- [f2de390](http://github.com/CraterCrash/godot-orchestrator/commit/f2de39023896fff138d24849da7848feb002183e) - GH-967 Fix lookup error when creating new functions
- [eabf51b](http://github.com/CraterCrash/godot-orchestrator/commit/eabf51b14ea041597140710fa43d6d5c137bafea) - GH-967 Remove unnecessary signal argument
- [7bdb50d](http://github.com/CraterCrash/godot-orchestrator/commit/7bdb50d2f48ecd135ed1f79ae593adc7ebbf505e) - GH-967 Move script validation to use parser/analyzer tooling
- [6519643](http://github.com/CraterCrash/godot-orchestrator/commit/65196436e14da243ad769d2e6cabba0ebd8521f7) - GH-967 Fix refreshing connection changes
- [1839d62](http://github.com/CraterCrash/godot-orchestrator/commit/1839d62fcf0533851684af0a2b0b1c573dc9b26d) - GH-967 Fix bug during rebase/merge
- [750ad72](http://github.com/CraterCrash/godot-orchestrator/commit/750ad72f9dadaa93775f5f041370fa30fee5468f) - GH-967 Fix extends inspector object reference
- [c03c595](http://github.com/CraterCrash/godot-orchestrator/commit/c03c59517c052d6f9a80570786afe21925efd49b) - GH-967 Remove unused variable
- [96fae7a](http://github.com/CraterCrash/godot-orchestrator/commit/96fae7aa81fc22bc1f75fc167ea52ba48388f64e) - GH-967 Allow graph toolbar to wrap
- [5fda745](http://github.com/CraterCrash/godot-orchestrator/commit/5fda745f6d0eb13e6822bc97e6c2b079d8e14746) - GH-967 Add ConnectionsDock mediator singleton
- [5757b7e](http://github.com/CraterCrash/godot-orchestrator/commit/5757b7e4b4602c7ccd9e6e53527c8d7348825b16) - GH-967 Fix crash on reused identifiers
- [63e9d33](http://github.com/CraterCrash/godot-orchestrator/commit/63e9d331e3891608a8f6949070924a19f6e68cef) - GH-967 Sort components alphabetical
- [0b35897](http://github.com/CraterCrash/godot-orchestrator/commit/0b358973167b2e0664759a908c3f8f8c9a9924fc) - GH-967 Expand file menu options
- [3b5c1bd](http://github.com/CraterCrash/godot-orchestrator/commit/3b5c1bd815e87cd66e415f806eb7024ec9bd5deb) - GH-967 Fix component panel edit popup resolution
- [eb3534e](http://github.com/CraterCrash/godot-orchestrator/commit/eb3534e593e5815ada0292d4a481184660b5c285) - GH-967 Add Debug menu to main toolbar
- [3950e67](http://github.com/CraterCrash/godot-orchestrator/commit/3950e67dd5d73fad98a0941f578fcb4b72509810) - GH-967 Restore breakpoints on restart
- [3d5862a](http://github.com/CraterCrash/godot-orchestrator/commit/3d5862afdb2e7e84e9a16e3ccf84535b1103d448) - GH-967 Change bookmark/breakpoint removal to all
- [8adecff](http://github.com/CraterCrash/godot-orchestrator/commit/8adecffd40f885617b5ff87253d0c229e6c9c5be) - GH-967 Mark edited when node is moved
- [1355391](http://github.com/CraterCrash/godot-orchestrator/commit/135539191d041f152cfa373ef4e8b947931395d1) - GH-967 New editor UI implementation
- [3339a75](http://github.com/CraterCrash/godot-orchestrator/commit/3339a7593c5f5511152a7af8cf1f01f00593df29) - GH-1141 Fix Godot 4.4 compatibility
- [7d931c6](http://github.com/CraterCrash/godot-orchestrator/commit/7d931c67c932c2449e0613d07418330e75578824) - GH-1141 Add support for script export remaps
- [08b52a8](http://github.com/CraterCrash/godot-orchestrator/commit/08b52a8e3c618fad9c3c1f61899bfc7607cdd4c7) - GH-1141 Fix get_resource_uid not to throw an error
- [4e43d95](http://github.com/CraterCrash/godot-orchestrator/commit/4e43d958fb991a9ec4cf3e640a13c2e5ddc6e037) - GH-1141 Fix format
- [53658be](http://github.com/CraterCrash/godot-orchestrator/commit/53658be76755463884f472e7358ec6d3d3dc62f0) - GH-1141 Fix set_uid to write uid as 8 and not 4 bytes
- [ced866c](http://github.com/CraterCrash/godot-orchestrator/commit/ced866c00b3d3364bf205f1cc067fd76ca808f67) - GH-1141 Fix error when creating new binary resource
- [b7d60c0](http://github.com/CraterCrash/godot-orchestrator/commit/b7d60c02e67ec5a095cc998a4411f016c4d17c40) - GH-1141 Don't assign resource paths
- [b633ad2](http://github.com/CraterCrash/godot-orchestrator/commit/b633ad24c37258784362ad33623d335ef6ae7ea6) - GH-1141 Fix editor crash on breakpoint
- [74ee55d](http://github.com/CraterCrash/godot-orchestrator/commit/74ee55d05f8d68203621f222925aeb63b508333f) - GH-1141 Rework ExtensionDB to support export builds
- [ce88829](http://github.com/CraterCrash/godot-orchestrator/commit/ce888291571fa6b5ec20f04a68f9f21ba818964e) - GH-1141 Fix validated variable get node
- [ec21eb6](http://github.com/CraterCrash/godot-orchestrator/commit/ec21eb61dbc2cf9969e965c41ad65273b1a36494) - GH-1141 Fix type cast to work with all script types
- [ab7218f](http://github.com/CraterCrash/godot-orchestrator/commit/ab7218f0d606a4127863d30d14611e726c9bfdb2) - GH-1141 Cleanup empty function body error message
- [04945f6](http://github.com/CraterCrash/godot-orchestrator/commit/04945f6b009f40d34e3fcac67e72f5a70eeae282) - GH-1141 Set script node ids while building AST
- [af4724c](http://github.com/CraterCrash/godot-orchestrator/commit/af4724ca84c00240072cd5891668e6216e7d2a59) - GH-1141 Introduce StringPtr for static initialization
- [c8b4b4b](http://github.com/CraterCrash/godot-orchestrator/commit/c8b4b4b794d37dc381c8a37648738732b8c0b8df) - GH-1141 Fix global constant registration
- [2b5a399](http://github.com/CraterCrash/godot-orchestrator/commit/2b5a39920c983f8825dcf108f8ea5c650ebe6c3b) - GH-1141 Make sure uid-baed autoloads are decoded to paths
- [d4b5bc8](http://github.com/CraterCrash/godot-orchestrator/commit/d4b5bc82d22e375fa459d09d0df367064f1f8245) - GH-1141 Flag build as custom
- [7006e3d](http://github.com/CraterCrash/godot-orchestrator/commit/7006e3d88218ca9bec81635807dea6d350e9084d) - GH-1141 Godot 4.4 compatibility
- [52644bb](http://github.com/CraterCrash/godot-orchestrator/commit/52644bb8760ceb3c6ad0809df0fbf0820d14ccee) - GH-1141 Fix placement of deprecated attribute
- [e8c7eb7](http://github.com/CraterCrash/godot-orchestrator/commit/e8c7eb7615c8733eef21f1100913fa6c15323e0e) - GH-1141 Apply override to OScriptLanguage::_validate_path
- [06f4e00](http://github.com/CraterCrash/godot-orchestrator/commit/06f4e00248e1f5112d3182fecf84e16d793bcd7d) - GH-1141 Fix Variant to ObjectID cast
- [e764b0a](http://github.com/CraterCrash/godot-orchestrator/commit/e764b0addbb5a5dd83fa3d241148b6a16173dfd4) - GH-1141 Fix potential null dereference
- [fd43cb9](http://github.com/CraterCrash/godot-orchestrator/commit/fd43cb978b63277ae165431824b9d7c50fa4ac18) - GH-1141 Fix iterator_category failure
- [515d4ac](http://github.com/CraterCrash/godot-orchestrator/commit/515d4ac641dcb0de93dd1f52f32b3e0ad2741e4f) - GH-1141 For compatibility, don't use range-based iteration
- [91a8235](http://github.com/CraterCrash/godot-orchestrator/commit/91a82355287969ce6df120be4a152b042a8759c0) - GH-1141 Fix demo project orchestrations
- [be02ee8](http://github.com/CraterCrash/godot-orchestrator/commit/be02ee876798a2842306de188e43144456a1e87b) - GH-1141 Bytecode VM implementation
- [07002e0](http://github.com/CraterCrash/godot-orchestrator/commit/07002e08af5ad63ef379cfbfcdcbc09b8728ba45) - GH-1156 Fix autowire eligibility algorithm
- [83cbb0b](http://github.com/CraterCrash/godot-orchestrator/commit/83cbb0b8766769c213310c0b23244816d5d45f1c) - GH-1154 Any/Variant pins should show all value producer actions
- [db281f1](http://github.com/CraterCrash/godot-orchestrator/commit/db281f1c1699164bccde54bc1b546be880fcc481) - GH-1143 Enforce empty arrays when class list is empty
- [b12d1f9](http://github.com/CraterCrash/godot-orchestrator/commit/b12d1f9025cd3275be4b3d203c361936cceba32f) - GH-1151 Add ui/nodes/connection_hotzone_scale option
- [c38d250](http://github.com/CraterCrash/godot-orchestrator/commit/c38d25054941c374bf366cb790e95d0933eceb0d) - GH-1131 Correctly identify when pins are enum/bitfields
- [80637e5](http://github.com/CraterCrash/godot-orchestrator/commit/80637e5f21acb6fa6956546ae1a36daa08d86db7) - GH-1133 Update ExtensionDB
- [a6f984f](http://github.com/CraterCrash/godot-orchestrator/commit/a6f984f66a887ad4b113025aa4a191bab85327c8) - GH-1133 Fix Modulo operation description
- [69bc0f4](http://github.com/CraterCrash/godot-orchestrator/commit/69bc0f4d2d1a89d1704988693651c92a6f2d4e0a) - GH-1134 Do not autowire when prior drag canceled
- [2712677](http://github.com/CraterCrash/godot-orchestrator/commit/2712677106ccd670be5dc9def3771273e4e4084d) - GH-1143 Fix pin connectivity with multiple class types
- [fe37b2d](http://github.com/CraterCrash/godot-orchestrator/commit/fe37b2dd326cfff1bd111cf3fe48f453e17df546) - GH-1121 Allow property nodes to self reference
- [9cce852](http://github.com/CraterCrash/godot-orchestrator/commit/9cce852996b75af892154fa3aeefb2cac9d476c0) - GH-1100 Adjust variable export button tooltip text
- [0ce329d](http://github.com/CraterCrash/godot-orchestrator/commit/0ce329dc50085719d703909391a6e3b61383c6e3) - GH-1110 Improve static function argument validation
- [14a9d35](http://github.com/CraterCrash/godot-orchestrator/commit/14a9d35b1a466659067e4d7782c7d70cc8c09790) - GH-1114 Scale data pin port icons with display scale
- [9d22863](http://github.com/CraterCrash/godot-orchestrator/commit/9d22863deb523b93ba64f906d2dbc18004c4b266) - GH-1112 Allow global class enums as variable/function args
- [2b6dc8d](http://github.com/CraterCrash/godot-orchestrator/commit/2b6dc8d0be09a974c2822ec2f04532a01a707638) - GH-1108 Fix port rule matching variant type methods
- [fe1e0ad](http://github.com/CraterCrash/godot-orchestrator/commit/fe1e0ad5aa3161ac2d6ca51b234d499738e2a930) - GH-1098 Read authors/donors using UTF-8 encoding
- [19263a1](http://github.com/CraterCrash/godot-orchestrator/commit/19263a17f64f9c5814d142e64c939dad122f20d3) - GH-1103 Fix introspector crash when object has no script
- [dde17fc](http://github.com/CraterCrash/godot-orchestrator/commit/dde17fc881f940cb39b63484a568369a7a2aa8ea) - GH-1087 Update Emscripten to 4.0.11
- [c999e68](http://github.com/CraterCrash/godot-orchestrator/commit/c999e687f5d746ce2a384f2f382de77eb298f9c8) - GH-1072 Extend scale up to 400%
- [3a4c40b](http://github.com/CraterCrash/godot-orchestrator/commit/3a4c40b2408464eda4545e8ce2c5955d234a16bb) - GH-1072 Add setting to control PrintStringUI text scale
- [a19ca56](http://github.com/CraterCrash/godot-orchestrator/commit/a19ca56bff5c4891e6e508b17b9493481b1e856f) - GH-1030 Do not remove selected nodes if clipboard cut fails
- [e0123e0](http://github.com/CraterCrash/godot-orchestrator/commit/e0123e04b57fc4d44bc40d81cc280ab4ec08bfac) - GH-1081 Correctly populate actions for autoloads/global scripts
- [e3e6d60](http://github.com/CraterCrash/godot-orchestrator/commit/e3e6d604c93bc8fd71b186b45527d4e8777e5252) - GH-1079 Support Global classes in ClassConstant node
- [936b93f](http://github.com/CraterCrash/godot-orchestrator/commit/936b93f3f35548edea5f36f5f79b193d7077b989) - GH-1077 Implement GDExtensionScriptInstanceInfo `to_string` handler
- [80b1701](http://github.com/CraterCrash/godot-orchestrator/commit/80b17019dd24fb067a0959160d3d48f540a431d0) - GH-1070 Allow get/set non-exported variables at runtime
- [4baa42f](http://github.com/CraterCrash/godot-orchestrator/commit/4baa42f6f1ebe44660781d10e9eb7d97402390c1) - GH-1070 Always expose all variable declarations

## [2.3.stable](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.3.stable) - 2025-11-24

- [0426d1d](http://github.com/CraterCrash/godot-orchestrator/commit/0426d1dc296ab3f80e487d2447ca2518218e215d) - GH-1004 Update extension compatibility to 4.5
- [e972494](http://github.com/CraterCrash/godot-orchestrator/commit/e972494b55e506ced9ba5aa333d7edf0ef07416c) - GH-1004 Update class documentation
- [110ea6c](http://github.com/CraterCrash/godot-orchestrator/commit/110ea6cde42a3bbd7396a2bd7e424043eea4dd5c) - GH-1004 Support Godot 4.5-stable

## [2.2.stable](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.2.stable) - 2025-11-24

- [cc934ec](http://github.com/CraterCrash/godot-orchestrator/commit/cc934ecbeba1839b9f44c0d7a82ac713408624a5) - GH-1046 Trim new signal argument values
- [d975d0e](http://github.com/CraterCrash/godot-orchestrator/commit/d975d0e23a9c98ddf30e424b0728dd2671c67e30) - GH-1038 Fix crash when input map changed
- [3f7ae57](http://github.com/CraterCrash/godot-orchestrator/commit/3f7ae578ffb85698ae80a6ac2240842cf5b817ef) - GH-1031 Make sure variable values are unique per instance
- [9fc7aeb](http://github.com/CraterCrash/godot-orchestrator/commit/9fc7aebb6ea176da6c552769338f60bcb481ed2c) - GH-1024 Introduce Android editor builds
- [aaf77df](http://github.com/CraterCrash/godot-orchestrator/commit/aaf77df60e154d47f377f950db1a5aebb0fdbb68) - GH-1014 Only set arm64 on linux filenames
- [456ade8](http://github.com/CraterCrash/godot-orchestrator/commit/456ade8b212028d0375075c3e135a9fe92109390) - GH-1027 Fix signal blocking for node pins
- [e58e01e](http://github.com/CraterCrash/godot-orchestrator/commit/e58e01ec5f948c94517829d60ffb5986bb7a64a4) - GH-1022 Do not allocate an empty method list
- [4c81bb7](http://github.com/CraterCrash/godot-orchestrator/commit/4c81bb7e64686cbe2028143ed0d50de7feeeecc3) - GH-1018 Add the new All Actions dialog window
- [77b23e6](http://github.com/CraterCrash/godot-orchestrator/commit/77b23e60664ed31e7f0fb11f708cf109df9afa99) - GH-1020 Fix GODOT_VERSION checks for `PropertyInfo`
- [67d482c](http://github.com/CraterCrash/godot-orchestrator/commit/67d482c8901a3956641be6565e717d27229360da) - GH-1020 Fix GODOT_VERSION checks for `notification`
- [8b9ed9f](http://github.com/CraterCrash/godot-orchestrator/commit/8b9ed9fb1110246cb787793262acf5e0b6d32f69) - GH-1014 Introduce Linux arm64 builds
- [e782969](http://github.com/CraterCrash/godot-orchestrator/commit/e7829690af974a9a25e5e899dffedd9449fcc132) - GH-1012 Remove `Logger` class
- [54b6016](http://github.com/CraterCrash/godot-orchestrator/commit/54b60162e4ab6f2cc9e1030f403f6c2015d88515) - GH-1016 Fix wasm32 no-threads extension
- [22925b0](http://github.com/CraterCrash/godot-orchestrator/commit/22925b024c917b5b837afa4a8f717daa4633ecb9) - GH-1008 Introduce `GDExtensionGodotVersion` wrapper
- [5b6a7f3](http://github.com/CraterCrash/godot-orchestrator/commit/5b6a7f35dc75a9dcf709fb85f6340274167e68c6) - GH-1006 Use build's resolved python version
- [41d3f85](http://github.com/CraterCrash/godot-orchestrator/commit/41d3f85ff8342064ee5f0123686e6c0a0ed8a7f8) - Fix icon behavior
- [a2964fd](http://github.com/CraterCrash/godot-orchestrator/commit/a2964fdafced419c89a732d4c65b080e9358a602) - GH-995 Clear inspector when closing an Orchestration
- [338e5f4](http://github.com/CraterCrash/godot-orchestrator/commit/338e5f4655358efceb0c43780912c28b0e85abd7) - GH-956 Avoid extra execution pins on duplication
- [e6585d5](http://github.com/CraterCrash/godot-orchestrator/commit/e6585d5fdb657db5e4b57e08f67861dd031d7d3b) - GH-991 OScriptNodeCallFunction extend OScriptEditablePinNode
- [1d1aaeb](http://github.com/CraterCrash/godot-orchestrator/commit/1d1aaeb0397a32d2ed0a516139fea86b1ea83c4b) - GH-985 Force Emscripten to use sccache
- [493e0a4](http://github.com/CraterCrash/godot-orchestrator/commit/493e0a4fc6e0aef85c23f084715db4596cd04d5d) - GH-983 Reset script edit status on save
- [f3002ba](http://github.com/CraterCrash/godot-orchestrator/commit/f3002babf1f884fdebb589fabaf8800faa74741d) - GH-981 Introduce `set_info` method on `OScriptVariable`
- [75b520b](http://github.com/CraterCrash/godot-orchestrator/commit/75b520bde57e6bf8344524d65a85ec0b79653c4d) - GH-979 Guard reconnecting to changed signal on duplication
- [d800833](http://github.com/CraterCrash/godot-orchestrator/commit/d800833b9c260a219b35a26e6c270173df693c6a) - GH-976 Improve GUID performance
- [bc9458f](http://github.com/CraterCrash/godot-orchestrator/commit/bc9458fd3e912496dd96345c086670f413adb8d7) - GH-974 Support reloading script from disk
- [baada2f](http://github.com/CraterCrash/godot-orchestrator/commit/baada2f01e8369580ee878ff8b608d1f7efb0949) - GH-972 Add ScriptExtension `_get_doc_class_name` override
- [dbf3910](http://github.com/CraterCrash/godot-orchestrator/commit/dbf3910d6af20089c66aab3e761e1f36c0f03a3f) - GH-969 Fix documentation builds on non-Windows platforms
- [1080460](http://github.com/CraterCrash/godot-orchestrator/commit/1080460172875670bda1abec95e4576c394f5ec5) - GH-956 Open/Focus when function duplicated & code cleanup
- [d4323d1](http://github.com/CraterCrash/godot-orchestrator/commit/d4323d1a765347681fe2539968776225dc60dd9c) - GH-956 Implement changes from review
- [762b641](http://github.com/CraterCrash/godot-orchestrator/commit/762b641ccf19d38c3408122eb5008cd292155d4d) - GH-956 Implement duplicate method
- [1fd3829](http://github.com/CraterCrash/godot-orchestrator/commit/1fd3829ab7da543c3395a35bde82322510f57de7) - GH-956 Implement duplicate variable
- [b6e0991](http://github.com/CraterCrash/godot-orchestrator/commit/b6e09914044f497444c3a590bb5c391878455876) - GH-849 Support python negative indexing on array nodes
- [ca703b9](http://github.com/CraterCrash/godot-orchestrator/commit/ca703b98b4d4a9285a557610705184895b0da1c8) - GH-951 Allow setting placeholder values with categories
- [a68da4c](http://github.com/CraterCrash/godot-orchestrator/commit/a68da4c33947916958cedf02ea788b0c8b54827d) - GH-953 Use Android API v22
- [aa7dfb6](http://github.com/CraterCrash/godot-orchestrator/commit/aa7dfb6d602d29197a36b98eac0b1a860c6869c8) - GH-947 Verify script instance on signal callback
- [c49d805](http://github.com/CraterCrash/godot-orchestrator/commit/c49d805143fbd5337c45c35f76b043bf0228e8e5) - GH-943 Add function/signal description inspector fields
- [500bdef](http://github.com/CraterCrash/godot-orchestrator/commit/500bdef206c3e7373c4254c3b60fce88f697cd2e) - GH-609 Add wasm32/web builds
- [7fc9440](http://github.com/CraterCrash/godot-orchestrator/commit/7fc94404b349154e02b2ae1b5d79ad670d9acd7c) - GH-940 Introduce export game plug-in binaries
- [4bdbe72](http://github.com/CraterCrash/godot-orchestrator/commit/4bdbe727d0aaec905d3b3e4ca70a196ce203673a) - GH-936 Add missing FilenameFilter icon
- [cdb2ac5](http://github.com/CraterCrash/godot-orchestrator/commit/cdb2ac58c8bf3eb0d23bed23f6ef9f49de01aa69) - GH-890 Fix enum dropdown for global script classes
- [149b51e](http://github.com/CraterCrash/godot-orchestrator/commit/149b51e8529acebcbeb98f18a9f63cc9510a0c89) - GH-821 Scope debug-functions to Godot 4.3+ only
- [d15ab0c](http://github.com/CraterCrash/godot-orchestrator/commit/d15ab0cbddcd03f22b04e1b19d0598f5df4253b6) - GH-821 Introduce Orchestration built-in functions
- [3009369](http://github.com/CraterCrash/godot-orchestrator/commit/300936994bc19e2fb0b8afb73d1b66e8a7b99222) - GH-535 Fix compiler warnings
- [d5428c8](http://github.com/CraterCrash/godot-orchestrator/commit/d5428c8330ee480e50bbbb2befad6246958fa2c0) - GH-535 Improve self fallback signal suggestions
- [d7980f0](http://github.com/CraterCrash/godot-orchestrator/commit/d7980f0d2d0a33d0ab59e09607609632cb0445ff) - GH-535 Add string-based pin suggestion options
- [f142963](http://github.com/CraterCrash/godot-orchestrator/commit/f142963de12aa509e8314776a1905a7f0d4181c0) - GH-901 Support get scene node with unique names
- [d259837](http://github.com/CraterCrash/godot-orchestrator/commit/d259837deab42cda9e1992621c1222fdfe1beea7) - GH-910 Update wire colors when settings changed
- [3c5629a](http://github.com/CraterCrash/godot-orchestrator/commit/3c5629a8f037bff23256327de5ea9d18d276733a) - GH-908 Allow type cast to abstract class types
- [af61a47](http://github.com/CraterCrash/godot-orchestrator/commit/af61a47ad887cdec41e7fbb8d14c3b568ecd2dde) - GH-868 Print additional configuration settings
- [3bfea4e](http://github.com/CraterCrash/godot-orchestrator/commit/3bfea4e91c6439f750b7c3ca2af4b6a07f28e750) - GH-868 ORCHESTRATOR_ARCH based on CMAKE_SIZEOF_VOID_P
- [7de6873](http://github.com/CraterCrash/godot-orchestrator/commit/7de68732fbce9561c73cf06c6daf7fff606f7c80) - GH-868 Fix library name resolution
- [a661a6e](http://github.com/CraterCrash/godot-orchestrator/commit/a661a6e3db6a3c9b527c450db363f33b31af5bde) - GH-868 Bump godot-engine/godot-cpp to 4.4.stable
- [ba15eba](http://github.com/CraterCrash/godot-orchestrator/commit/ba15ebab4f8b698838db1eb5ae822cab04a1ccf6) - GH-868 Add Orchestrator's doc generator back
- [b5c5b94](http://github.com/CraterCrash/godot-orchestrator/commit/b5c5b94a5edae79e5b4fb7b39de648a51ec76db7) - GH-868 Use new `macos` platform name rather than `darwin`
- [6bb8697](http://github.com/CraterCrash/godot-orchestrator/commit/6bb8697af1806fd68d421e3654f0d6d5cb48ce5f) - GH-868 Resolve prefix based on ANDROID identifier
- [2b204d4](http://github.com/CraterCrash/godot-orchestrator/commit/2b204d4600ccb1e9d0336a525c2a283ec568ddd0) - GH-868 Fix file name resolution based on platform/arch/prefix
- [5520d4e](http://github.com/CraterCrash/godot-orchestrator/commit/5520d4ef138d7b18a9b7c2086be970647765d4f8) - GH-868 Include GODOT_ARCH in build config output
- [a7365f7](http://github.com/CraterCrash/godot-orchestrator/commit/a7365f7ef2702139f67dea93cd75c7cf21a215d8) - GH-868 Remove commented lines
- [6d2e744](http://github.com/CraterCrash/godot-orchestrator/commit/6d2e744f765b95f61275b36eef75768083ccb479) - GH-868 Bump godot-engine/godot-cpp to 4.4.beta2
- [f6193b6](http://github.com/CraterCrash/godot-orchestrator/commit/f6193b67f76dc5006b5f5e1a04d1a5e4f9b1fcce) - Fix compiler warnings
- [b69d0b5](http://github.com/CraterCrash/godot-orchestrator/commit/b69d0b54b8813a158a5affdeaeaebc55924b5ea0) - GH-914 Add "close on focus lost" toggle to all actions dialog
- [92bc2e2](http://github.com/CraterCrash/godot-orchestrator/commit/92bc2e275da100c453769717073d21310c1353b2) - GH-914 Add setting to close all actions on focus lost
- [cf169b6](http://github.com/CraterCrash/godot-orchestrator/commit/cf169b65475912f59b7b34aad51c736f2354ecc4) - GH-906 Update README Discord link
- [031df90](http://github.com/CraterCrash/godot-orchestrator/commit/031df90fbb8c51b071ba1efef13852721cb9d05e) - GH-903 Restrict script base type to adhere to node's class hierarchy
- [03fd9b4](http://github.com/CraterCrash/godot-orchestrator/commit/03fd9b4f6eaf29387a50a8bf209a593a5ab8fbd2) - GH-899 Move to Ubuntu 22.04 runners
- [544d329](http://github.com/CraterCrash/godot-orchestrator/commit/544d3299f260bd1f64cc554626c35e3687cc95ca) - GH-879 Fix exporting node/resource variable types
- [4021b10](http://github.com/CraterCrash/godot-orchestrator/commit/4021b10853e6f4bd8b70cac14cbb080ecbadf8aa) - GH-881 Add static method flag validation
- [e8b0a59](http://github.com/CraterCrash/godot-orchestrator/commit/e8b0a59532b82ba1986c199c9e76e51413a5ab01) - GH-881 Support calling static script functions
- [18de71c](http://github.com/CraterCrash/godot-orchestrator/commit/18de71c7e4421332bd990f45aa2facb44fe93829) - GH-897 Fix validation lookup for signal name on target
- [9631c77](http://github.com/CraterCrash/godot-orchestrator/commit/9631c77394e1e65453380633990edda745d80131) - GH-895 Return target when variant function is chained
- [477f687](http://github.com/CraterCrash/godot-orchestrator/commit/477f68762302678b06f3c22b4daf90b45649c705) - GH-883 Restrict overlapping updates
- [0f076fc](http://github.com/CraterCrash/godot-orchestrator/commit/0f076fc2b2df968ccfdb13d51132c649fb052673) - GH-883 Delay component panel update by one frame
- [0370b41](http://github.com/CraterCrash/godot-orchestrator/commit/0370b413d38b2cc054a735db45c922de7a185a60) - GH-838 Rename setting to `settings/dialogue/default_message_scene`
- [2914b3e](http://github.com/CraterCrash/godot-orchestrator/commit/2914b3e811f9b2606c82c4245d9781e4ce713e32) - GH-838 Added default_scene to ProjectSettings
- [3b19f67](http://github.com/CraterCrash/godot-orchestrator/commit/3b19f675372a8e940cc2e1f206496ed22fb88d2a) - GH-877 Render enum drop-downs for script-specific enums
- [7e38145](http://github.com/CraterCrash/godot-orchestrator/commit/7e381453275922ce7a71e8ca7ca1dfffb079ab86) - GH-862 Change icons for compose/decompose script nodes
- [81755f1](http://github.com/CraterCrash/godot-orchestrator/commit/81755f1e2c7a0a72b85bba9a3a723a170c4d0524) - GH-811 Correctly initialize promoted variables
- [be1f01d](http://github.com/CraterCrash/godot-orchestrator/commit/be1f01d717b64d3e5ed2ed130f3ff6e6ed6d0186) - GH-844 Allow up/down and page up/down to move selection
- [6e3ccf8](http://github.com/CraterCrash/godot-orchestrator/commit/6e3ccf87ecb46622a2855701466f7e403dde1fe6) - GH-872 Use correct struct type in memset
- [d0679cd](http://github.com/CraterCrash/godot-orchestrator/commit/d0679cd5488d161671c367fe991aa56ebebd96c9) - GH-870 Always supply a return value
- [dab983a](http://github.com/CraterCrash/godot-orchestrator/commit/dab983a47bdf7ab4c3e207427cce876c30896ad4) - GH-870 Dispatch `_notification` to script's graph
- [5a7a5e4](http://github.com/CraterCrash/godot-orchestrator/commit/5a7a5e44c0046e2225af98462731ef2ae24d5db3) - GH-848 Guard sync on theme change for when node is ready
- [ffc6027](http://github.com/CraterCrash/godot-orchestrator/commit/ffc60276d38751705ab73d228f08043acdfacb6b) - Update graph_edit.cpp
- [4b664f5](http://github.com/CraterCrash/godot-orchestrator/commit/4b664f58b81c3645bb9cb14fb098d92b9e05b1e8) - Update README.md
- [53663ae](http://github.com/CraterCrash/godot-orchestrator/commit/53663aecca29ebf5d91a6dc2707accb8df659e67) - GH-857 Align tab highlighting with Script tab behavior
- [9b17be0](http://github.com/CraterCrash/godot-orchestrator/commit/9b17be09d2ed46c720d71816c104c5a784975588) - GH-860 Default `settings/notify_about_pre-releases` to `false`
- [37ebe0d](http://github.com/CraterCrash/godot-orchestrator/commit/37ebe0dff249cdf3eed2a58737e9334a824be6d3) - GH-865 Prevent collapse to function with more than one data output pin
- [80082ff](http://github.com/CraterCrash/godot-orchestrator/commit/80082ff2f67ce47ca9ca0631297eb3b911739274) - GH-825 Refactor OScriptLanguage & add OScriptNodeFactory

## [2.2.dev1](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.2.dev1) - 2024-09-21

- [42d2626](http://github.com/CraterCrash/godot-orchestrator/commit/42d26265055423f3bedf6d2c8736936db17973b9) - GH-724 Fix copy-n-paste between two orchestrations
- [4e2824a](http://github.com/CraterCrash/godot-orchestrator/commit/4e2824a8173a5e06cfcd0f67d575837ee402ead8) - GH-807 Support named lookup of signals, used by `await` keyword
- [704cfba](http://github.com/CraterCrash/godot-orchestrator/commit/704cfbaef8961b06a1a183a3f8a01c02f16f4371) - GH-714 Support `ui_cut` action in `GraphEdit` controls
- [2901320](http://github.com/CraterCrash/godot-orchestrator/commit/29013204ce935ecc65741ba27d6e27399647b949) - GH-618 Reset pin default on connection
- [bdd11a0](http://github.com/CraterCrash/godot-orchestrator/commit/bdd11a0a9b823873b871d1d1e36fa6afecb7fbf9) - GH-670 Fix reset pin to default value
- [fef3e93](http://github.com/CraterCrash/godot-orchestrator/commit/fef3e93787de912233d5a0fe53e658002c6db660) - GH-803 Component panels react to context-menu shortcuts
- [32a2b02](http://github.com/CraterCrash/godot-orchestrator/commit/32a2b02bdab4b5fca51d1229389a5f4c9763b003) - GH-761 Use new ClassDB methods to fetch property getter/setter
- [57c0207](http://github.com/CraterCrash/godot-orchestrator/commit/57c0207a3b166f67bc6b3fa49c5841a5e4a12dab) - GH-800 Temporarily disable some property get/set validation rules
- [5da872b](http://github.com/CraterCrash/godot-orchestrator/commit/5da872b7f6134661a013eaaafb64208498d7da55) - GH-798 Remove unnecessary instantiate scene cache
- [dc0b0f9](http://github.com/CraterCrash/godot-orchestrator/commit/dc0b0f9a5c3e4721b69060a305fa335cef6039a2) - GH-796 Guard against `get_current_scene` returning null
- [d5558ee](http://github.com/CraterCrash/godot-orchestrator/commit/d5558eed96faef74eb7e11d1afd3b8fba27fd3bd) - GH-794 Fix default value evaluation in ScriptPlaceHolderInstance
- [30eea75](http://github.com/CraterCrash/godot-orchestrator/commit/30eea75518767f382824df6f77a113f9e7c32a99) - Build system cleanup and refactor
- [5a0d577](http://github.com/CraterCrash/godot-orchestrator/commit/5a0d5773cad9f2df761e21c2791dfde3efad5660) - GH-467 Only save node size when manually resized (Godot 4.3+)
- [a994dff](http://github.com/CraterCrash/godot-orchestrator/commit/a994dff4d479f36f817f6033a7398fc817866327) - GH-786 Add tooltip for `Orchestration Build` button
- [965fec3](http://github.com/CraterCrash/godot-orchestrator/commit/965fec33ef33a57127eeb65ab019a994d158c2c3) - GH-778 Fix crash on Windows 10 - Revert GH-653
- [7bbc5a1](http://github.com/CraterCrash/godot-orchestrator/commit/7bbc5a142ed1c29b6198e10b70a525a840a23f1f) - Prefer `&&` rather than `and` operator
- [3307fd1](http://github.com/CraterCrash/godot-orchestrator/commit/3307fd16a3ac9d6fd1f920ebe19e311ab634b06f) - GH-774 Relax return node validation for sequence nodes
- [301fd21](http://github.com/CraterCrash/godot-orchestrator/commit/301fd21f37c5bf3fed16bf12d8ef157c0659c162) - GH-771 Make exported variables searchable in `All Actions`
- [e23dbfe](http://github.com/CraterCrash/godot-orchestrator/commit/e23dbfeaafef74055bf10d2970a0a0bf2bdae35f) - [ci] Cleanup CI build configuration
- [3312036](http://github.com/CraterCrash/godot-orchestrator/commit/331203666e40637ce2944401e4136bdaea51f137) - GH-765 Disable debug symbols on Linux/Android builds
- [542ce01](http://github.com/CraterCrash/godot-orchestrator/commit/542ce01fabf5e320737269633ce7e483236c86bb) - GH-427 Support custom icons for comment nodes
- [3bccbb6](http://github.com/CraterCrash/godot-orchestrator/commit/3bccbb67379900a164144f4f48357b5535bbd2de) - GH-756 Fix validated variable getter state consistency
- [6dff26d](http://github.com/CraterCrash/godot-orchestrator/commit/6dff26d764c2a1cea7edacfa9acd8ca9a79dccd5) - GH-712 Clamp `All Actions` dialog within screen rect.
- [4301d24](http://github.com/CraterCrash/godot-orchestrator/commit/4301d24acbd4ce0082addb8e6ff8fad3c0b481a0) - GH-752 Restrict arrow-key movement to only selected elements
- [1953283](http://github.com/CraterCrash/godot-orchestrator/commit/1953283d359809cedf0486373a76580339f53841) - GH-736 Fix knot movement/alignment
- [0140edd](http://github.com/CraterCrash/godot-orchestrator/commit/0140eddf2b4a54381c82f77e55ba3178e37ad2b4) - GH-737 Allow knot node operations within comment nodes
- [106e0e5](http://github.com/CraterCrash/godot-orchestrator/commit/106e0e5c3afdf669e0a92a69172714097500271e) - GH-738 Fix `Select Group` to include Knots and Nodes
- [0333834](http://github.com/CraterCrash/godot-orchestrator/commit/03338348e11a0e820e93a6e75341f2325010417b) - GH-655 Use `EditorInterface::get_singleton` where possible
- [ad909cf](http://github.com/CraterCrash/godot-orchestrator/commit/ad909cf29f978e8fd5baeca69c8fdb5a0d87d74c) - GH-743 Fix update picker is_after logic

## [2.1.stable](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.1.stable) - 2024-08-15

- [0413239](http://github.com/CraterCrash/godot-orchestrator/commit/041323953b3accec5ab93e954faa6c2a87678943) - GH-741 Bump godot-engine/godot-cpp to 4.3.stable
- [20b5362](http://github.com/CraterCrash/godot-orchestrator/commit/20b5362e615044adb3e7b24e52a8fcc58015867a) - GH-716 Include knots in movement with arrow keys
- [94b0204](http://github.com/CraterCrash/godot-orchestrator/commit/94b02042f96641d3eac2cab55d613afbf377a6e3) - Fix broken help
- [45496a9](http://github.com/CraterCrash/godot-orchestrator/commit/45496a9880762aab3ad5d41cf2a4e6fb07a0212e) - GH-727 Add constant variable support
- [23d6427](http://github.com/CraterCrash/godot-orchestrator/commit/23d64278ed633189cbdc43388bedb770cc29064d) - GH-722 Correctly copy node state using `ui_copy` action
- [8f882c9](http://github.com/CraterCrash/godot-orchestrator/commit/8f882c9c058ab15a4d87eb5ea3d3990df0dca94e) - GH-715 Alphabetically sort singleton list in inspector
- [c163185](http://github.com/CraterCrash/godot-orchestrator/commit/c163185edefccaea83e56f66c6d855fedb0ae13b) - GH-729 Graph grid settings & cache left/right panel layouts
- [b8b306a](http://github.com/CraterCrash/godot-orchestrator/commit/b8b306a37cee4909373f84119d5acbaa757c23e9) - GH-718 Add variable descriptions to get/set node tooltips
- [a01c35d](http://github.com/CraterCrash/godot-orchestrator/commit/a01c35d502b7646350d7d9b197dcbeeff2dfbc15) - GH-716 Allow moving nodes using arrow keys
- [34f0374](http://github.com/CraterCrash/godot-orchestrator/commit/34f037445b17e284404638afd6a940bf876dcd39) - Set min height on Orchestration build output panel
- [112cc20](http://github.com/CraterCrash/godot-orchestrator/commit/112cc201d6dd8d996f3146c86279d8053528196c) - GH-705 Correctly size controls based on editor scale
- [f727883](http://github.com/CraterCrash/godot-orchestrator/commit/f727883e9b4e7d0cf5830c32232bf06c809d0b3f) - GH-707 Add GraphNode alignment options
- [c280586](http://github.com/CraterCrash/godot-orchestrator/commit/c280586ea802e6bf2c71a230f3d36a63e7db0d04) - GH-680 Fix crash on load
- [57ec042](http://github.com/CraterCrash/godot-orchestrator/commit/57ec042d66b49f6886408cf675ae034568d0d19c) - GH-680 Support several serialization methods: `get_dependencies`, `rename_dependencies`, and `get_resource_script_class`
- [bb10544](http://github.com/CraterCrash/godot-orchestrator/commit/bb10544bdbd3d8a79b7bb36e98c7e95521a33fa3) - GH-680 Fix loading external resources
- [beeeb84](http://github.com/CraterCrash/godot-orchestrator/commit/beeeb847def000c0a30e1b1aa74ec70d3a02cf0f) - GH-703 Update FileSystemDock on file save as
- [20ba58a](http://github.com/CraterCrash/godot-orchestrator/commit/20ba58a9194853486d760f328382e3d1dad2a0b8) - GH-693 Disable conversion to binary format on export
- [11ddf96](http://github.com/CraterCrash/godot-orchestrator/commit/11ddf96977b40f67f6de966d289614adabcaf1d2) - GH-693 Emit resolved target object for method chain
- [bb5cb4d](http://github.com/CraterCrash/godot-orchestrator/commit/bb5cb4d436522ddeadb8cbb36f5cfb19de69bbc4) - GH-701 Fix type cast honoring global script classes
- [e539db6](http://github.com/CraterCrash/godot-orchestrator/commit/e539db620783516c23dbf7695379ff9b33402b5d) - Update copyright headers
- [32c9ea3](http://github.com/CraterCrash/godot-orchestrator/commit/32c9ea34432dba333de3f4df74c5a8111021951a) - GH-697 Synchronize graph on theme changes
- [cccc3a5](http://github.com/CraterCrash/godot-orchestrator/commit/cccc3a542587690e4998ee7c43e7bc93a60082cd) - GH-696 Avoid error when disabling recent files option
- [7190c7c](http://github.com/CraterCrash/godot-orchestrator/commit/7190c7c388610d610186b965701df56f5aa96131) - GH-684 Fix call mode semantics
- [98eedaa](http://github.com/CraterCrash/godot-orchestrator/commit/98eedaa05c40f7045e00d58b37925873d82d2167) - GH-640 Fix Godot 4.2 compatibility
- [adf4c7e](http://github.com/CraterCrash/godot-orchestrator/commit/adf4c7eb1a663497abf8fa8639e24fee7d77c82a) - GH-640 Add dragging function creates callable
- [90120ad](http://github.com/CraterCrash/godot-orchestrator/commit/90120ad22d48d574711526423cacf1b3392a712a) - GH-689 Introduce `PackedVector4Array` serialization handlers
- [cecce3c](http://github.com/CraterCrash/godot-orchestrator/commit/cecce3c66d197f2e1e22d1ee181755b1ef7fb726) - GH-691 Use function argument names rather than class names
- [624856e](http://github.com/CraterCrash/godot-orchestrator/commit/624856e9144c03f6b029f89b52c9b9befaeba2b6) - GH-682 Fix type resolution
- [af6f01a](http://github.com/CraterCrash/godot-orchestrator/commit/af6f01a80a3ab883f5b07ab727e9b4b1025b4358) - GH-682 Fix exporting `Node` based variable types
- [0b4de3a](http://github.com/CraterCrash/godot-orchestrator/commit/0b4de3ab75e62ddd2970e12be8a0a0a4bec322a0) - GH-687 Fix usage of script vs p_script
- [44e310d](http://github.com/CraterCrash/godot-orchestrator/commit/44e310d6054f913c7b3a051f4e83129c586d7895) - GH-687 Check script type on debugger signals

## [2.1.rc4](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.1.rc4) - 2024-08-08

- [cfa9b38](http://github.com/CraterCrash/godot-orchestrator/commit/cfa9b3885b08e9cda6e6803f53999e9a3ecd143e) - GH-657 Bump godot-engine/godot-cpp to 4.3.rc2
- [24eb6e7](http://github.com/CraterCrash/godot-orchestrator/commit/24eb6e7491c05a222c204752cd8e0b0c9c66563b) - GH-648 Permit any output to connect to boolean input
- [2a7c311](http://github.com/CraterCrash/godot-orchestrator/commit/2a7c31129718b8c02665f0eafdaf0c3590f0452f) - GH-636 Don't wrap text in `PrintStringUI`
- [f2289db](http://github.com/CraterCrash/godot-orchestrator/commit/f2289db71f53be4270c990fd047f3c8c137eb743) - GH-674 Fix Await signal to work with parameterized signals
- [c1d1a24](http://github.com/CraterCrash/godot-orchestrator/commit/c1d1a245f8cb3750035e99f3f9386444c117a13f) - GH-675 Relax validation on function arguments with default values
- [fb2bd08](http://github.com/CraterCrash/godot-orchestrator/commit/fb2bd08ab020892a0409fa6044aac4f297ca2d01) - Reset assign type on duplicate/paste
- [41269c3](http://github.com/CraterCrash/godot-orchestrator/commit/41269c313e1141578737e8622d4bf72e2a6699d7) - Improve Local Variables Initialization & Assignment UX
- [111d1c5](http://github.com/CraterCrash/godot-orchestrator/commit/111d1c5744cc392cea38e2b9f0a65b5f706d07b3) - GH-658 Fix Godot 4.2 compatibility
- [62492a2](http://github.com/CraterCrash/godot-orchestrator/commit/62492a2d7f7374d7c4354a81e3bd8eac6f50f647) - GH-658 Add version pick to plug-in updater subsystem
- [f04744c](http://github.com/CraterCrash/godot-orchestrator/commit/f04744c3620a54fa8c80eba23627819591873f8a) - Fix typo
- [75ff266](http://github.com/CraterCrash/godot-orchestrator/commit/75ff266bf250626eafcac356c3f773ead4d31486) - GH-666 Correctly handle Toggle Breakpoint keybind
- [f50568e](http://github.com/CraterCrash/godot-orchestrator/commit/f50568e60d8956a1f8e786e6fdbc3369f401c8c0) - GH-667 Relax operator node connection requirements
- [31e2f9c](http://github.com/CraterCrash/godot-orchestrator/commit/31e2f9ce5fab706d51d31c49feae7ee28c8147f4) - GH-664 Use screen space for calculating paste position
- [973f7c3](http://github.com/CraterCrash/godot-orchestrator/commit/973f7c330e12e612de8c09ac5430ea0ff5e50971) - GH-662 Exclude loop-based pins from return value check
- [6bfacdd](http://github.com/CraterCrash/godot-orchestrator/commit/6bfacdde27a550c7f4c21daba715a4cb8ee89c42) - Add release_manifests.json
- [a0f141c](http://github.com/CraterCrash/godot-orchestrator/commit/a0f141c0fa13090731634e4710883170bcc718e5) - GH-646 Only reset return value when last return node removed
- [1f92561](http://github.com/CraterCrash/godot-orchestrator/commit/1f925615da23f9952e962fdef31d9ae7b1bc29a2) - GH-646 Allow return nodes to be duplicated
- [a7c4ddb](http://github.com/CraterCrash/godot-orchestrator/commit/a7c4ddbca25d981954c8a877c6443c5a13519957) - GH-646 Function graph validation for return node links
- [0392024](http://github.com/CraterCrash/godot-orchestrator/commit/0392024f5d75ac966f39bd43abfa6cced9af44f5) - GH-651 Move build/validate output to a bottom panel
- [d9354f9](http://github.com/CraterCrash/godot-orchestrator/commit/d9354f9e86bea89d6f3c758507638b380b78e389) - GH-647 Store/Cache/Sync knots correctly on pin disconnects
- [9a5e5d5](http://github.com/CraterCrash/godot-orchestrator/commit/9a5e5d53f38d57c93299227c4d7526583384f8ed) - GH-653 Resize main toolbar icon with display scale
- [f9892fb](http://github.com/CraterCrash/godot-orchestrator/commit/f9892fbe783243bc4808dbdc3f02255f5e588c70) - Fix lambda unused capture
- [46dc432](http://github.com/CraterCrash/godot-orchestrator/commit/46dc432b56a41e26678164def29beac51eecd447) - GH-643 Allow `String` to connect to `StringName` pins
- [f29fe1b](http://github.com/CraterCrash/godot-orchestrator/commit/f29fe1bb4ee5e338f0a69d636e74fbf1c16c9299) - GH-642 Allow `Object` to connect to `Boolean` pins
- [4e514d2](http://github.com/CraterCrash/godot-orchestrator/commit/4e514d2eb25896a22b19362d3f1dca376bd73813) - GH-638 Guard against reconnection on node duplication
- [35b82cb](http://github.com/CraterCrash/godot-orchestrator/commit/35b82cb27b8df1dadedcab5798894a5f7ce8bce2) - Correctly clean-up placeholder instances
- [9fc12e9](http://github.com/CraterCrash/godot-orchestrator/commit/9fc12e9dbdb8650eb51f4b0970111abaff4624e9) - Fix editor crashes reverting inspector values for constant nodes
- [6e33e12](http://github.com/CraterCrash/godot-orchestrator/commit/6e33e12c5a3a35c5c942bc8f83f3594542632bd6) - GH-632 Add new function call node color variants
- [beb964c](http://github.com/CraterCrash/godot-orchestrator/commit/beb964c3c1fe2a528a3602b62cfd9191a263783b) - GH-630 Add link to GH issue
- [214c184](http://github.com/CraterCrash/godot-orchestrator/commit/214c18487f5560fb1c73d1e5bbb015f98f6955ce) - GH-630 Enhance `VariableGet` with validation mode
- [26d8395](http://github.com/CraterCrash/godot-orchestrator/commit/26d8395e1538ea7761c156156444aad85d1440b0) - GH-634 Protect against double callback dispatch in Godot 4.2.x
- [832ac92](http://github.com/CraterCrash/godot-orchestrator/commit/832ac92b961882e080f0068d963a2899fc1a2e95) - GH-628 Synchronize signal slot disconnect UI updates
- [10e8a74](http://github.com/CraterCrash/godot-orchestrator/commit/10e8a74b893245c5bd07fd08c2378c60aeed23b7) - GH-626 Fix handling of script placeholder properties

## [2.1.rc3](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.1.rc3) - 2024-07-29

- [1e12d00](http://github.com/CraterCrash/godot-orchestrator/commit/1e12d009c0af686f74968fde6ecd1d176c176ac9) - Update about dialog details
- [ac097d0](http://github.com/CraterCrash/godot-orchestrator/commit/ac097d0be937b2d91606354fbe72ff3c967410dd) - GH-622 Revert commit 8f15816b092c9a92b878db319a496430925f8816
- [5388fa3](http://github.com/CraterCrash/godot-orchestrator/commit/5388fa35b8ed5d59f30196a408a26839f25bd7b8) - GH-595 Improve initial rendering of variable type selection
- [51947b2](http://github.com/CraterCrash/godot-orchestrator/commit/51947b2ea98dc8ad6e23587f591db4028f8589bb) - GH-610 Add in-editor script node documentation
- [bfd94ff](http://github.com/CraterCrash/godot-orchestrator/commit/bfd94ff17c6468445b27878ebd3a0e9a5a2562d7) - GH-607 Improve changing variable types
- [129ce72](http://github.com/CraterCrash/godot-orchestrator/commit/129ce72aa3024fd7d620984f8000897c2f1f47de) - GH-617 Retain `PrintString` defaults across node refreshes
- [97e1ed1](http://github.com/CraterCrash/godot-orchestrator/commit/97e1ed1b458018b888fc654422d6193e5b619d18) - GH-612 Fix view documentation not rendering
- [d089784](http://github.com/CraterCrash/godot-orchestrator/commit/d089784055580b4b656cc4155ce278012a14b4f5) - GH-614 Mark several classes as internal
- [3fefdbb](http://github.com/CraterCrash/godot-orchestrator/commit/3fefdbb2db6e384ac8ce31618aa1405b66eb603a) - GH-605 Improve numeric default value widget validation
- [5c4babd](http://github.com/CraterCrash/godot-orchestrator/commit/5c4babd81727d74ad0f96e05fbbac77c37cadae4) - GH-596 Render `int`, `float`, and `bool` with user-friendly names
- [26b28b1](http://github.com/CraterCrash/godot-orchestrator/commit/26b28b1a5cf781b3124b380d328de1ba89fc20ca) - GH-592 Add optional delete node confirmation dialog
- [b7e2622](http://github.com/CraterCrash/godot-orchestrator/commit/b7e26221a0a93376dd1b0c454c8c8a50ab054586) - GH-593 Fix collapse to function bugs
- [b6f8ddc](http://github.com/CraterCrash/godot-orchestrator/commit/b6f8ddce8254c79efae3f0280dc83daa1bcd47cd) - GH-603 Permit selecting abstract types for variable definitions
- [f1cda9f](http://github.com/CraterCrash/godot-orchestrator/commit/f1cda9f164582a0b09a5c986684de72221c9eb0b) - Remove random UtilityFunction::print call
- [055870b](http://github.com/CraterCrash/godot-orchestrator/commit/055870b251fff93db832980faf49b7e3d468379f) - GH-590 Use our own instance of ScriptCreateDialog
- [bee5a48](http://github.com/CraterCrash/godot-orchestrator/commit/bee5a48c4c5e4e833fced578a832fe1e3b727f5e) - Fix lambda capture warnings
- [aed1d08](http://github.com/CraterCrash/godot-orchestrator/commit/aed1d08bae4cf890eb12e6dbbf2696cdb2acbfaa) - Fix some signed/unsigned build warnings
- [679c0f6](http://github.com/CraterCrash/godot-orchestrator/commit/679c0f6bfba93f908cefce3697bad12ce33cde7f) - GH-584 Disable knot creation inside node rect
- [ebbdfff](http://github.com/CraterCrash/godot-orchestrator/commit/ebbdfff590b60026efc1dc63cb03b3dcd7cd6c44) - GH-574 Strengthen validation for adding/renaming component items
- [8dd4e2f](http://github.com/CraterCrash/godot-orchestrator/commit/8dd4e2f59bd14179ca9c421cc390d43ef2b8320f) - GH-582 Auto-select first action when node first placed
- [8f15816](http://github.com/CraterCrash/godot-orchestrator/commit/8f15816b092c9a92b878db319a496430925f8816) - GH-583 Always show execution pins on user-defined script functions
- [7c8f566](http://github.com/CraterCrash/godot-orchestrator/commit/7c8f5660837d0e40c29038ff3ba3ed22be04473e) - GH-578 Make debugger errors more clear
- [b9ea73f](http://github.com/CraterCrash/godot-orchestrator/commit/b9ea73f34590eb2a57920835b49580f3d9aefb1e) - GH-575 Correctly focus script on editor breakpoints
- [98fdb36](http://github.com/CraterCrash/godot-orchestrator/commit/98fdb36ae7d5d1de95a1e072e3d21ee5f1665c00) - GH-579 Raise breakpoint when input action has no action name

## [2.1.rc2](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.1.rc2) - 2024-07-21

- [5f9f3f4](http://github.com/CraterCrash/godot-orchestrator/commit/5f9f3f4fbb4a1561e57df5cde982d247aa38161c) - GH-567 Correctly validate local variable node connection
- [6647c3a](http://github.com/CraterCrash/godot-orchestrator/commit/6647c3af4d3249d21d90cac200f81a26fd8f98fd) - GH-568 Relax property validation

## [2.1.rc1](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.1.rc1) - 2024-07-21

- [53c628a](http://github.com/CraterCrash/godot-orchestrator/commit/53c628ad2b8a18eccbbc1ce5cd82187042285ca2) - GH-563 Relax validation on function result node
- [8d50ade](http://github.com/CraterCrash/godot-orchestrator/commit/8d50ade7516e6e89a143e6f2a59e44a657042d7b) - GH-560 Add global script filename to search results
- [f263523](http://github.com/CraterCrash/godot-orchestrator/commit/f263523340cfb4e0abbed514bf7db33b8a314cb3) - GH-555 Add custom icons for pass-by reference/value
- [922ac98](http://github.com/CraterCrash/godot-orchestrator/commit/922ac9880afa5195d4dcf07ab9a2880b20f80cf7) - GH-555 Add pass-by- value/reference to property container UI
- [a1f3f1a](http://github.com/CraterCrash/godot-orchestrator/commit/a1f3f1aff7767f37b7ec32f599b36d2f95d3a8c6) - GH-559 Fix `text_submitted` due to multiple registration calls
- [b52afce](http://github.com/CraterCrash/godot-orchestrator/commit/b52afceb24ff873a06e1e6be7ac7807c9c95c87c) - Fix API compatibility with Godot 4.2.1
- [796a680](http://github.com/CraterCrash/godot-orchestrator/commit/796a6802d7c049dfc39002a2aece071b880542f8) - Fix build errors
- [c9df854](http://github.com/CraterCrash/godot-orchestrator/commit/c9df854fbc40c636a8ffc3f8a0c90ac5329c8efe) - GH-556 Align variable type plugin with new search type
- [6147e28](http://github.com/CraterCrash/godot-orchestrator/commit/6147e280bfe0c4ac93974cd2c669b3a5a2993d50) - GH-556 Generalize "select type" dialog
- [1768f9a](http://github.com/CraterCrash/godot-orchestrator/commit/1768f9a735e57659ee346215fb1a7fdf5d407aea) - GH-551 Avoid duplicating return nodes on rename
- [d50b28c](http://github.com/CraterCrash/godot-orchestrator/commit/d50b28cf8ce2261862f8c65b0657c45867dad260) - GH-497 Function/Signals support all class/argument types
- [d3ba7c9](http://github.com/CraterCrash/godot-orchestrator/commit/d3ba7c9c5dffc8552d56eddf1b6002c06d9e6ad2) - GH-549 Add additional keywords for ComposeFrom/Decompose nodes
- [88d2df0](http://github.com/CraterCrash/godot-orchestrator/commit/88d2df06d4c64b3683d7af31ca30286c07c9ad75) - GH-547 Duplicate node instances on paste
- [77466fe](http://github.com/CraterCrash/godot-orchestrator/commit/77466febb878cb31224c7f40a2acd8f878bbbeac) - GH-338 Support variables as script global class types
- [ab763ab](http://github.com/CraterCrash/godot-orchestrator/commit/ab763ab39ae83d20504e51683d3a49627f311e63) - GH-534 Correctly resolve self for NodePath popups
- [a04a9d9](http://github.com/CraterCrash/godot-orchestrator/commit/a04a9d9d785dba4b61171056a2ff979ed60d08c7) - GH-532 Fix Godot 4.2.1 compatibility
- [43379ec](http://github.com/CraterCrash/godot-orchestrator/commit/43379ecce7ceb2ad2baedaf9f9c791e9119877d0) - GH-532 Align Get Scene Node class on path change
- [674fb74](http://github.com/CraterCrash/godot-orchestrator/commit/674fb7480378bb660bbe4416e4c0f10921ac020b) - GH-537 Fix Godot 4.2.1 compatibility
- [c011903](http://github.com/CraterCrash/godot-orchestrator/commit/c0119037d32b3122a93e884558669bccc1f369b2) - GH-537 Fix target resolution
- [dbced0d](http://github.com/CraterCrash/godot-orchestrator/commit/dbced0dedcb1dbd68875ba215b284aa802f50e4f) - GH-542 Fix tween animation for focusing graph nodes
- [5f6de0e](http://github.com/CraterCrash/godot-orchestrator/commit/5f6de0e698db7c4e58f7d204461a606c20f1517d) - GH-533 Ignore default value widgets on target pins
- [7df2f18](http://github.com/CraterCrash/godot-orchestrator/commit/7df2f18d79ac813360480010457c1eb65bbde699) - Add Mac, Linux, and Web ignores to .gitignore file
- [1230949](http://github.com/CraterCrash/godot-orchestrator/commit/1230949ede0ce318f0cc113e208c65dbae9f48e4) - GH-539 Fix placeholder instance clean-up

## [2.1.dev4](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.1.dev4) - 2024-07-15

- [b642c29](http://github.com/CraterCrash/godot-orchestrator/commit/b642c29884fe472dc38110c55fcc0b8aad46ed91) - GH-529 Improve add component item workflow
- [3e4985e](http://github.com/CraterCrash/godot-orchestrator/commit/3e4985efd38b42f41688012234c730b698c255ed) - GH-527 Improve all action search/category classifications
- [0edcefa](http://github.com/CraterCrash/godot-orchestrator/commit/0edcefaeafd3dc3393d16198aa76cc6c52a06ee4) - GH-59 Add configurable corner/border radius
- [0ba992d](http://github.com/CraterCrash/godot-orchestrator/commit/0ba992d7a24ea1c1165ef2616dd0d1b1b5a52494) - GH-521 Fix compatibility issue with Godot 4.2.1 and `set_auto_translate_mode`
- [3d99bc5](http://github.com/CraterCrash/godot-orchestrator/commit/3d99bc5b2f7b54d2a93886fbd6a486c0b9408f81) - GH-521 Fix compatibility issue with Godot 4.2.1 and `containsn`
- [831a41b](http://github.com/CraterCrash/godot-orchestrator/commit/831a41bc306c4707fd6f19d1fc01fee0b76e8ddd) - Add instanced scene indicator to scene node selector
- [234cd19](http://github.com/CraterCrash/godot-orchestrator/commit/234cd19db366b7e5555cfec74f961fb8ad49ba41) - GH-472 Show event actions when dragging from input pins
- [b2a7206](http://github.com/CraterCrash/godot-orchestrator/commit/b2a720647aa6faa45ef9cfc3ad50553af68bf2df) - GH-473 Improve view documentation jump for nodes
- [de1e4b5](http://github.com/CraterCrash/godot-orchestrator/commit/de1e4b5f05af7fe65f3304cbaa9014488e6c676a) - Update .gitignore
- [f99c6ea](http://github.com/CraterCrash/godot-orchestrator/commit/f99c6eabe809749b56704431e460b02b083006c1) - GH-498 Improve NodePath dialogs for nodes and properties
- [990e3dd](http://github.com/CraterCrash/godot-orchestrator/commit/990e3dd7f2e17ef39471ed48eb1f78c9a6b495c1) - GH-491 Improve graph node left/right column rendering
- [9cb1179](http://github.com/CraterCrash/godot-orchestrator/commit/9cb11794849f123f33c323a347cb6726bd5e5555) - GH-496 Track editor graph state in editor cache
- [5dbd06c](http://github.com/CraterCrash/godot-orchestrator/commit/5dbd06cf91149785d40ee66c094c13a711dfb3ce) - GH-512 Correctly resolve target object
- [0b67f50](http://github.com/CraterCrash/godot-orchestrator/commit/0b67f5010d6478e304bd331fbf5709c94362d66c) - GH-517 Run orphan fix-up during Orchestration post-initialize
- [a4275f5](http://github.com/CraterCrash/godot-orchestrator/commit/a4275f513b8e2742d7be8ff73ff44040e28bed33) - GH-511 Add label to Enum/Bitfield return function values
- [30b4a57](http://github.com/CraterCrash/godot-orchestrator/commit/30b4a570b4e9894054fc129434ad2b272aedca5c) - GH-510 Pass class type initialization to New Object nodes
- [f6dd912](http://github.com/CraterCrash/godot-orchestrator/commit/f6dd9128b744b886b6bef9308998d0299f32a7ed) - GH-505 Make node context menu items multi-select aware
- [160d8db](http://github.com/CraterCrash/godot-orchestrator/commit/160d8dbcc572ff0e8902aab34a55730221e24498) - GH-490 Make PopupMenu instances dynamic for Node/Pins
- [e671c01](http://github.com/CraterCrash/godot-orchestrator/commit/e671c0124c5f119ad1468d6b748ceabcda25ae5c) - GH-502 Fix action menu item alignment
- [54c7fde](http://github.com/CraterCrash/godot-orchestrator/commit/54c7fde8bc0b3f7240f8a268ba692e9497e8f2bd) - GH-470 Operator node - always autowire first eligible pin
- [fd31f74](http://github.com/CraterCrash/godot-orchestrator/commit/fd31f74b4b67c4d793535c11706fb768414eab29) - GH-488 Update InspectorDock when ProjectSettings change
- [2b12f63](http://github.com/CraterCrash/godot-orchestrator/commit/2b12f6328db43b537ae05830a18ef669be289a0f) - Add a boolean setting to show the 'arrange' button in the UI.
- [f7e000a](http://github.com/CraterCrash/godot-orchestrator/commit/f7e000a6bb00b1a6dde6bc890013671e4036b6b1) - GH-487 Changing function argument type resets default value
- [9dfde8a](http://github.com/CraterCrash/godot-orchestrator/commit/9dfde8a77f3271164fb36e5c20b0821588b0f47d) - GH-444 Fix potential nullptr exception
- [e38942d](http://github.com/CraterCrash/godot-orchestrator/commit/e38942df8ea7be344b23525c597c660714c16ba4) - GH-444 Add compatibility for Godot 4.2
- [a4f079b](http://github.com/CraterCrash/godot-orchestrator/commit/a4f079b73b59f4373e4073279c0f95ddda8e03d5) - GH-444 Update demo orchestrations to format 2
- [b83ba9f](http://github.com/CraterCrash/godot-orchestrator/commit/b83ba9f9fdb42059f5b98249e87c3441c8b1aa8f) - GH-444 Improve pin type safety & validation
- [13093f5](http://github.com/CraterCrash/godot-orchestrator/commit/13093f53b8b9a07e01d66da296d790151890c304) - GH-444 Fix variable type resolution
- [6096533](http://github.com/CraterCrash/godot-orchestrator/commit/609653362f299c267d2ff233e416b608effd5160) - GH-444 Correctly identify variant arguments for functions/signals
- [7ef6caa](http://github.com/CraterCrash/godot-orchestrator/commit/7ef6caa28439f84fb32708b6a1a50cf6ed250e9b) - GH-444 Use helper methods for pin flags
- [283e25b](http://github.com/CraterCrash/godot-orchestrator/commit/283e25b870f4c58c4ee5bf521f7334b96165422f) - GH-486 Add connection color mapping for PackedVector4Array
- [5b99f04](http://github.com/CraterCrash/godot-orchestrator/commit/5b99f04807640b9755dccbe35f5966864d30e687) - GH-492 Allow disconnect slot from component panels
- [d185cda](http://github.com/CraterCrash/godot-orchestrator/commit/d185cda8d2d1c422a33c4cd3a1eac3bce48c9ad0) - GH-492 Correctly resolve signal argument types
- [ac5e2a2](http://github.com/CraterCrash/godot-orchestrator/commit/ac5e2a219b98cc62f4865dc458d03857baf44750) - GH-484 Show enum, bitfield, class icons in variable panel
- [80ed037](http://github.com/CraterCrash/godot-orchestrator/commit/80ed037f552e13162e3a2d4d835b9e2e75d38f66) - GH-482 Exclude internal properties from action menu
- [2d5a2dd](http://github.com/CraterCrash/godot-orchestrator/commit/2d5a2ddbab5057c21115c4f20f3d1ee88096124e) - Fix typo in build log warning message
- [9c34a96](http://github.com/CraterCrash/godot-orchestrator/commit/9c34a96922d7bfd4185544a919e9d1261ec8d230) - GH-477 Fix ExtensionDB generator
- [efb7131](http://github.com/CraterCrash/godot-orchestrator/commit/efb7131326b53bcb596042b476989bbcb59e3c83) - GH-476 Fix error handling in virtual machine
- [60e191c](http://github.com/CraterCrash/godot-orchestrator/commit/60e191c7f4c730c24d7132c3b61f511a0171b0a7) - GH-475 Fix variable property info init for class types
- [cacb2ca](http://github.com/CraterCrash/godot-orchestrator/commit/cacb2caa5378d0e2aba477c9e0dc42f63e885564) - GH-465 Apply "Refresh Nodes" option to all selected nodes
- [85b6500](http://github.com/CraterCrash/godot-orchestrator/commit/85b65006748431fcca3b4811f2868f118851b03a) - GH-452 Render knots snapped to the grid
- [80b2b98](http://github.com/CraterCrash/godot-orchestrator/commit/80b2b98f735ba7d9e6d13805f6fa77d2c94a0b11) - GH-285 Add EditorDebugger support (Requires Godot 4.3)
- [cc8e799](http://github.com/CraterCrash/godot-orchestrator/commit/cc8e7990f30f4f157fd785399d1d2a2dd0cb147a) - GH-421 Add Godot compatibility to README.md
- [8edae09](http://github.com/CraterCrash/godot-orchestrator/commit/8edae0900fd9b3fb5e88a9427ef8e05a7fe9cbc2) - GH-421 Add missing guards
- [72519a6](http://github.com/CraterCrash/godot-orchestrator/commit/72519a6f380eafcada6001c5615e70f8e27553f2) - GH-421 Bump .gdextension compatibility to 4.3
- [9e61df0](http://github.com/CraterCrash/godot-orchestrator/commit/9e61df023df95caf43940ffbce7e8f3da566b82d) - GH-421 Fix 4.3 stack allocation crash issues with RefCounted
- [764ea3f](http://github.com/CraterCrash/godot-orchestrator/commit/764ea3fec345318da1cbb2a0fcea3be5daa9de2e) - GH-421 Use `Resource::generate_scene_unique_id` instead
- [2bbd305](http://github.com/CraterCrash/godot-orchestrator/commit/2bbd305524347053208f74acb9d141ddfe61a92e) - GH-421 Add compile-time support for Godot 4.3.beta2+
- [c4f1af3](http://github.com/CraterCrash/godot-orchestrator/commit/c4f1af3f6aee94552fdf0772ecc42e0daf191680) - GH-421 Update ExtensionDB for Godot 4.3.beta2
- [8a00a61](http://github.com/CraterCrash/godot-orchestrator/commit/8a00a611e200b2dcca60ca296ca2d15fddfac416) - GH-421 Bump godot-engine/godot-cpp to 4.3.beta2
- [c8f57cc](http://github.com/CraterCrash/godot-orchestrator/commit/c8f57ccde2ac4a9b335660373bbd660d5bd751dd) - GH-460 Avoid variable panel exponential updates
- [fe17684](http://github.com/CraterCrash/godot-orchestrator/commit/fe17684ccadeb95c28067823e2e9dff710c1a77c) - GH-457 Introduce custom `FileDialog` implementation
- [b3144b7](http://github.com/CraterCrash/godot-orchestrator/commit/b3144b7b7d973c41237221e3619a06cb88c55a97) - GH-453 Fix create knot GraphNode index out of bounds error
- [563991b](http://github.com/CraterCrash/godot-orchestrator/commit/563991b4cb9d74d1fa69d29f8994be5d6e27f578) - GH-455 Fix collapse/expand fault in all actions menu
- [17fcc90](http://github.com/CraterCrash/godot-orchestrator/commit/17fcc903e898c5c6d07a6b669a22fff517111e46) - GH-263 Add default initializer values
- [d135caa](http://github.com/CraterCrash/godot-orchestrator/commit/d135caa1c4685f207996f0a68b2231255f43302e) - Refactor main layout & viewports
- [523adae](http://github.com/CraterCrash/godot-orchestrator/commit/523adae56f61af4228b5c87f6ccc529691736ebc) - Fix switch warning
- [7b7bfb2](http://github.com/CraterCrash/godot-orchestrator/commit/7b7bfb27a911a8cf162e8f663d8c0392ef055a65) - GH-263 Update demo to use text-based orchestrations
- [5f954d1](http://github.com/CraterCrash/godot-orchestrator/commit/5f954d135b00fd6294c1deefae6126d46a493432) - GH-263 Support text-based Orchestration format
- [d9734d8](http://github.com/CraterCrash/godot-orchestrator/commit/d9734d8bec4145176e75c4a28605db67d3456b14) - Add common macros header
- [e353986](http://github.com/CraterCrash/godot-orchestrator/commit/e35398655996044e6da052c8dd006f0e59aeaf2a) - Fix logical operator behavior
- [3e15c31](http://github.com/CraterCrash/godot-orchestrator/commit/3e15c31c8e2cfbeba1c8ac54566636cefffe112d) - Fix constructor init reorder warnings
- [4001860](http://github.com/CraterCrash/godot-orchestrator/commit/4001860495869ab7b38e370dbcbcdce53ce630bc) - Fix signed/unsigned comparison
- [f3fb7c0](http://github.com/CraterCrash/godot-orchestrator/commit/f3fb7c0cb4d44b0dd495aab9d63c510852625f2a) - Wrap error macro with braces
- [e8b49a2](http://github.com/CraterCrash/godot-orchestrator/commit/e8b49a208aee34b08fc9a692b6d43b47dab702a8) - Fix logical operator
- [1dfc31f](http://github.com/CraterCrash/godot-orchestrator/commit/1dfc31f781b7c3bbdf82431ba801c510a2ec0d8b) - [ci] Bump robinraju/release-downloader 1.10 to 1.11
- [36c6c53](http://github.com/CraterCrash/godot-orchestrator/commit/36c6c53d3b1aa9ba522821324b0ec900d77d3f9f) - GH-428 Fix function return types that are enum/flags
- [c626ac3](http://github.com/CraterCrash/godot-orchestrator/commit/c626ac3e9c4363fa73e6e35d94c29559362e21c4) - GH-438 Do not show validation success dialog on play game/scene
- [b788d85](http://github.com/CraterCrash/godot-orchestrator/commit/b788d85da569770ec47929563d16b37a742f8f43) - GH-416 Support instantiation of script-based classes
- [d120dad](http://github.com/CraterCrash/godot-orchestrator/commit/d120dad7f1ea036e6f0719e09fef4f50d9ebb8e7) - GH-423 Avoid reuse of default value instances
- [895a747](http://github.com/CraterCrash/godot-orchestrator/commit/895a74717263430219554695c5c3d50c5b540812) - GH-431 Upgrade of For w/Break nodes autowires aborted
- [187d764](http://github.com/CraterCrash/godot-orchestrator/commit/187d764d40837c5662c800322247e7c256d1c6fb) - GH-429 Fix compatibility with godot-minimal-theme 1.5.0
- [c32ec26](http://github.com/CraterCrash/godot-orchestrator/commit/c32ec26a6a00c2834143a651378adf4c6f01180c) - GH-434 Display validation results on success
- [63c3e71](http://github.com/CraterCrash/godot-orchestrator/commit/63c3e71301f8ca8e40e6bfbcee79a0c2bd993f8e) - Add fixup to validate button for orphaned nodes/connections
- [925d30b](http://github.com/CraterCrash/godot-orchestrator/commit/925d30bc91c648b0662fe779c520179e5d4febde) - GH-425 Fix upgrade bug with "For with Break" nodes
- [e3359d2](http://github.com/CraterCrash/godot-orchestrator/commit/e3359d23395f049732ad9ee4eebe8be8758f85be) - Add/Align usage of static `_bind_methods` in node classes
- [855fbb4](http://github.com/CraterCrash/godot-orchestrator/commit/855fbb44f7bc76352a54fbd4667671832963dfad) - GH-255 Apply property usage fixup to functions/signals
- [a64ee64](http://github.com/CraterCrash/godot-orchestrator/commit/a64ee645ed722dd8444096cdcc5491c814103c13) - GH-410 Enable friendly names by default
- [6e01d05](http://github.com/CraterCrash/godot-orchestrator/commit/6e01d057773a96533d08654ba84bdbf4b0ccb912) - GH-410 Add friendly names for Graph/Function component panels
- [74a89ef](http://github.com/CraterCrash/godot-orchestrator/commit/74a89ef35a2cc010fcc878e9ba99845bd12db648) - GH-418 Fix toolbar update when base type changes
- [572e012](http://github.com/CraterCrash/godot-orchestrator/commit/572e01254502aa20fe899f3f57f4bb8344fb6d25) - GH-414 Fix method exclusion logic to allow virtual methods

## [2.1.dev3](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.1.dev3) - 2024-06-16

- [3394eb5](http://github.com/CraterCrash/godot-orchestrator/commit/3394eb514e903c5a44f5d45981857b6a353a4ed2) - GH-408 Correctly handle component tree expand/collapse
- [5857499](http://github.com/CraterCrash/godot-orchestrator/commit/5857499fc95346c58051393a19817859771bc38a) - GH-405 Update variable tooltip text
- [9cbe57b](http://github.com/CraterCrash/godot-orchestrator/commit/9cbe57b27181de8d67ebb507381ee37c019d29f3) - GH-403 Remove redundant/superfluous text from node/pin names
- [39abada](http://github.com/CraterCrash/godot-orchestrator/commit/39abada76ccf1eba5886bb032e451deb14d91462) - GH-401 Update component panel when using context menu delete
- [f4e3fe7](http://github.com/CraterCrash/godot-orchestrator/commit/f4e3fe737946c0fcb62f033b406dae1bb6ec48b3) - GH-399 Spawn function return node when function has return value
- [0deffa7](http://github.com/CraterCrash/godot-orchestrator/commit/0deffa78f0bf7acbf2d0e6676660117325913043) - GH-364 Allow disabling autowire selection dialog
- [975b5e1](http://github.com/CraterCrash/godot-orchestrator/commit/975b5e1f7233c726125eff94fe35ac3e8f544c4d) - GH-364 Improved autowire with selection dialog
- [360678a](http://github.com/CraterCrash/godot-orchestrator/commit/360678ad7847662a9a7ddd29484f5a98f256bac8) - GH-366 Permit deleting event nodes like any other node
- [e9f4dc9](http://github.com/CraterCrash/godot-orchestrator/commit/e9f4dc91d66d3a077bb28ba76236133880e84a31) - GH-394 Split virtual machine from `OScriptInstance`
- [728bb81](http://github.com/CraterCrash/godot-orchestrator/commit/728bb813c88b3d5d79a60f5e1be842027c577557) - GH-392 Allow reselect in component panel item lists
- [b46ec6e](http://github.com/CraterCrash/godot-orchestrator/commit/b46ec6e1cd2a20de2ba23fb9a225cff646eaa1d0) - GH-365 Add disconnect control flow on drag option
- [d2c3e05](http://github.com/CraterCrash/godot-orchestrator/commit/d2c3e05e4ea76d7bf24f19b5bd1d3fd2445dffe4) - GH-379 Component panels honor editor theme
- [394f7e7](http://github.com/CraterCrash/godot-orchestrator/commit/394f7e7eaf7757ff16568aed4579ab738386eb86) - GH-390 Fix compatibility with the custom Godot minimal theme
- [fd4e21b](http://github.com/CraterCrash/godot-orchestrator/commit/fd4e21b2c5f8b8eb41bd330946ad86d641a172e1) - GH-382 Avoid recent history duplicates
- [11202e5](http://github.com/CraterCrash/godot-orchestrator/commit/11202e500ae9fa9b785e7d242301ccf53e0e2c87) - GH-385 Fix instantiate scene to respect input pin
- [a12f6b6](http://github.com/CraterCrash/godot-orchestrator/commit/a12f6b685c1be4810bf69b136777371da9d892e1) - GH-383 Split out `Orchestration` contract and refactors
- [3f2f461](http://github.com/CraterCrash/godot-orchestrator/commit/3f2f46186cae84d38379671a466027a42041a14e) - GH-360 Select action names from drop-down list
- [1b73261](http://github.com/CraterCrash/godot-orchestrator/commit/1b73261073c5ff708ebece687e04be13f7f74ddd) - GH-371 Fix zoom factor connection knot rendering
- [8f8e908](http://github.com/CraterCrash/godot-orchestrator/commit/8f8e90815d13b79c8d929677d69c2bfa4a3bde17) - Fix several code warnings
- [69b99ab](http://github.com/CraterCrash/godot-orchestrator/commit/69b99ab55194a79fa941bc776868e6c24e222a20) - [ci] Fix ubuntu builds
- [536fe94](http://github.com/CraterCrash/godot-orchestrator/commit/536fe94615e1a44856ab413dd578fd377fbd5e3d) - GH-356 Fix knot rendering on Godot 4.2
- [dfb68ae](http://github.com/CraterCrash/godot-orchestrator/commit/dfb68ae24da9d379a8c37f6faf9c10eb44bde94e) - GH-352 Curvature only between first two and last two points
- [ca11421](http://github.com/CraterCrash/godot-orchestrator/commit/ca11421f702b3790133307760c60643ec7db00de) - GH-350 Add for-each/for-loop abort output pin

## [2.1.dev2](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.1.dev2) - 2024-05-12

- [0aada9d](http://github.com/CraterCrash/godot-orchestrator/commit/0aada9d8bb379748f9e73745c11bb94ff778f035) - GH-78 Support graph connection wire knots
- [aa7daa0](http://github.com/CraterCrash/godot-orchestrator/commit/aa7daa021156599ddc1635b128a05ab26a8a8e99) - GH-347 Improve base type indicator on graph toolbar
- [e950b60](http://github.com/CraterCrash/godot-orchestrator/commit/e950b609c2a8f5789090cfda17dc2078cc0e8799) - Remove unused assignment
- [50fcd4d](http://github.com/CraterCrash/godot-orchestrator/commit/50fcd4dfc43b011b7bb968de4a508adde55d1b72) - GH-156 Collapse nodes to function and expand node feature
- [234b209](http://github.com/CraterCrash/godot-orchestrator/commit/234b209bd166e2d5081326951438862cc3ef4a87) - GH-339 Retain/store variable type filter across popup/restarts
- [78a75fe](http://github.com/CraterCrash/godot-orchestrator/commit/78a75fea206861931146e9e5ae224633b6e5a21c) - GH-345 Fix regression
- [6eb9d2a](http://github.com/CraterCrash/godot-orchestrator/commit/6eb9d2ab82f41dd2af334e4d82bf5fc786c705a1) - GH-343 Improve node styles, fidelity, and usability
- [677a920](http://github.com/CraterCrash/godot-orchestrator/commit/677a920b95fe51c5bd727da91654ddf2c1a3e232) - GH-345 Add landing page to main view
- [44c7055](http://github.com/CraterCrash/godot-orchestrator/commit/44c7055c85b06040addcdb453d4691a8e2ac417e) - GH-301 Support class/enum/bitfield based variables
- [d7df658](http://github.com/CraterCrash/godot-orchestrator/commit/d7df658a4113e0acb278a9e37cbdad54d867d16c) - GH-242 Add impl for ScriptLanguageExtension::_preferred_file_name_casing
- [49b21a5](http://github.com/CraterCrash/godot-orchestrator/commit/49b21a5fbe218f2e44accfeaa813a1f8b7f368e4) - GH-221 View doc jump to class/constant/method Godot doc
- [3896d22](http://github.com/CraterCrash/godot-orchestrator/commit/3896d22be7e9934f70270a7f2addabff7ddd106c) - GH-330 Fix Self node broken icon
- [340c512](http://github.com/CraterCrash/godot-orchestrator/commit/340c512a946e40df799bb9a2bcda3dbf7766d388) - GH-333 Implement GridPattern support for Godot 4.3
- [692d3b2](http://github.com/CraterCrash/godot-orchestrator/commit/692d3b2217a479ec65f5868f9a1d0cce59f3170c) - GH-76 Add scroll to item signal
- [d0c5e5d](http://github.com/CraterCrash/godot-orchestrator/commit/d0c5e5d5049056089d5dbfdcf5f926d5c8f25396) - GH-327 Fix editor crash on invalid reference
- [671ba65](http://github.com/CraterCrash/godot-orchestrator/commit/671ba65e26c65aca7161864abb6229ad9d1cd992) - [ci] Fix workflow
- [ead3e5f](http://github.com/CraterCrash/godot-orchestrator/commit/ead3e5f72a09318edf7fe075ce5ced2f7e0528ba) - [ci] Add arguments to change-log workflow
- [b9317fe](http://github.com/CraterCrash/godot-orchestrator/commit/b9317fed34778e93b965cbe558a17f1d74b98928) - GH-284 Add support for static functions
- [9a97c2a](http://github.com/CraterCrash/godot-orchestrator/commit/9a97c2ab42a7dab32646c8047723eb354b399750) - GH-321 Persist `For Each` node's "with break" status
- [1f82cf0](http://github.com/CraterCrash/godot-orchestrator/commit/1f82cf0efcd352fe360a1eede7c06687f4c5e28f) - GH-323 Fix persisting enum default value choices
- [c0289a7](http://github.com/CraterCrash/godot-orchestrator/commit/c0289a7af4c03e984cc885e14b1289d2ab397829) - GH-315 Have `For Each` set Element as `Any`
- [79e3a90](http://github.com/CraterCrash/godot-orchestrator/commit/79e3a908afdc5df24d85665316eee7aac6126680) - GH-318 Add `Dictionary Set` node
- [2d45ebc](http://github.com/CraterCrash/godot-orchestrator/commit/2d45ebc78ba41a413e96267646d9562b4a3860f7) - GH-313 Add Godot version compile-time constant
- [5f06fc6](http://github.com/CraterCrash/godot-orchestrator/commit/5f06fc6deb62bb49757f3e7c38307397a209f593) - GH-304 Track recently accessed orchestrations
- [7621afe](http://github.com/CraterCrash/godot-orchestrator/commit/7621afee3fc70e2b3e849d3d042978ab052f4a31) - GH-310 Support file/folder removed and files moved signals
- [cf3a2f7](http://github.com/CraterCrash/godot-orchestrator/commit/cf3a2f714bdc37a089543683aea6d8711519a235) - GH-306 Refactor `MethodUtils`
- [75726ee](http://github.com/CraterCrash/godot-orchestrator/commit/75726ee59bb05798fdd711d5d26fc1609b87d2d1) - GH-306 Fix functions to return Any types
- [07c3305](http://github.com/CraterCrash/godot-orchestrator/commit/07c3305d5c35bb8cb0d75210001f650cace7f9f6) - GH-287 Always call "Init" event if its wired
- [43f7f48](http://github.com/CraterCrash/godot-orchestrator/commit/43f7f48e1f06a0dffaa1ca12ef6758afbc937e83) - GH-283 Support method chaining
- [766bc0a](http://github.com/CraterCrash/godot-orchestrator/commit/766bc0a94bfc64c0d3214669810e19bd1b7db0c1) - GH-289 Fix built-in methods using PROPERTY_USAGE_NIL_IS_VARIANT
- [0ea31d1](http://github.com/CraterCrash/godot-orchestrator/commit/0ea31d1db861720d22b1a687464f3c7244cb7b41) - GH-282 Explicitly filter `_get` and `_set` methods
- [35a6b7e](http://github.com/CraterCrash/godot-orchestrator/commit/35a6b7ebc7d9090ebcf09bbf04ec7ea1ff05eb21) - GH-297 Preserve setting order when setting is modified
- [037ec30](http://github.com/CraterCrash/godot-orchestrator/commit/037ec302e0265b9ae4afd98de21e9d4cf3750d45) - Fix comparison signed/unsigned mismatch
- [229e723](http://github.com/CraterCrash/godot-orchestrator/commit/229e7238afdd9a701ddf8a602489171aacc69ace) - GH-272 Remove obsolete documentation
- [7602de2](http://github.com/CraterCrash/godot-orchestrator/commit/7602de28930113fed0133fc5ac5b8158dcb8f3ff) - Rework editor icon lookups

## [2.1.dev1](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.1.dev1) - 2024-04-22

- [3508d11](http://github.com/CraterCrash/godot-orchestrator/commit/3508d1170fb363802ac71e6895e1b0a6fa26fb57) - GH-206 Correctly generates action items for instantiated scenes
- [d58ca8a](http://github.com/CraterCrash/godot-orchestrator/commit/d58ca8ab2a4c2371445ad47b3ce55a9f0cee437e) - GH-205 Dim wires when using `highlight_selected_connections`
- [7ee7f94](http://github.com/CraterCrash/godot-orchestrator/commit/7ee7f941ed1a1ad4a17a72eeb594b8933957e8b8) - GH-248 Construct `Callable` with correct target reference
- [16d5503](http://github.com/CraterCrash/godot-orchestrator/commit/16d55033aefbaf0388b0a4e52e9ada6af3e9944d) - GH-273 Force `PrintStringUI` to ignore mouse events
- [a64f593](http://github.com/CraterCrash/godot-orchestrator/commit/a64f59326a702bebcea8214330133c0785610482) - GH-254 Fix emitting non-Orchestrator based signals
- [c18f68a](http://github.com/CraterCrash/godot-orchestrator/commit/c18f68a856138696b3c58dfeff7f3f4602c4b203) - GH-238 Rework/Improve Bitfield pin value rendering
- [0c78712](http://github.com/CraterCrash/godot-orchestrator/commit/0c787129e95299024745b7780dec2229a38c768b) - GH-265 Support Object `new()` and `free()` nodes
- [7548c45](http://github.com/CraterCrash/godot-orchestrator/commit/7548c45972114e25ad87c1964e6cb1bf12fe37d7) - GH-266 Correctly resolve property class actions
- [09dbfed](http://github.com/CraterCrash/godot-orchestrator/commit/09dbfed3dce3f8bfd58de8dd59e8a87994c049e6) - GH-253 Include registered autoloads in all actions menu
- [1523e3a](http://github.com/CraterCrash/godot-orchestrator/commit/1523e3a2f3e2b52ff36e3770f720c0dcd2648155) - GH-268 Do not serialize OScriptNode flags
- [c2c8a77](http://github.com/CraterCrash/godot-orchestrator/commit/c2c8a7712404720206b84d9d9142f6316fbb5a04) - [ci] Upgrade tj-actions/changed-files from v44.1.0 to v44.3.0
- [d639a00](http://github.com/CraterCrash/godot-orchestrator/commit/d639a00984048cf64151bfd38668d2169c5d3317) - Don't use bitwise `&` operator, use correct operator
- [af1b9fe](http://github.com/CraterCrash/godot-orchestrator/commit/af1b9fe2c1989be80b27de377ea13db7565d71eb) - Don't make unnecessary copies of OScriptGraph
- [b99eff2](http://github.com/CraterCrash/godot-orchestrator/commit/b99eff2bc4da9edd0be1a0b0c07b1c3aaa6aaed6) - [ci] Upgrade tj-actions/changed-files from v44.0.1 to v44.1.0
- [a643406](http://github.com/CraterCrash/godot-orchestrator/commit/a643406eb9033dc6d94ca5abf61ca5448f0ad820) - [ci] Android artifacts use 'lib' prefix
- [48c4179](http://github.com/CraterCrash/godot-orchestrator/commit/48c41795176fdd6c3cd687ce963bc18176c018ba) - [ci] Disable debug builds
- [65da934](http://github.com/CraterCrash/godot-orchestrator/commit/65da93480705fcb558f7dc58125e3c80748384da) - [ci] Add android build
- [61cd74d](http://github.com/CraterCrash/godot-orchestrator/commit/61cd74d5c3209ffc728fc482978c082cf358d6d7) - Update documentation link in README.md
- [5ec6e82](http://github.com/CraterCrash/godot-orchestrator/commit/5ec6e827a0e1bffcf444f46e8e1cad709dd5ca89) - [ci] Upgrade tj-actions/changed-files from v44.0.0 to v44.0.1
- [7018570](http://github.com/CraterCrash/godot-orchestrator/commit/7018570030f39e9a963a605bb1a304fa68c54d20) - [ci] Upgrade robinraju/release-downloader from v1.9 to v1.10
- [e11519f](http://github.com/CraterCrash/godot-orchestrator/commit/e11519f4595f21b4675722ae3e0dcd30c4daf350) - GH-245 Force `ExtensionDB` generator to use LF line endings
- [c563837](http://github.com/CraterCrash/godot-orchestrator/commit/c563837b86f1078bce744b14b48bf992f59e356d) - GH-239 Provide `ExtensionDB::is_class_enum_bitfield` look-up
- [112f566](http://github.com/CraterCrash/godot-orchestrator/commit/112f5666aa218fbf1ee1c147984122a50a340985) - GH-237 Render @GlobalScope and class-scope bitfields uniformly
- [633cd18](http://github.com/CraterCrash/godot-orchestrator/commit/633cd184f6a90d1567fce598e87c65494f337268) - GH-240 Standardize Method return value check
- [14bcedf](http://github.com/CraterCrash/godot-orchestrator/commit/14bcedff8786dc6e239ae6ea7fa2c3a35e578905) - GH-217 Guard against nullptr
- [937011c](http://github.com/CraterCrash/godot-orchestrator/commit/937011c80646fdcb28b279f52068453191426e16) - GH-217 Add signal connection indicator for user-defined functions
- [bcc03ed](http://github.com/CraterCrash/godot-orchestrator/commit/bcc03edbbc73585e501ad9459d28fbfb9b1d47cc) - GH-232 Remove superfluous warnings saving callable/signal types
- [3abdc3d](http://github.com/CraterCrash/godot-orchestrator/commit/3abdc3d8a613d2ead4fdbcc0685230e07d15fac5) - GH-230 Reconstruct existing node on sync request
- [5ccab43](http://github.com/CraterCrash/godot-orchestrator/commit/5ccab43539a79ebcf9727a3a4a4708a3da6a1e91) - GH-222 Allow some constant/singleton names be searchable
- [139a5f0](http://github.com/CraterCrash/godot-orchestrator/commit/139a5f0819a79674ae8f3123dfdbf530f834ca79) - GH-227 Correctly encode Godot vararg built-in functions
- [3c1900e](http://github.com/CraterCrash/godot-orchestrator/commit/3c1900ec1e91cb78fe505f513443b0cfefdb42df) - Update README screenshots
- [8d60bc8](http://github.com/CraterCrash/godot-orchestrator/commit/8d60bc8e550336c6c095b0eb097a0fa7d7d0a941) - GH-207 Change orchestration view based on active root scene node
- [57041b1](http://github.com/CraterCrash/godot-orchestrator/commit/57041b1c891de667bc8e9c5dfe1d04979f30a0cd) - GH-204 Spawn override function at center of view
- [6e69142](http://github.com/CraterCrash/godot-orchestrator/commit/6e69142ec827eb2bff004355a9b85114f5ef21c8) - GH-215 Initially set function arguments to default values

## [2.0.stable](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.0.stable) - 2024-03-30

- [280aadc](http://github.com/CraterCrash/godot-orchestrator/commit/280aadcb5c592722e52718af4bb247c249dc5a57) - GH-202 Fix disconnect error on `tab_changed` signal
- [30d6299](http://github.com/CraterCrash/godot-orchestrator/commit/30d6299a21786024e9b1669ff826f2b0b789a3fe) - GH-208 Fix patch/build version check logic
- [5038580](http://github.com/CraterCrash/godot-orchestrator/commit/503858047c6c90b28a57351aed7f6e080de96602) - GH-208 Add auto-update functionality
- [ecbdebf](http://github.com/CraterCrash/godot-orchestrator/commit/ecbdebf2fd3e96cad724c16788d47ca7e1f1fba1) - [ci] Upgrade tj-actions/changed-files from v43.0.1 to v44.0.0

## [2.0.rc2](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.0.rc2) - 2024-03-24

- [65f82f2](http://github.com/CraterCrash/godot-orchestrator/commit/65f82f2229f09fd04b35960c1954c3ba44805881) - Rework about dialog
- [3b17834](http://github.com/CraterCrash/godot-orchestrator/commit/3b1783489887777c51b1291c51dbbb2dc7d48243) - GH-176 Move dialog center prior to popup
- [10034e3](http://github.com/CraterCrash/godot-orchestrator/commit/10034e3ec8df8ef76179298752d07ff79932ff3c) - GH-193 Allow highlighting selected nodes/connections
- [1e4ae2e](http://github.com/CraterCrash/godot-orchestrator/commit/1e4ae2e6b6ab56cbef3432878bfd5fd9e2f3a0e8) - GH-183 Signal function connection indicator/dialog
- [34f85f8](http://github.com/CraterCrash/godot-orchestrator/commit/34f85f877dec17f4526ac898b2086f72f56322a3) - GH-177 Fix type propagation for Preload and Instantiate Scene
- [e769057](http://github.com/CraterCrash/godot-orchestrator/commit/e7690574fa98026435ab8d35369e62a8734ecaf7) - GH-194 Reduce title text in call function nodes
- [57e13ce](http://github.com/CraterCrash/godot-orchestrator/commit/57e13ce430ddab059df0fa4757309acc53ccc501) - GH-187 Add BitField input/default value support
- [3599beb](http://github.com/CraterCrash/godot-orchestrator/commit/3599bebde3aaab834fca4c71c58c0332e7bf5896) - GH-180 Support variadic function arguments
- [5e36291](http://github.com/CraterCrash/godot-orchestrator/commit/5e3629180135fdfffea93d0b111877ae172ff573) - GH-190 Do not cache instantiated scene node
- [fdec82f](http://github.com/CraterCrash/godot-orchestrator/commit/fdec82f958e94c2aa82010d0eace46f1f3e247dd) - GH-179 Remove Function Call `(self)` indicator from non-target pins
- [1590194](http://github.com/CraterCrash/godot-orchestrator/commit/1590194efb24248638536029b65386742ce73742) - GH-179 Function Call `Target` pin no longer autowired
- [b19db62](http://github.com/CraterCrash/godot-orchestrator/commit/b19db62f31e78495f47ebae0af2f4ca4d539ea81) - GH-182 The `ENTER` key releases node input focus
- [4e146cb](http://github.com/CraterCrash/godot-orchestrator/commit/4e146cba5eeedf8a9fb3a5abea1c3c8191c71a0e) - GH-176 Position all actions menu based on `center_on_mouse`
- [2b95ddd](http://github.com/CraterCrash/godot-orchestrator/commit/2b95ddd35423082b89b9ea621deaa516acbf0e2d) - [ci] Upgrade tj-actions/changed-files from v43.0.0 to v43.0.1
- [d84191d](http://github.com/CraterCrash/godot-orchestrator/commit/d84191dbc4282f7cb33ef19faf9cbb7b78134179) - GH-173 Align styles with non-comment nodes
- [6cd0b66](http://github.com/CraterCrash/godot-orchestrator/commit/6cd0b66aea13d6d8d9d0cca37bc5e55bd5f96f55) - GH-173 Sync comment background color on inspector change
- [df24b23](http://github.com/CraterCrash/godot-orchestrator/commit/df24b23d6e6a877a41ba07b5f15bea12d9ca0cfb) - Update README.md
- [551ed1f](http://github.com/CraterCrash/godot-orchestrator/commit/551ed1f738fe64c8c11d1a4ae37afe648198fa51) - GH-98 Distribute Orchestrator icon .import files
- [df6691f](http://github.com/CraterCrash/godot-orchestrator/commit/df6691fff827a8df9f69a16570ac1b25b4fa3eb5) - GH-152 Do not change node icons when script attached
- [269e8e9](http://github.com/CraterCrash/godot-orchestrator/commit/269e8e9f2079226bf9c33634ee1dd75999f694b5) - GH-167 Use `ubuntu-20.04` for GLIBC 2.31
- [161976e](http://github.com/CraterCrash/godot-orchestrator/commit/161976e26078cf28a0da6add0f76063110ee85c4) - [ci] Upgrade tj-actions/changed-files from v42.1.0 to v43.0.0
- [de49a48](http://github.com/CraterCrash/godot-orchestrator/commit/de49a480e4512b2095a0a39d4b2b31928b105c80) - GH-164 Add Local Variable types Object & Any
- [38e5b43](http://github.com/CraterCrash/godot-orchestrator/commit/38e5b43df3614a3b49d4d2436c568b624cc949c4) - GH-158 Correctly escape modulus title text
- [7d77cff](http://github.com/CraterCrash/godot-orchestrator/commit/7d77cffe6da374574acd20e9c619a7ec9fd04eaa) - GH-155 Allow toggling component panel visibility
- [6113a9c](http://github.com/CraterCrash/godot-orchestrator/commit/6113a9c4b84a79497effa07d74173b92df5bf7c4) - GH-159 Support all Packed-Array types
- [63011e1](http://github.com/CraterCrash/godot-orchestrator/commit/63011e1d397232321bc948298659641c75b5cea1) - [ci] Upgrade tj-actions/changed-files from v42.0.7 to v42.1.0
- [7c6731e](http://github.com/CraterCrash/godot-orchestrator/commit/7c6731e72793b774d4d7b1fe9c6b796255100f0d) - Update documentation workflow

## [2.0.rc1](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.0.rc1) - 2024-03-10

- [468efc6](http://github.com/CraterCrash/godot-orchestrator/commit/468efc63bf36ac24848a7a709fcbf40ef87cd795) - [docs] Update tutorial
- [5522fd1](http://github.com/CraterCrash/godot-orchestrator/commit/5522fd11df1dc027fc0f8b0430133d4285976fe9) - [docs] Update docs images with new styles
- [7ed918c](http://github.com/CraterCrash/godot-orchestrator/commit/7ed918c8620c7720466df92699c49b4e22d26887) - [docs] Update nodes
- [2b5ba1a](http://github.com/CraterCrash/godot-orchestrator/commit/2b5ba1a90d9c98b6d0875bdecc1ac93d6396309e) - GH-145 Use `snprintf` instead
- [cbd89b2](http://github.com/CraterCrash/godot-orchestrator/commit/cbd89b22f5bf149c72070e051a614f2ad6969db4) - GH-145 Use arch_linux compatible time formatting
- [ebb0b0b](http://github.com/CraterCrash/godot-orchestrator/commit/ebb0b0bf3b24a31f002aeac42140903ed4202e10) - [ci] Upgrade tj-actions/changed-files from v42.0.6 v42.0.7
- [2a64fe4](http://github.com/CraterCrash/godot-orchestrator/commit/2a64fe44c2a22b815d5484ef571c4adcc1dc8dee) - GH-136 Add build validation for autoload node
- [696f89a](http://github.com/CraterCrash/godot-orchestrator/commit/696f89a1f729438889bb0891e2eea792ee97db6d) - GH-136 Add support for accessing Godot autoloads
- [dfb8ece](http://github.com/CraterCrash/godot-orchestrator/commit/dfb8eceec8c5c39c5830f6ec78697e84bdb4632a) - GH-143 Return null rather than 0-sized property info list
- [290f57e](http://github.com/CraterCrash/godot-orchestrator/commit/290f57ee5406351591d632d61551d56618e1ebb1) - [ci] Upgrade tj-actions/changed-files from v42.0.5 to v42.0.6
- [573abaa](http://github.com/CraterCrash/godot-orchestrator/commit/573abaa18b2b122489999ff45e451e79d813e49b) - GH-122 Introduce `Instantiate Scene` node
- [92c7b06](http://github.com/CraterCrash/godot-orchestrator/commit/92c7b06eb62a032fe968c5fe0529a2eb7e5842a9) - GH-122 Make file pin behavior generic
- [2f84493](http://github.com/CraterCrash/godot-orchestrator/commit/2f844933ef730124636a81b3d6264466201c584c) - GH-118 Fix equality ambiguity failure
- [3a98226](http://github.com/CraterCrash/godot-orchestrator/commit/3a982264068d6a61d2da9774ad7655c1930a0a67) - GH-118 Fix NodePath property resolution
- [33a995d](http://github.com/CraterCrash/godot-orchestrator/commit/33a995ddf8ddcd03525eca56649d8f4c969acd00) - GH-118 Fix GetSceneNode resolution
- [24f9f5a](http://github.com/CraterCrash/godot-orchestrator/commit/24f9f5af46b2df43027b15c09584eaa0264c8a1d) - GH-121 Dispatch only script user-defined functions
- [19026d5](http://github.com/CraterCrash/godot-orchestrator/commit/19026d5dfafe62ef4eafd274f295a0fca6ed3c75) - GH-126 Correctly select last open file
- [20665b2](http://github.com/CraterCrash/godot-orchestrator/commit/20665b22a3c9fb8eb716a86bcb85fccf473d082a) - GH-132 Improved graph node rendering
- [16eab41](http://github.com/CraterCrash/godot-orchestrator/commit/16eab414ec4cf0e2f09530e8c2fc5cd2311b55e0) - GH-130 Improve filtering of All Actions dialog
- [8afc997](http://github.com/CraterCrash/godot-orchestrator/commit/8afc997f15c7b5154e4cf2f417fad0bdaf59a256) - GH-126 Render file list like Script tab file list
- [420505a](http://github.com/CraterCrash/godot-orchestrator/commit/420505a3e52c1f1cb2ebee3b4192d1e7f52ab7a7) - GH-111 Correctly handle return type as Variant
- [e3def5b](http://github.com/CraterCrash/godot-orchestrator/commit/e3def5b21a3bbe14c13ee45f48779f44c7ff8a4f) - [ci] Add build concurrency
- [7d67fa4](http://github.com/CraterCrash/godot-orchestrator/commit/7d67fa48b35b6c5aeec518e2fb776d83b39c1728) - [ci] Temporarily disable rsync
- [6c775b3](http://github.com/CraterCrash/godot-orchestrator/commit/6c775b34d9d8054fd573ebcbcd21cfdd6c88f748) - [ci] Remove rsync delete
- [b5fc6f8](http://github.com/CraterCrash/godot-orchestrator/commit/b5fc6f8af0826f3ca9be369318b3a8686ba4a2e2) - [ci] Temporarily rsync docs
- [5710786](http://github.com/CraterCrash/godot-orchestrator/commit/5710786b48ade7225a299716710f736232e5a829) - [ci] Fix documentation workflow condition
- [92332e8](http://github.com/CraterCrash/godot-orchestrator/commit/92332e886c3a1c7b37e984d80788d2e1d0f91a80) - [ci] New Documentation Workflow Builder
- [7c398b2](http://github.com/CraterCrash/godot-orchestrator/commit/7c398b2ad0c6af11712062aff1712102bbd97d1c) - GH-112 Correctly coerce `ComposeFrom` values
- [e91d54f](http://github.com/CraterCrash/godot-orchestrator/commit/e91d54f1053a22d0fcba67bf685ad421cbe74468) - GH-116 Correctly update exported default values on nodes
- [665ec25](http://github.com/CraterCrash/godot-orchestrator/commit/665ec25d4f86f945ba4c93b9fbe1e795b6923608) - GH-114 Apply editor display scale to toolbar
- [f705d1e](http://github.com/CraterCrash/godot-orchestrator/commit/f705d1eea449530db468f26e6e902df5df836c49) - [CMake] Add MacOS universal binary (x86_64,arm64) support

## [2.0.dev3](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.0.dev3) - 2024-02-25

- [862aa9d](http://github.com/CraterCrash/godot-orchestrator/commit/862aa9d310da3a4e900f5ec126a14c266bace010) - GH-84 Support favorites in "All actions" menu
- [ceee2e8](http://github.com/CraterCrash/godot-orchestrator/commit/ceee2e80f521196379aa39509b62ab662d31fafe) - [ci] Upgrade metcalfc/changelog-generator from 4.3.0 to 4.3.1
- [cfdf3e8](http://github.com/CraterCrash/godot-orchestrator/commit/cfdf3e8a3e614430da5c636fb03085dbecd5afd3) - [ci] Remove show files and retest upload
- [843b800](http://github.com/CraterCrash/godot-orchestrator/commit/843b800dc901272b492d83fa7e81bc5323d5addc) - [ci] Show files after download
- [0a381e2](http://github.com/CraterCrash/godot-orchestrator/commit/0a381e268a139661a1ca8ffdcc4e8a69090c6c6a) - [ci] Remove geekyeggo/delete-artifact
- [ecc87c4](http://github.com/CraterCrash/godot-orchestrator/commit/ecc87c408954dcebd503326f5531f79c007d08e0) - [ci] Upgrade actions/upload-artifact from v3 to v4
- [8e6b5a0](http://github.com/CraterCrash/godot-orchestrator/commit/8e6b5a0e4478ec3e5c2bd28d8f1421305ca90685) - [ci] Replace jwlawson/actions-setup-cmake@v1.14 with get-cmake@v3.28.0
- [93d6f64](http://github.com/CraterCrash/godot-orchestrator/commit/93d6f6439d977cd6d33b37db2c6b63a62268af8d) - [ci] Upgrade ilammy/msvc-dev-cmd from 1.12.1 to 1.13.0
- [9bfa8f5](http://github.com/CraterCrash/godot-orchestrator/commit/9bfa8f50dff93517f906f34ed19edf1ffc037c8f) - [ci] Upgrade actions/setup-python from 4 to 5
- [d4bc2ea](http://github.com/CraterCrash/godot-orchestrator/commit/d4bc2eabc2429fee375b92366d762bcfbcb0d239) - GH-74 Add action menu database cache
- [b14f433](http://github.com/CraterCrash/godot-orchestrator/commit/b14f4332ec8f7aa8c929373538b4dd312ea8e69e) - [perf]: minimize function call result variant copies
- [f91ac2f](http://github.com/CraterCrash/godot-orchestrator/commit/f91ac2ff02248aba826d86cf6fd8aaa7beba305c) - [perf]: optimize variant usage in operator node
- [ed2da2f](http://github.com/CraterCrash/godot-orchestrator/commit/ed2da2f31a4748781c9ba1757a201626200c09d3) - [perf]: reduce hash-map lookup by caching function node instance pair
- [f2fdf5f](http://github.com/CraterCrash/godot-orchestrator/commit/f2fdf5f7290f781c4d164b04fca8b4447eb34c24) - [perf]: optimize ComposeFrom node behavior
- [7d4f042](http://github.com/CraterCrash/godot-orchestrator/commit/7d4f0427783e366b4455913ee30ec67840e3b2e5) - [perf]: rework execution context and stack
- [1a83ee8](http://github.com/CraterCrash/godot-orchestrator/commit/1a83ee83d5796a96438105bb9f60e989b2cafcc6) - [perf]: use cached script node identifier
- [f14f82e](http://github.com/CraterCrash/godot-orchestrator/commit/f14f82e1ee8c1933b2874b14f8d04fcc75550017) - [perf]: allow multiple return nodes in function graphs
- [96c2e5b](http://github.com/CraterCrash/godot-orchestrator/commit/96c2e5be9e3225000599e5f9ba7cc7c3810a7c4d) - [perf]: call function node improvements
- [c60bfa4](http://github.com/CraterCrash/godot-orchestrator/commit/c60bfa464b4c524ef8447cd5b2b957ae3303fb9d) - [perf]: clear_error is now no-op if no error is set
- [679139d](http://github.com/CraterCrash/godot-orchestrator/commit/679139d512eb6e6ecaa17ad9acd033491b4e83bf) - [perf]: allocate empty working memory register statically
- [2f52346](http://github.com/CraterCrash/godot-orchestrator/commit/2f52346eeac9048c3efb26ae276d31334ae8d07f) - [perf]: scope ERR_FAIL_xxx macros to DEBUG builds
- [2eda2af](http://github.com/CraterCrash/godot-orchestrator/commit/2eda2af72c85d73df3d1557e11685259bd5073fe) - [perf]: use std::vector<int> and std::lower_bound
- [de2a0a8](http://github.com/CraterCrash/godot-orchestrator/commit/de2a0a8aa147bb32630c6e44fa7d10f5105b8595) - [perf]: cache settings/runtime/max_call_stack
- [8d875ef](http://github.com/CraterCrash/godot-orchestrator/commit/8d875ef049f59042cd4ea25601440d9720f53a7e) - GH-92 Add short-cut keybindings for Variable drag-n-drop
- [e34c057](http://github.com/CraterCrash/godot-orchestrator/commit/e34c0575e7060bb9f2f55d3a5e9325b596d23414) - GH-89 On rename, notify user if new name already exists
- [fe8a393](http://github.com/CraterCrash/godot-orchestrator/commit/fe8a3935e655b2726cb11b0ebe125e18c7e137cf) - GH-89 Correctly resolve new variable names on insert
- [70c0233](http://github.com/CraterCrash/godot-orchestrator/commit/70c023353490014f83db29fdaf21f8b34a2443a5) - GH-82 Fix crash when dragging from node pins
- [2d0c5eb](http://github.com/CraterCrash/godot-orchestrator/commit/2d0c5eb818a215b382806a1495707c4d09dd1d5c) - [ci] Upgrade metcalfc/changelog-generator from 4.2.0 to 4.3.0
- [7defe77](http://github.com/CraterCrash/godot-orchestrator/commit/7defe77aecdb3f14ab15ea06768c2e36ec7c61bb) - [ci] Upgrade robinraju/release-downloader from 1.8 to 1.9

## [2.0.dev2](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.0.dev2) - 2024-01-21

- [ce09546](http://github.com/CraterCrash/godot-orchestrator/commit/ce09546d244ceb9fa750cc6220b410ca42824201) - GH-79 Avoid using deprecated `move_to_foreground`
- [882e7f2](http://github.com/CraterCrash/godot-orchestrator/commit/882e7f2ff0c435400e230c5420da51df93edcf60) - Use Editor theme in About Dialog
- [c864647](http://github.com/CraterCrash/godot-orchestrator/commit/c864647c50de8447ce72e086fed33031a6df3ab1) - GH-72 Add Await Signal Node Feature
- [dde6d70](http://github.com/CraterCrash/godot-orchestrator/commit/dde6d7095af61fcbe9726cea540bfe490f2db905) - GH-67 Fix random error when key is missing
- [fbe3159](http://github.com/CraterCrash/godot-orchestrator/commit/fbe3159fd3330aee2539705b4f397b9ad466a9b3) - GH-66 Add local variable name and description
- [92b9971](http://github.com/CraterCrash/godot-orchestrator/commit/92b99718a1a8a26383ec049c963c6879e1ddf47a) - GH-67 Restore open orchestrations
- [df28556](http://github.com/CraterCrash/godot-orchestrator/commit/df285569af773443bfc19efe2b5bfe0635882a9f) - GH-68 Fix `max_call_stack` property key
- [14c11c2](http://github.com/CraterCrash/godot-orchestrator/commit/14c11c28d4591e3a44ee5086864ed2eeb05e8765) - GH-52 Fix editor crash due to nullptr
- [f2e3766](http://github.com/CraterCrash/godot-orchestrator/commit/f2e37662f98bcbad8f0e34c6eb81e3cee2011dfc) - Add additional Help-menu options
- [b5b3421](http://github.com/CraterCrash/godot-orchestrator/commit/b5b3421a476fdd121ff6c9d159a9918ce79759e8) - GH-52 Work with scene node properties & methods
- [30b6df6](http://github.com/CraterCrash/godot-orchestrator/commit/30b6df629d0f944c207d4158e31378882d5e6494) - GH-61 Add floating window mode
- [90bea05](http://github.com/CraterCrash/godot-orchestrator/commit/90bea051b5f16f4095aad560175ddd27cf257841) - GH-56 Display status text on empty graphs
- [500b0c1](http://github.com/CraterCrash/godot-orchestrator/commit/500b0c1e0fef79d884ae2de9b29993aa22f2a30a) - GH-54 Remove print statement
- [2e666ce](http://github.com/CraterCrash/godot-orchestrator/commit/2e666ce8f05b3dfcd9b9a44c238c5b50e1169996) - GH-54 Add cut/copy/paste/duplicate support
- [06f80b7](http://github.com/CraterCrash/godot-orchestrator/commit/06f80b7baf6824cd8434349ab53a0084a4f7c719) - Upgrade hugoalh/scan-virus-ghaction to 0.20.1
- [85aaacf](http://github.com/CraterCrash/godot-orchestrator/commit/85aaacf39309bb67708920d35e03d72a9f174ac8) - GH-48 Fix rendering of "Update Available" on dev builds
- [f1572bf](http://github.com/CraterCrash/godot-orchestrator/commit/f1572bff1bee46bc82021e1d628699714c9424f0) - Add GitHub Security Workflow
- [625429e](http://github.com/CraterCrash/godot-orchestrator/commit/625429e26b6b40f1da069e3dad567b83eae2b1de) - Add Zoom percentage graph indicator
- [94c85be](http://github.com/CraterCrash/godot-orchestrator/commit/94c85beb56ef14be843f1704122e2086bf8d6ef9) - Add Goto Node accelerator
- [f614bdc](http://github.com/CraterCrash/godot-orchestrator/commit/f614bdcfbed99a72bc54a1c24c3480ffd25b02b2) - Refactor/Cleanup code

## [2.0.dev1](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v2.0.dev1) - 2024-01-01

- [511348b](http://github.com/CraterCrash/godot-orchestrator/commit/511348bdfd863d480de6bd710d5a132b91ede92c) - GH-43 Fix signal function registration
- [dbd29e4](http://github.com/CraterCrash/godot-orchestrator/commit/dbd29e440a502d7808a59291aff598e6d8d3584c) - GH-43 Use default disconnect behavior
- [39d9d58](http://github.com/CraterCrash/godot-orchestrator/commit/39d9d584b48c2135690c4afee44343b69f7677b8) - GH-43 Fix function entry deletion bug
- [dca1b27](http://github.com/CraterCrash/godot-orchestrator/commit/dca1b27a7a9a8cf40dfe2db819cc52352563614a) - GH-43 Update documentation for 2.0
- [927483c](http://github.com/CraterCrash/godot-orchestrator/commit/927483c1f65dc47dfa154c1dcb084dd795e1d24c) - GH-43 Build adjustments
- [741e4eb](http://github.com/CraterCrash/godot-orchestrator/commit/741e4eb7eacad789a511a91a01b49292dfd02e0e) - GH-43 Fix Cleanup build errors/warnings
- [ffbdb3c](http://github.com/CraterCrash/godot-orchestrator/commit/ffbdb3cd1dcf3d4e11475260bdc3a97a9bb28818) - GH-43 Move to ubuntu-latest runners
- [a9f6061](http://github.com/CraterCrash/godot-orchestrator/commit/a9f6061b2fd9378abb62f29a4a9600ffecee675f) - GH-43 Build adjustments
- [d3e53a4](http://github.com/CraterCrash/godot-orchestrator/commit/d3e53a4380812a6f14afcb6b48e5686d70127e70) - GH-43 More cmake fixes
- [4d8aeaa](http://github.com/CraterCrash/godot-orchestrator/commit/4d8aeaa8f820919068e863e68973ce6160798c43) - GH-43 Fix commit hash check
- [760000d](http://github.com/CraterCrash/godot-orchestrator/commit/760000d05b41c34d428093e44bf7a3fe082bbb91) - GH-43 Disable clang-format on build for now
- [ebeff77](http://github.com/CraterCrash/godot-orchestrator/commit/ebeff77c2477c8be733e547f75c2fd6db35a0bcf) - GH-43 Fix clang-format
- [2842457](http://github.com/CraterCrash/godot-orchestrator/commit/284245762d0839156afd0244fb5b8c4794a254ac) - GH-43 Fix incorrect include
- [308a13c](http://github.com/CraterCrash/godot-orchestrator/commit/308a13c59869a18782a4bd4c690348d37c9b8029) - GH-43 Remove unintended inclusion
- [da563dc](http://github.com/CraterCrash/godot-orchestrator/commit/da563dc027d65fc494489d86c08a065bb6f17e75) - GH-43 Use C++20 rather than C++23
- [e8539f5](http://github.com/CraterCrash/godot-orchestrator/commit/e8539f52f26a9dd4e746b8295983f67297cf6892) - GH-43 Port to GDExtension (Godot 4.2+)
- [bf08967](http://github.com/CraterCrash/godot-orchestrator/commit/bf089671a1f9ff5b28a56f2d2e519311726a0286) - GH-45 Only export `/addons/**`

## [1.1.0](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v1.1.0) - 2023-12-08

- [e98d83a](http://github.com/CraterCrash/godot-orchestrator/commit/e98d83ab4d6c90e5fa3cd2af49fbd06f7e8d39b0) - GH-22 Initial supoport for Godot 4.2 (4.2.dev5)
- [bb16856](http://github.com/CraterCrash/godot-orchestrator/commit/bb1685623f985e5b3411cf2028d5bcf86fd4b45d) - [ci] Upgrade metcalfc/changelog-generator from 4.1.0 to 4.2.0
- [867eb58](http://github.com/CraterCrash/godot-orchestrator/commit/867eb58e47d7dbc6c96089d6f378ef926524a876) - Update READMEs
- [90b73b6](http://github.com/CraterCrash/godot-orchestrator/commit/90b73b6b5150f8feb4068a2e8d3a1457a6d71000) - Code improvements
- [4b8c265](http://github.com/CraterCrash/godot-orchestrator/commit/4b8c2656d23b968ce67f6954d842683357b96490) - Add context-menu to Orchestration files list
- [ca1ae29](http://github.com/CraterCrash/godot-orchestrator/commit/ca1ae291e7e6ad570987ff0a4c016bbcf1a4fd41) - GH-24 Introduce an `OrchestrationPlayer` scene node
- [bd20168](http://github.com/CraterCrash/godot-orchestrator/commit/bd201684a3c5b8307e1bccdb07ff0d25a3e8d599) - Update .gitignore
- [292e73c](http://github.com/CraterCrash/godot-orchestrator/commit/292e73c03b62a3e039fb9e3af0b05224536ad842) - GH-33 Add node icons to node list and drag visual
- [266e828](http://github.com/CraterCrash/godot-orchestrator/commit/266e8282982ce273b5fbae5c2fcef0cb519b2e35) - GH-31 Add auto-update feature
- [33684d3](http://github.com/CraterCrash/godot-orchestrator/commit/33684d3ea82079f6e109f11ab4f7dcfd249308cc) - GH-29 Add configurable options to Project Settings UI
- [e20bfc7](http://github.com/CraterCrash/godot-orchestrator/commit/e20bfc74ac86c57481c3fd4a806c6dd181f6d473) - Update README.md
- [4b33aa6](http://github.com/CraterCrash/godot-orchestrator/commit/4b33aa6aa9173d791cfe3d050ef58c9a061bcbf3) - Update README.md
- [7001d13](http://github.com/CraterCrash/godot-orchestrator/commit/7001d1372606c41e9172c9b9c89088a14a05444d) - GH-26 Fix when removing unconnected show message choices
- [26be9f4](http://github.com/CraterCrash/godot-orchestrator/commit/26be9f433d4173a2c57a25df5480ea3f6bea46fc) - GH-21 Show character name field by default
- [277fbd8](http://github.com/CraterCrash/godot-orchestrator/commit/277fbd8a9ea5700ec9af148464bc1da2088cf825) - GH-21 Use correct speaker name for show message node
- [0b6cf15](http://github.com/CraterCrash/godot-orchestrator/commit/0b6cf15f2aba769d4fd1e1cc6ef753721588b3a1) - Add feature request/enhancement issues option
- [027d13b](http://github.com/CraterCrash/godot-orchestrator/commit/027d13bdf77aa926ce3c143299eeda0676b1b4ae) - Update config.yml

## [1.0.5](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v1.0.5) - 2023-09-17

- [0cb4a85](http://github.com/CraterCrash/godot-orchestrator/commit/0cb4a854542f3afffec2b35b241d0ab06a6b677e) - Document wait-for-input-action (#14)
- [0ee6ec3](http://github.com/CraterCrash/godot-orchestrator/commit/0ee6ec38a641b00a487a7e217620a84c0f079ff3) - wait between each action when chaining action multiple times
- [db147c4](http://github.com/CraterCrash/godot-orchestrator/commit/db147c407805a1914b37d7faf33e230da4d4fc09) - adjusted node ui size
- [eacbb2e](http://github.com/CraterCrash/godot-orchestrator/commit/eacbb2ee16a889ccab65373b35af28d7b4d88ced) - renamed shadow variable
- [750e959](http://github.com/CraterCrash/godot-orchestrator/commit/750e9598580f5b2733141a24f987a9be401b34ae) - added wait for action node
- [3fb7b41](http://github.com/CraterCrash/godot-orchestrator/commit/3fb7b41c8282c3eff27d36d7ab4bc44593bba496) - Fix more load order dependency failures
- [402152d](http://github.com/CraterCrash/godot-orchestrator/commit/402152de0606cc6fad34223c849603c40d74183c) - ShowMessage: ESC/SPACE now auto-completes text
- [f585b99](http://github.com/CraterCrash/godot-orchestrator/commit/f585b99a9e5a69d10d263394555dc9b51d2e0115) - Add handles to AUTHORS.txt
- [8275543](http://github.com/CraterCrash/godot-orchestrator/commit/827554380df7218b3bb82bf4c2d8f8b641fe1ad6) - Source version from plugin.cfg
- [a162a9b](http://github.com/CraterCrash/godot-orchestrator/commit/a162a9b156bb6bba82528b5ca365e88e4e2a68d6) - Add GitHub actions & dependabot


## [1.0.4](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v1.0.4) - 2023-09-16

- [4f73e27](https://github.com/CraterCrash/godot-orchestrator/tree/4f73e27eb97f5d20dc89a5685140db846a98a085) - Prepare 1.0.4 release (update version)


## [1.0.3](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v1.0.3) - 2023-09-16

- [4c14f2f](https://github.com/CraterCrash/godot-orchestrator/tree/4c14f2ff1e4c945c3e05053e7b4fd7d2b7e0be08) - Update open file references when moving files
- [7cfc9aa](https://github.com/CraterCrash/godot-orchestrator/tree/7cfc9aa06b1eaad12fd4903517c2f2999cf4c505) - Cleanup editor runtime output
- [fba16d4](https://github.com/CraterCrash/godot-orchestrator/tree/fba16d4289f631369469673e87f162e0b42e22b0) - Fix running orchestrations in editor
- [6c30b52](https://github.com/CraterCrash/godot-orchestrator/tree/6c30b5297ea33742ab13d0a832b8c6554ece64b2) - Allow multiple end nodes
- [b18a349](https://github.com/CraterCrash/godot-orchestrator/tree/b18a34924fc749df2fb2d3fbff82125659d93a1a) - Rename README to README.md
- [d6d7f96](https://github.com/CraterCrash/godot-orchestrator/tree/d6d7f96526b69815207a556bfb40037625768ad7) - Duplicate README in addon folder
- [f6e9fd9](https://github.com/CraterCrash/godot-orchestrator/tree/f6e9fd9a2a88f83b737aa956b034470f8708d019) - Updated README.md


## [1.0.2](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v1.0.2) - 2023-09-10

- [a82afa7](https://github.com/CraterCrash/godot-orchestrator/tree/a82afa7853eff1eb8250b6e3a1d5a1e401787a2b) - Save orchestrations on EditorPlugin apply_changes callback
- [33a1392](https://github.com/CraterCrash/godot-orchestrator/tree/33e1392f63ad8e288ddf6bc990a6c6b22a2d33bc) - Fix plug-in load order, removing const preloads
- [3b54509](https://github.com/CraterCrash/godot-orchestrator/tree/3b54509912d13ac0cc3daf37ba2d202f0cca5dd3) - Load resource scripts safely to avoid runtime errors


## [1.0.1](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v1.0.1) - 2023-09-08

- Removed unused logos.


## [1.0.0](https://github.com/CraterCrash/godot-orchestrator/releases/tag/v1.0.0) - 2023-08-13

- Initial release