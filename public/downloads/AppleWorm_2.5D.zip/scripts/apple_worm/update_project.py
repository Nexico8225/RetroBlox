import re

p = r"D:\Folders\RetroBlox\WormObby\project.godot"
with open(p, "r", encoding="utf-8") as f:
    content = f.read()

content = re.sub(r'run/main_scene="[^"]+"', 'run/main_scene="res://scenes/apple_worm/main_menu.tscn"', content)
content = re.sub(r'config/name="[^"]+"', 'config/name="Apple Worm 2.5D"', content)

if "[autoload]" not in content:
    content += '\n[autoload]\n\nAppleWormGlobal="*res://scripts/apple_worm/apple_worm_global.gd"\n'
elif 'AppleWormGlobal=' not in content:
    content = content.replace("[autoload]", '[autoload]\n\nAppleWormGlobal="*res://scripts/apple_worm/apple_worm_global.gd"')

with open(p, "w", encoding="utf-8") as f:
    f.write(content)

print("Updated project.godot successfully!")
