import os, zipfile

project_dir = r"D:\Folders\RetroBlox\WormObby"
zip_path = r"D:\Folders\RetroBlox\RetroBlox\public\downloads\AppleWorm_2.5D.zip"

exclude_dirs = {'.godot', '.git', '.kombai'}

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(project_dir):
        # Filter out exclude_dirs
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for f in files:
            if f.endswith('.tmp') or f.endswith('.pck'):
                continue
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, project_dir)
            zf.write(full_path, rel_path)

print(f"Created {zip_path} with size: {os.path.getsize(zip_path):,} bytes")
