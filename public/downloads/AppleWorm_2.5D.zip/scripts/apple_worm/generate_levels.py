import os

levels_dir = r"D:\Folders\RetroBlox\WormObby\levels"
os.makedirs(levels_dir, exist_ok=True)

def create_level_tscn(level_num, title, walls, apples, portal, start, start_len=3, start_dir=0, hazards=None):
    if hazards is None:
        hazards = []

    all_x = [w[0] for w in walls] + [portal[0], start[0]] + [a[0] for a in apples]
    all_y = [w[1] for w in walls] + [portal[1], start[1]] + [a[1] for a in apples]
    min_x, max_x = min(all_x), max(all_x)
    min_y, max_y = min(all_y), max(all_y)
    center_x = (min_x + max_x) / 2.0
    center_y = (min_y + max_y) / 2.0
    cam_dist = max(11.0, max(max_x - min_x + 5.0, (max_y - min_y + 4.0) * 1.3))

    lines = []
    # In Godot 4, scene header format:
    lines.append('[gd_scene load_steps=6 format=3]')
    lines.append('')
    lines.append('[ext_resource type="Script" path="res://scripts/apple_worm/apple_worm_level.gd" id="1_lvl"]')
    lines.append('[ext_resource type="Script" path="res://scripts/apple_worm/wall_block.gd" id="2_wall"]')
    lines.append('[ext_resource type="Script" path="res://scripts/apple_worm/apple_item.gd" id="3_apple"]')
    lines.append('[ext_resource type="Script" path="res://scripts/apple_worm/level_portal.gd" id="4_portal"]')
    lines.append('[ext_resource type="Script" path="res://scripts/apple_worm/worm_start.gd" id="5_start"]')
    if hazards:
        lines.append('[ext_resource type="Script" path="res://scripts/apple_worm/spike_hazard.gd" id="6_spike"]')
    lines.append('')
    lines.append(f'[node name="Level{level_num:03d}" type="Node3D"]')
    lines.append('script = ExtResource("1_lvl")')
    lines.append(f'level_title = "{title}"')
    lines.append(f'par_moves = {10 + level_num * 2}')
    lines.append(f'camera_distance = {cam_dist:.1f}')
    lines.append(f'camera_center = Vector2({center_x:.2f}, {center_y:.2f})')
    lines.append('')

    # Worm start
    lines.append('[node name="WormStart" type="Node3D" parent="."]')
    lines.append(f'transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, {start[0]}, {start[1]}, 0)')
    lines.append('script = ExtResource("5_start")')
    lines.append(f'initial_length = {start_len}')
    lines.append(f'initial_direction = {start_dir}')
    lines.append('')

    # Portal
    lines.append('[node name="LevelPortal" type="Node3D" parent="."]')
    lines.append(f'transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, {portal[0]}, {portal[1]}, 0)')
    lines.append('script = ExtResource("4_portal")')
    lines.append('')

    # Walls
    for idx, (wx, wy) in enumerate(walls):
        lines.append(f'[node name="Wall_{idx}" type="Node3D" parent="."]')
        lines.append(f'transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, {wx}, {wy}, 0)')
        lines.append('script = ExtResource("2_wall")')
        lines.append('')

    # Apples
    for idx, (ax, ay, atype) in enumerate(apples):
        lines.append(f'[node name="Apple_{idx}" type="Node3D" parent="."]')
        lines.append(f'transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, {ax}, {ay}, 0)')
        lines.append('script = ExtResource("3_apple")')
        lines.append(f'apple_type = {atype}')
        lines.append('')

    # Hazards
    for idx, (hx, hy) in enumerate(hazards):
        lines.append(f'[node name="Spike_{idx}" type="Node3D" parent="."]')
        lines.append(f'transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, {hx}, {hy}, 0)')
        lines.append('script = ExtResource("6_spike")')
        lines.append('')

    content = '\n'.join(lines) + '\n'
    file_path = os.path.join(levels_dir, f'level_{level_num:03d}.tscn')
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

# Generate 100 progressive levels
for lvl in range(1, 101):
    walls = []
    apples = []
    hazards = []

    if lvl == 1:
        title = "Level 1: First Bite"
        start = (1, 3)
        portal = (9, 3)
        for x in range(0, 4): walls.append((x, 2))
        for x in range(7, 11): walls.append((x, 2))
        apples.append((3, 3, 0)) # Red apple
    elif lvl == 2:
        title = "Level 2: Step Up"
        start = (1, 2)
        portal = (10, 4)
        for x in range(0, 4): walls.append((x, 1))
        walls.append((4, 2))
        walls.append((5, 2))
        for x in range(8, 12): walls.append((x, 3))
        apples.append((5, 3, 0))
    elif lvl == 3:
        title = "Level 3: The Big Leap"
        start = (1, 4)
        portal = (11, 4)
        for x in range(0, 4): walls.append((x, 3))
        for x in range(9, 13): walls.append((x, 3))
        apples.append((3, 4, 0))
    elif lvl <= 15:
        title = f"Level {lvl}: Bridge Builder"
        start = (1, 3)
        gap = min(5, 2 + (lvl // 4))
        portal = (6 + gap, 3)
        for x in range(0, 4): walls.append((x, 2))
        for x in range(5 + gap, 9 + gap): walls.append((x, 2))
        apples.append((3, 3, 0))
        if lvl > 8:
            walls.append((2, 4))
            walls.append((2, 5))
            apples.append((2, 6, 0))
    elif lvl <= 40:
        title = f"Level {lvl}: Narrow Passage"
        start = (1, 5)
        portal = (12, 2)
        for x in range(0, 5): walls.append((x, 4))
        apples.append((3, 5, 1)) # Black apple (shrink)
        for x in range(6, 10):
            walls.append((x, 3))
            walls.append((x, 5))
        for x in range(10, 14): walls.append((x, 1))
    elif lvl <= 70:
        title = f"Level {lvl}: Golden Titan"
        start = (1, 4)
        portal = (16, 4)
        for x in range(0, 4): walls.append((x, 3))
        apples.append((3, 4, 2)) # Gold apple (double size)
        for x in range(14, 18): walls.append((x, 3))
        for x in range(5, 13):
            hazards.append((x, 0))
            walls.append((x, -1))
    else:
        title = f"Level {lvl}: Grand Labyrinth"
        start = (1, 6)
        portal = (18, 3)
        for x in range(0, 4): walls.append((x, 5))
        apples.append((2, 6, 0)) # Red apple
        for x in range(5, 8): walls.append((x, 4))
        apples.append((7, 5, 1)) # Black apple
        walls.append((9, 6))
        walls.append((9, 5))
        walls.append((9, 4))
        walls.append((11, 6))
        walls.append((11, 5))
        walls.append((11, 4))
        for x in range(9, 13): walls.append((x, 2))
        apples.append((12, 3, 2)) # Gold apple
        for x in range(16, 20): walls.append((x, 2))

    create_level_tscn(lvl, title, walls, apples, portal, start, start_len=3, start_dir=0, hazards=hazards)

print(f"Generated 100 level scenes in {levels_dir} successfully!")
