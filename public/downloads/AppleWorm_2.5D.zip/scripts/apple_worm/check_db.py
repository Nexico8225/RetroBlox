import sqlite3

conn = sqlite3.connect(r"D:\Folders\RetroBlox\RetroBlox\db\custom.db")
c = conn.cursor()
tables = [row[0] for row in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]

game_tables = [t for t in tables if any(k in t.lower() for k in ['place', 'game', 'experience'])]
print("Game tables:", game_tables)
for gt in game_tables:
    rows = c.execute(f"SELECT * FROM {gt}").fetchall()
    cols = [d[0] for d in c.description]
    print(gt, cols)
    for r in rows:
        print("  ", r)
