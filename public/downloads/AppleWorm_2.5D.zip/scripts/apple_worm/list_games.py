import sqlite3

conn = sqlite3.connect(r"D:\Folders\RetroBlox\RetroBlox\db\custom.db")
c = conn.cursor()
games = c.execute("SELECT id, name, engine, iconUrl, thumbnailUrl FROM Game").fetchall()
print("Total Games:", len(games))
for g in games:
    print(g)
places = c.execute("SELECT id, slug, name FROM Place").fetchall()
print("Total Places:", len(places))
for p in places:
    print(p)
