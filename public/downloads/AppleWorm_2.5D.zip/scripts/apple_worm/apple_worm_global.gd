# res://scripts/apple_worm/apple_worm_global.gd
extends Node

var selected_level: String = "res://levels/level_001.tscn"
