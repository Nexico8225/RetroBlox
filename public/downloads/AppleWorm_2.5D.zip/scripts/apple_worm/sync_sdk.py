import os, shutil

sdk_dir = r"D:\Folders\RetroBlox\RetroBlox_SDK"
worm_dir = r"D:\Folders\RetroBlox\WormObby"

# 1. Sync scripts
src_scripts = os.path.join(worm_dir, "scripts", "apple_worm")
dst_scripts = os.path.join(sdk_dir, "scripts", "apple_worm")
os.makedirs(dst_scripts, exist_ok=True)
for fn in os.listdir(src_scripts):
    if fn.endswith(".gd"):
        shutil.copy2(os.path.join(src_scripts, fn), os.path.join(dst_scripts, fn))
print("Synced scripts to SDK")

# 2. Create toolbox prefabs for drag-and-drop in SDK & WormObby
prefabs = {
    "wall_block.tscn": """[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://scripts/apple_worm/wall_block.gd" id="1_wb"]
[node name="WallBlock" type="Node3D"]
script = ExtResource("1_wb")
""",
    "apple_red.tscn": """[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://scripts/apple_worm/apple_item.gd" id="1_ai"]
[node name="AppleRed" type="Node3D"]
script = ExtResource("1_ai")
apple_type = 0
""",
    "apple_black.tscn": """[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://scripts/apple_worm/apple_item.gd" id="1_ai"]
[node name="AppleBlack" type="Node3D"]
script = ExtResource("1_ai")
apple_type = 1
""",
    "apple_gold.tscn": """[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://scripts/apple_worm/apple_item.gd" id="1_ai"]
[node name="AppleGold" type="Node3D"]
script = ExtResource("1_ai")
apple_type = 2
""",
    "level_portal.tscn": """[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://scripts/apple_worm/level_portal.gd" id="1_lp"]
[node name="LevelPortal" type="Node3D"]
script = ExtResource("1_lp")
""",
    "worm_start.tscn": """[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://scripts/apple_worm/worm_start.gd" id="1_ws"]
[node name="WormStart" type="Node3D"]
script = ExtResource("1_ws")
initial_length = 3
initial_direction = 0
""",
    "spike_hazard.tscn": """[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://scripts/apple_worm/spike_hazard.gd" id="1_sh"]
[node name="SpikeHazard" type="Node3D"]
script = ExtResource("1_sh")
"""
}

for base_dir in [worm_dir, sdk_dir]:
    prefabs_dir = os.path.join(base_dir, "toolbox", "apple_worm")
    os.makedirs(prefabs_dir, exist_ok=True)
    for name, content in prefabs.items():
        with open(os.path.join(prefabs_dir, name), "w", encoding="utf-8") as f:
            f.write(content)
print("Created Apple Worm toolbox prefabs in both WormObby and RetroBlox_SDK")
